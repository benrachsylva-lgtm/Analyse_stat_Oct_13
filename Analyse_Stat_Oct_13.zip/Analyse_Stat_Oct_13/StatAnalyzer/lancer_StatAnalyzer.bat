@echo off
title StatAnalyzer - Lancement
color 1F
echo.
echo  ============================================
echo    StatAnalyzer - Analyse Statistique
echo    Logiciel pour la Recherche Medicale
echo  ============================================
echo.

:: Verifier Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERREUR] Python n'est pas installe ou non ajoute au PATH.
    echo  Telechargez Python 3.10+ sur https://www.python.org
    pause
    exit /b 1
)

echo  [OK] Python detecte
echo.

:: Installer les dependances si necessaire
if not exist ".deps_installed" (
    echo  Installation des dependances...
    pip install -r requirements.txt --quiet
    if errorlevel 1 (
        echo  [ERREUR] Echec de l'installation des dependances.
        pause
        exit /b 1
    )
    echo installed > .deps_installed
    echo  [OK] Dependances installees
)

echo  Lancement de StatAnalyzer...
echo.
python main.py

if errorlevel 1 (
    echo.
    echo  [ERREUR] Le logiciel a rencontre une erreur.
    pause
)
