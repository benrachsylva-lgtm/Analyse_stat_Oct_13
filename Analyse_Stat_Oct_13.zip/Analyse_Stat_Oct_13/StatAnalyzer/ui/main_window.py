"""
Interface principale - StatAnalyzer
"""

import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
import numpy as np
from pathlib import Path
import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.data_manager import DataManager
from core import charts as ch
from ui.bivariate_table import BivariateTable
from ui.dossier_page import DossierPatientPage

# ─── Palette de couleurs ──────────────────────────────────────────────────────
C = {
    "bg": "#F0F4F8",
    "sidebar": "#1E3A5F",
    "sidebar_hover": "#2D5A8E",
    "sidebar_active": "#2563EB",
    "card": "#FFFFFF",
    "border": "#CBD5E1",
    "text": "#1E293B",
    "text_secondary": "#64748B",
    "accent": "#2563EB",
    "accent2": "#16A34A",
    "accent3": "#DC2626",
    "accent4": "#D97706",
    "accent5": "#7C3AED",
    "white": "#FFFFFF",
    "header_bg": "#1E3A5F",
}


class ScrollableFrame(ctk.CTkScrollableFrame):
    """Frame scrollable personnalisée"""
    pass


class DataTable(tk.Frame):
    """Tableau de données avec Treeview et scrollbars"""

    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg=C["card"], **kwargs)
        self._build()

    def _build(self):
        # Barre d'outils
        toolbar = tk.Frame(self, bg=C["card"], pady=4)
        toolbar.pack(fill='x', padx=8)

        self.search_var = tk.StringVar()
        self.search_var.trace_add('write', self._on_search)
        search_frame = tk.Frame(toolbar, bg="#EFF6FF", relief='flat',
                                 highlightbackground=C["border"], highlightthickness=1)
        search_frame.pack(side='left')
        tk.Label(search_frame, text="🔍", bg="#EFF6FF", font=('Segoe UI', 10)).pack(side='left', padx=4)
        self.search_entry = tk.Entry(search_frame, textvariable=self.search_var,
                                      bg="#EFF6FF", relief='flat', font=('Segoe UI', 9),
                                      fg=C["text_secondary"], width=20)
        self.search_entry.pack(side='left', padx=4, pady=4)
        self.search_entry.insert(0, "Rechercher...")
        self.search_entry.bind('<FocusIn>', lambda e: self._clear_placeholder())
        self.search_entry.bind('<FocusOut>', lambda e: self._restore_placeholder())

        self.row_info = tk.Label(toolbar, text="", bg=C["card"],
                                  font=('Segoe UI', 9), fg=C["text_secondary"])
        self.row_info.pack(side='right', padx=8)

        # Treeview
        tree_frame = tk.Frame(self, bg=C["card"])
        tree_frame.pack(fill='both', expand=True, padx=8, pady=4)

        style = ttk.Style()
        style.theme_use('clam')
        style.configure("Custom.Treeview",
                         background=C["card"],
                         foreground=C["text"],
                         fieldbackground=C["card"],
                         font=('Segoe UI', 9),
                         rowheight=24)
        style.configure("Custom.Treeview.Heading",
                         background=C["header_bg"],
                         foreground="white",
                         font=('Segoe UI', 9, 'bold'),
                         relief='flat')
        style.map("Custom.Treeview",
                  background=[('selected', C["accent"])],
                  foreground=[('selected', 'white')])
        style.map("Custom.Treeview.Heading",
                  background=[('active', C["sidebar_hover"])])

        vsb = ttk.Scrollbar(tree_frame, orient='vertical')
        hsb = ttk.Scrollbar(tree_frame, orient='horizontal')

        self.tree = ttk.Treeview(tree_frame, style="Custom.Treeview",
                                  yscrollcommand=vsb.set, xscrollcommand=hsb.set,
                                  selectmode='extended')
        vsb.config(command=self.tree.yview)
        hsb.config(command=self.tree.xview)

        self.tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        self._df = None
        self._all_rows = []

    def _clear_placeholder(self):
        if self.search_entry.get() == "Rechercher...":
            self.search_entry.delete(0, 'end')
            self.search_entry.config(fg=C["text"])

    def _restore_placeholder(self):
        if not self.search_entry.get():
            self.search_entry.insert(0, "Rechercher...")
            self.search_entry.config(fg=C["text_secondary"])

    def _on_search(self, *args):
        query = self.search_var.get().lower()
        if query == "rechercher...":
            query = ""
        self.tree.delete(*self.tree.get_children())
        for row in self._all_rows:
            if not query or any(query in str(v).lower() for v in row):
                tag = 'even' if len(self.tree.get_children()) % 2 == 0 else 'odd'
                self.tree.insert('', 'end', values=row, tags=(tag,))
        self.row_info.config(text=f"{len(self.tree.get_children())} lignes affichées")

    def load_dataframe(self, df: pd.DataFrame):
        self._df = df
        self.tree.delete(*self.tree.get_children())
        self.tree['columns'] = list(df.columns)
        self.tree['show'] = 'headings'

        for col in df.columns:
            self.tree.heading(col, text=str(col),
                               command=lambda c=col: self._sort_by(c, False))
            width = max(80, min(200, len(str(col)) * 10))
            self.tree.column(col, width=width, anchor='w', minwidth=60)

        self.tree.tag_configure('even', background='#FFFFFF')
        self.tree.tag_configure('odd', background='#EFF6FF')

        self._all_rows = []
        for _, row in df.iterrows():
            vals = tuple(str(v) if pd.notna(v) else "" for v in row)
            self._all_rows.append(vals)
            tag = 'even' if len(self._all_rows) % 2 == 0 else 'odd'
            self.tree.insert('', 'end', values=vals, tags=(tag,))

        self.row_info.config(text=f"{len(df)} lignes × {len(df.columns)} colonnes")

    def _sort_by(self, col, descending):
        if self._df is None:
            return
        data = [(self.tree.set(child, col), child) for child in self.tree.get_children('')]
        try:
            data.sort(key=lambda x: float(x[0]) if x[0] else -np.inf, reverse=descending)
        except ValueError:
            data.sort(key=lambda x: x[0].lower(), reverse=descending)
        for i, (_, child) in enumerate(data):
            self.tree.move(child, '', i)
        self.tree.heading(col, command=lambda: self._sort_by(col, not descending))


class SidebarButton(ctk.CTkButton):
    def __init__(self, parent, text, icon="", command=None, active=False, **kwargs):
        self._icon = icon
        color = C["sidebar_active"] if active else "transparent"
        super().__init__(
            parent,
            text=f"  {icon}  {text}",
            command=command,
            fg_color=color,
            hover_color=C["sidebar_hover"],
            text_color="white",
            anchor="w",
            font=ctk.CTkFont(family="Segoe UI", size=12),
            height=42,
            corner_radius=8,
            border_spacing=10,
            **kwargs,
        )


class MainWindow(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.data_mgr = DataManager()
        self.last_bivariate_results = []

        self.title("StatAnalyzer — Analyse Statistique Médicale")
        self.geometry("1280x800")
        self.minsize(1100, 700)
        self.configure(fg_color=C["bg"])

        self._build_layout()
        self._show_page("import")

    # ─────────────────────────────── Layout ─────────────────────────────────

    def _build_layout(self):
        # Sidebar
        self.sidebar = ctk.CTkFrame(self, width=230, fg_color=C["sidebar"],
                                     corner_radius=0)
        self.sidebar.pack(side='left', fill='y')
        self.sidebar.pack_propagate(False)

        # Logo / Titre
        logo_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        logo_frame.pack(fill='x', padx=16, pady=(20, 8))
        ctk.CTkLabel(logo_frame, text="📊",
                      font=ctk.CTkFont(size=32), text_color="white").pack()
        ctk.CTkLabel(logo_frame, text="StatAnalyzer",
                      font=ctk.CTkFont(family="Segoe UI", size=16, weight="bold"),
                      text_color="white").pack()
        ctk.CTkLabel(logo_frame, text="Analyse médicale",
                      font=ctk.CTkFont(family="Segoe UI", size=9),
                      text_color="#94A3B8").pack()

        sep = ctk.CTkFrame(self.sidebar, height=1, fg_color="#2D4A6F")
        sep.pack(fill='x', padx=16, pady=10)

        # Boutons de navigation
        nav_items = [
            ("import",      "📂", "Importation"),
            ("completeness","📋", "Complétude"),
            ("descriptive", "📈", "Analyse descriptive"),
            ("groups",      "🗂️", "Groupes"),
            ("bivariate",   "⚖️", "Analyse bivariée"),
            ("export",      "💾", "Exportation"),
            ("dossier",     "🩺", "Dossier patient"),
        ]
        self.nav_buttons = {}
        for page_id, icon, label in nav_items:
            btn = SidebarButton(self.sidebar, label, icon,
                                command=lambda p=page_id: self._show_page(p))
            btn.pack(fill='x', padx=10, pady=2)
            self.nav_buttons[page_id] = btn

        # Version
        ctk.CTkLabel(self.sidebar, text="v1.0  |  Python + CustomTkinter",
                      font=ctk.CTkFont(size=8),
                      text_color="#475569").pack(side='bottom', pady=8)

        # Zone principale
        self.main_area = ctk.CTkFrame(self, fg_color=C["bg"], corner_radius=0)
        self.main_area.pack(side='left', fill='both', expand=True)

        # Pages (frames)
        self.pages = {}
        self._build_import_page()
        self._build_completeness_page()
        self._build_descriptive_page()
        self._build_groups_page()
        self._build_bivariate_page()
        self._build_export_page()
        self._build_dossier_page()

    def _show_page(self, page_id: str):
        for pid, frame in self.pages.items():
            frame.pack_forget()
        self.pages[page_id].pack(fill='both', expand=True)

        for pid, btn in self.nav_buttons.items():
            btn.configure(fg_color=C["sidebar_active"] if pid == page_id else "transparent")

    # ─── Helpers UI ──────────────────────────────────────────────────────────

    def _card(self, parent, title="", **kwargs):
        outer = ctk.CTkFrame(parent, fg_color=C["card"], corner_radius=10,
                              border_width=1, border_color=C["border"], **kwargs)
        if title:
            hdr = ctk.CTkFrame(outer, fg_color=C["accent"], corner_radius=8, height=36)
            hdr.pack(fill='x', padx=8, pady=(8, 0))
            hdr.pack_propagate(False)
            ctk.CTkLabel(hdr, text=title,
                          font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                          text_color="white").pack(side='left', padx=10, pady=6)
        return outer

    def _header(self, parent, title: str, subtitle=""):
        hdr = ctk.CTkFrame(parent, fg_color=C["header_bg"], corner_radius=0, height=64)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text=title,
                      font=ctk.CTkFont(family="Segoe UI", size=15, weight="bold"),
                      text_color="white").pack(side='left', padx=20, pady=(12, 4))
        if subtitle:
            ctk.CTkLabel(hdr, text=subtitle,
                          font=ctk.CTkFont(size=10), text_color="#94A3B8").pack(side='left', padx=4)
        return hdr

    def _btn(self, parent, text, cmd, color=None, width=140, icon=""):
        return ctk.CTkButton(
            parent,
            text=f"{icon} {text}" if icon else text,
            command=cmd,
            fg_color=color or C["accent"],
            hover_color=C["sidebar_hover"],
            text_color="white",
            font=ctk.CTkFont(family="Segoe UI", size=11),
            corner_radius=8,
            height=36,
            width=width,
        )

    def _label(self, parent, text, bold=False, size=10, color=None):
        return ctk.CTkLabel(
            parent,
            text=text,
            font=ctk.CTkFont(family="Segoe UI", size=size, weight="bold" if bold else "normal"),
            text_color=color or C["text"],
        )

    # ─────────────────────────────── PAGE : Import ───────────────────────────

    def _build_import_page(self):
        page = ctk.CTkFrame(self.main_area, fg_color=C["bg"], corner_radius=0)
        self.pages["import"] = page

        self._header(page, "📂  Importation des données",
                      "Chargez votre fichier Excel ou CSV")

        content = ctk.CTkScrollableFrame(page, fg_color=C["bg"], corner_radius=0)
        content.pack(fill='both', expand=True, padx=16, pady=12)

        # Carte chargement fichier
        card_load = self._card(content, "Sélection du fichier")
        card_load.pack(fill='x', pady=(0, 12))

        inner = ctk.CTkFrame(card_load, fg_color="transparent")
        inner.pack(fill='x', padx=16, pady=12)

        self.file_label = self._label(inner, "Aucun fichier sélectionné",
                                       color=C["text_secondary"])
        self.file_label.pack(side='left', fill='x', expand=True)

        self._btn(inner, "Parcourir...", self._browse_file,
                   icon="📁", width=150).pack(side='right')

        # Sélection feuille
        sheet_card = self._card(content, "Feuille Excel (si applicable)")
        sheet_card.pack(fill='x', pady=(0, 12))
        sheet_inner = ctk.CTkFrame(sheet_card, fg_color="transparent")
        sheet_inner.pack(fill='x', padx=16, pady=12)

        self._label(sheet_inner, "Feuille :").pack(side='left', padx=(0, 8))
        self.sheet_var = tk.StringVar(value="Sélectionner une feuille")
        self.sheet_combo = ctk.CTkComboBox(sheet_inner, variable=self.sheet_var,
                                            values=[], width=250, state='disabled',
                                            font=ctk.CTkFont(size=11))
        self.sheet_combo.pack(side='left')
        self._btn(sheet_inner, "Charger", self._load_data,
                   color=C["accent2"], icon="▶", width=120).pack(side='left', padx=8)

        # Résumé de détection
        self.detect_card = self._card(content, "Détection automatique des variables")
        self.detect_card.pack(fill='x', pady=(0, 12))
        self.detect_inner = ctk.CTkFrame(self.detect_card, fg_color="transparent")
        self.detect_inner.pack(fill='x', padx=16, pady=12)
        self._label(self.detect_inner, "Importez un fichier pour voir la détection automatique.",
                     color=C["text_secondary"]).pack(side='left')

        # Tableau de données
        table_card = self._card(content, "Aperçu des données")
        table_card.pack(fill='both', expand=True, pady=(0, 12))
        self.data_table = DataTable(table_card)
        self.data_table.pack(fill='both', expand=True, padx=8, pady=8,
                              ipady=200)

    def _browse_file(self):
        path = filedialog.askopenfilename(
            title="Ouvrir un fichier de données",
            filetypes=[("Fichiers supportés", "*.xlsx *.xls *.csv"),
                       ("Excel", "*.xlsx *.xls"),
                       ("CSV", "*.csv"),
                       ("Tous", "*.*")]
        )
        if not path:
            return
        self.file_label.configure(text=Path(path).name, text_color=C["text"])
        ext = Path(path).suffix.lower()

        if ext in ['.xlsx', '.xls']:
            try:
                sheets = self.data_mgr.get_excel_sheets(path)
                self.sheet_combo.configure(values=sheets, state='readonly')
                self.sheet_var.set(sheets[0])
            except Exception as e:
                messagebox.showerror("Erreur", str(e))
                return
        else:
            self.sheet_combo.configure(values=[], state='disabled')
            self.sheet_var.set("N/A")

        self._current_file_path = path
        # Auto-charger
        self._load_data()

    def _load_data(self):
        if not hasattr(self, '_current_file_path'):
            messagebox.showwarning("Attention", "Veuillez sélectionner un fichier.")
            return

        sheet = self.sheet_var.get() if self.sheet_var.get() not in ("N/A", "Sélectionner une feuille") else None

        try:
            df = self.data_mgr.load_file(self._current_file_path, sheet_name=sheet)
            self.data_table.load_dataframe(df)
            self._update_detect_panel()
            self._refresh_all_combos()
            messagebox.showinfo("Succès",
                                f"Fichier chargé : {len(df)} lignes × {len(df.columns)} colonnes")
        except Exception as e:
            messagebox.showerror("Erreur de chargement", str(e))

    def _update_detect_panel(self):
        for w in self.detect_inner.winfo_children():
            w.destroy()

        dm = self.data_mgr
        n_quant = len(dm.quantitative_vars)
        n_qual = len(dm.qualitative_vars)
        n_missing = dm.df.isna().sum().sum()

        items = [
            (f"{len(dm.df.columns)} variables", C["accent"], "📊"),
            (f"{len(dm.df)} observations", C["accent2"], "👥"),
            (f"{n_quant} quantitatives", "#0891B2", "📈"),
            (f"{n_qual} qualitatives", C["accent5"], "🏷️"),
            (f"{n_missing} valeurs manquantes", C["accent3"] if n_missing > 0 else C["accent2"], "⚠️"),
        ]

        for text, color, icon in items:
            pill = ctk.CTkFrame(self.detect_inner, fg_color=color,
                                 corner_radius=20, height=32)
            pill.pack(side='left', padx=4)
            pill.pack_propagate(False)
            ctk.CTkLabel(pill, text=f"{icon}  {text}",
                          font=ctk.CTkFont(size=10, weight="bold"),
                          text_color="white").pack(padx=12, pady=4)

        # Listes
        if dm.quantitative_vars:
            ctk.CTkLabel(self.detect_inner,
                          text=f"  Quantitatives: {', '.join(dm.quantitative_vars[:6])}{'...' if len(dm.quantitative_vars)>6 else ''}",
                          font=ctk.CTkFont(size=9), text_color=C["text_secondary"]).pack(side='left')

    # ─────────────────────────────── PAGE : Complétude ───────────────────────

    def _build_completeness_page(self):
        page = ctk.CTkFrame(self.main_area, fg_color=C["bg"], corner_radius=0)
        self.pages["completeness"] = page

        self._header(page, "📋  Analyse de complétude",
                      "Valeurs manquantes et taux de renseignement")

        content = ctk.CTkFrame(page, fg_color=C["bg"])
        content.pack(fill='both', expand=True, padx=16, pady=12)

        # Actions
        actions = ctk.CTkFrame(content, fg_color="transparent")
        actions.pack(fill='x', pady=(0, 8))
        self._btn(actions, "Générer le tableau", self._gen_completeness,
                   icon="▶", color=C["accent"]).pack(side='left', padx=4)
        self._btn(actions, "Export Excel", self._export_completeness_excel,
                   icon="📊", color=C["accent2"]).pack(side='left', padx=4)
        self._btn(actions, "Export Word", self._export_completeness_word,
                   icon="📄", color=C["accent5"]).pack(side='left', padx=4)

        # Table
        card = self._card(content, "Tableau de complétude")
        card.pack(fill='both', expand=True)
        self.completeness_table = DataTable(card)
        self.completeness_table.pack(fill='both', expand=True, padx=8, pady=8,
                                      ipady=300)

    def _gen_completeness(self):
        if self.data_mgr.df is None:
            messagebox.showwarning("Attention", "Veuillez d'abord importer des données.")
            return
        df = self.data_mgr.get_completeness_table()
        self.completeness_table.load_dataframe(df)

    def _export_completeness_excel(self):
        self._quick_export("excel", {"completeness": True})

    def _export_completeness_word(self):
        self._quick_export("word", {"completeness": True})

    # ─────────────────────────────── PAGE : Descriptive ─────────────────────

    def _build_descriptive_page(self):
        page = ctk.CTkFrame(self.main_area, fg_color=C["bg"], corner_radius=0)
        self.pages["descriptive"] = page

        self._header(page, "📈  Analyse descriptive",
                      "Statistiques par variable qualitative et quantitative")

        # Onglets
        self.desc_tabs = ctk.CTkTabview(page, fg_color=C["card"],
                                         segmented_button_fg_color=C["header_bg"],
                                         segmented_button_selected_color=C["accent"],
                                         segmented_button_unselected_color=C["header_bg"],
                                         segmented_button_selected_hover_color=C["sidebar_hover"],
                                         text_color="white")
        self.desc_tabs.pack(fill='both', expand=True, padx=16, pady=12)
        self.desc_tabs.add("Qualitatives")
        self.desc_tabs.add("Quantitatives")

        self._build_qual_tab(self.desc_tabs.tab("Qualitatives"))
        self._build_quant_tab(self.desc_tabs.tab("Quantitatives"))

    def _build_qual_tab(self, tab):
        left = ctk.CTkFrame(tab, fg_color=C["bg"], width=220)
        left.pack(side='left', fill='y', padx=(0, 8), pady=8)
        left.pack_propagate(False)

        self._label(left, "Variable", bold=True).pack(anchor='w', pady=(8, 4), padx=8)
        self.qual_var = tk.StringVar()
        self.qual_combo = ctk.CTkComboBox(left, variable=self.qual_var,
                                           values=[], width=200,
                                           command=self._on_qual_select)
        self.qual_combo.pack(padx=8)

        ctk.CTkFrame(left, height=1, fg_color=C["border"]).pack(fill='x', padx=8, pady=12)
        self._label(left, "Graphique", bold=True).pack(anchor='w', pady=(0, 4), padx=8)
        self._btn(left, "Barres", lambda: self._show_qual_chart("bar"),
                   icon="📊", color=C["accent"], width=190).pack(padx=8, pady=4)
        self._btn(left, "Camembert", lambda: self._show_qual_chart("pie"),
                   icon="🥧", color=C["accent5"], width=190).pack(padx=8, pady=4)

        right = ctk.CTkFrame(tab, fg_color=C["bg"])
        right.pack(side='left', fill='both', expand=True, pady=8)

        card = self._card(right, "Tableau des modalités")
        card.pack(fill='both', expand=True)
        self.qual_table = DataTable(card)
        self.qual_table.pack(fill='both', expand=True, padx=8, pady=8, ipady=200)

    def _on_qual_select(self, choice=None):
        col = self.qual_var.get()
        if not col or self.data_mgr.df is None:
            return
        df = self.data_mgr.get_qualitative_stats(col)
        self.qual_table.load_dataframe(df)

    def _show_qual_chart(self, chart_type):
        col = self.qual_var.get()
        if not col or self.data_mgr.df is None:
            messagebox.showwarning("Attention", "Sélectionnez une variable qualitative.")
            return
        try:
            if chart_type == "bar":
                fig = ch.create_bar_chart(self.data_mgr.df, col)
            else:
                fig = ch.create_pie_chart(self.data_mgr.df, col)
            self._open_chart_window(fig, f"{chart_type.capitalize()} — {col}")
        except Exception as e:
            messagebox.showerror("Erreur graphique", str(e))

    def _build_quant_tab(self, tab):
        left = ctk.CTkFrame(tab, fg_color=C["bg"], width=220)
        left.pack(side='left', fill='y', padx=(0, 8), pady=8)
        left.pack_propagate(False)

        self._label(left, "Variable", bold=True).pack(anchor='w', pady=(8, 4), padx=8)
        self.quant_var = tk.StringVar()
        self.quant_combo = ctk.CTkComboBox(left, variable=self.quant_var,
                                            values=[], width=200,
                                            command=self._on_quant_select)
        self.quant_combo.pack(padx=8)

        ctk.CTkFrame(left, height=1, fg_color=C["border"]).pack(fill='x', padx=8, pady=12)
        self._label(left, "Graphique", bold=True).pack(anchor='w', pady=(0, 4), padx=8)
        self._btn(left, "Histogramme", lambda: self._show_quant_chart("hist"),
                   icon="📊", color=C["accent"], width=190).pack(padx=8, pady=4)
        self._btn(left, "Boxplot", lambda: self._show_quant_chart("box"),
                   icon="📦", color=C["accent2"], width=190).pack(padx=8, pady=4)

        right = ctk.CTkFrame(tab, fg_color=C["bg"])
        right.pack(side='left', fill='both', expand=True, pady=8)

        card = self._card(right, "Statistiques descriptives")
        card.pack(fill='both', expand=True)
        self.quant_table = DataTable(card)
        self.quant_table.pack(fill='both', expand=True, padx=8, pady=8, ipady=200)

    def _on_quant_select(self, choice=None):
        col = self.quant_var.get()
        if not col or self.data_mgr.df is None:
            return
        stats = self.data_mgr.get_quantitative_stats(col)
        if stats:
            df = pd.DataFrame(list(stats.items()), columns=["Statistique", "Valeur"])
            self.quant_table.load_dataframe(df)

    def _show_quant_chart(self, chart_type):
        col = self.quant_var.get()
        if not col or self.data_mgr.df is None:
            messagebox.showwarning("Attention", "Sélectionnez une variable quantitative.")
            return
        try:
            if chart_type == "hist":
                fig = ch.create_histogram(self.data_mgr.df, col)
            else:
                fig = ch.create_boxplot(self.data_mgr.df, col)
            self._open_chart_window(fig, f"{chart_type.capitalize()} — {col}")
        except Exception as e:
            messagebox.showerror("Erreur graphique", str(e))

    def _open_chart_window(self, fig, title):
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
        win = ctk.CTkToplevel(self)
        win.title(title)
        win.geometry("900x600")
        win.configure(fg_color=C["card"])

        canvas = FigureCanvasTkAgg(fig, master=win)
        canvas.draw()
        canvas.get_tk_widget().pack(fill='both', expand=True)
        toolbar = NavigationToolbar2Tk(canvas, win)
        toolbar.update()

    # ─────────────────────────────── PAGE : Groupes ──────────────────────────

    def _build_groups_page(self):
        page = ctk.CTkFrame(self.main_area, fg_color=C["bg"], corner_radius=0)
        self.pages["groups"] = page

        self._header(page, "🗂️  Gestion des groupes de variables",
                      "Créez des groupes thématiques pour l'analyse")

        paned = ctk.CTkFrame(page, fg_color=C["bg"])
        paned.pack(fill='both', expand=True, padx=16, pady=12)

        # Panneau gauche - Création
        left = ctk.CTkFrame(paned, fg_color=C["card"], corner_radius=10,
                             border_width=1, border_color=C["border"], width=300)
        left.pack(side='left', fill='y', padx=(0, 8))
        left.pack_propagate(False)

        hdr = ctk.CTkFrame(left, fg_color=C["accent"], corner_radius=8, height=36)
        hdr.pack(fill='x', padx=8, pady=(8, 4))
        hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text="Nouveau groupe",
                      font=ctk.CTkFont(size=11, weight="bold"),
                      text_color="white").pack(side='left', padx=10)

        inner = ctk.CTkFrame(left, fg_color="transparent")
        inner.pack(fill='both', expand=True, padx=10, pady=8)

        self._label(inner, "Nom du groupe :", bold=True).pack(anchor='w', pady=(4, 2))
        self.group_name_var = tk.StringVar()
        ctk.CTkEntry(inner, textvariable=self.group_name_var,
                      placeholder_text="Ex: Variables socio-démographiques",
                      font=ctk.CTkFont(size=11), height=36,
                      corner_radius=8).pack(fill='x', pady=(0, 8))

        self._label(inner, "Variables disponibles :", bold=True).pack(anchor='w', pady=(4, 2))
        self._label(inner, "Ctrl+clic pour sélection multiple",
                     color=C["text_secondary"], size=9).pack(anchor='w')

        list_frame = tk.Frame(inner, bg=C["bg"])
        list_frame.pack(fill='both', expand=True, pady=4)
        vsb = tk.Scrollbar(list_frame)
        vsb.pack(side='right', fill='y')
        self.var_listbox = tk.Listbox(list_frame, selectmode='multiple',
                                       yscrollcommand=vsb.set,
                                       bg=C["card"], fg=C["text"],
                                       selectbackground=C["accent"],
                                       selectforeground="white",
                                       font=('Segoe UI', 10),
                                       relief='flat', borderwidth=0,
                                       activestyle='none')
        self.var_listbox.pack(side='left', fill='both', expand=True)
        vsb.config(command=self.var_listbox.yview)

        btn_row = ctk.CTkFrame(inner, fg_color="transparent")
        btn_row.pack(fill='x', pady=8)
        self._btn(btn_row, "Créer", self._create_group,
                   icon="➕", color=C["accent2"], width=100).pack(side='left', padx=2)
        self._btn(btn_row, "Effacer", self._clear_group_form,
                   icon="🗑", color=C["accent3"], width=100).pack(side='left', padx=2)

        # Panneau droit - Liste des groupes + tableau
        right = ctk.CTkFrame(paned, fg_color=C["bg"])
        right.pack(side='left', fill='both', expand=True)

        # Liste groupes
        grp_card = self._card(right, "Groupes créés")
        grp_card.pack(fill='x', pady=(0, 8))
        grp_inner = ctk.CTkFrame(grp_card, fg_color="transparent")
        grp_inner.pack(fill='x', padx=10, pady=8)
        self.groups_frame = ctk.CTkScrollableFrame(grp_inner, fg_color="transparent",
                                                    height=100)
        self.groups_frame.pack(fill='x')
        self._label(grp_inner, "Aucun groupe créé.",
                     color=C["text_secondary"]).pack()
        self._no_group_label = grp_inner.winfo_children()[-1]

        # Tableau descriptif du groupe sélectionné
        desc_card = self._card(right, "Tableau descriptif du groupe")
        desc_card.pack(fill='both', expand=True)
        actions_row = ctk.CTkFrame(desc_card, fg_color="transparent")
        actions_row.pack(fill='x', padx=10, pady=4)
        self._label(actions_row, "Groupe affiché :").pack(side='left')
        self.grp_display_var = tk.StringVar(value="—")
        self.grp_display_combo = ctk.CTkComboBox(actions_row, variable=self.grp_display_var,
                                                   values=[], width=220,
                                                   command=self._show_group_table)
        self.grp_display_combo.pack(side='left', padx=8)

        self.group_desc_table = DataTable(desc_card)
        self.group_desc_table.pack(fill='both', expand=True, padx=8, pady=4, ipady=200)

    def _create_group(self):
        name = self.group_name_var.get().strip()
        if not name:
            messagebox.showwarning("Attention", "Donnez un nom au groupe.")
            return
        selected = [self.var_listbox.get(i) for i in self.var_listbox.curselection()]
        if not selected:
            messagebox.showwarning("Attention", "Sélectionnez au moins une variable.")
            return
        self.data_mgr.create_group(name, selected)
        self._refresh_groups_display()
        messagebox.showinfo("Groupe créé", f"Groupe « {name} » créé avec {len(selected)} variables.")

    def _clear_group_form(self):
        self.group_name_var.set("")
        self.var_listbox.selection_clear(0, 'end')

    def _refresh_groups_display(self):
        for w in self.groups_frame.winfo_children():
            w.destroy()

        groups = self.data_mgr.variable_groups
        if groups:
            self._no_group_label.pack_forget()
            for gname, gvars in groups.items():
                row = ctk.CTkFrame(self.groups_frame, fg_color="#EFF6FF",
                                    corner_radius=8, height=42)
                row.pack(fill='x', pady=3)
                row.pack_propagate(False)
                ctk.CTkLabel(row,
                              text=f"🗂️  {gname}   ({len(gvars)} vars : {', '.join(gvars[:3])}{'...' if len(gvars)>3 else ''})",
                              font=ctk.CTkFont(size=10), text_color=C["text"]).pack(side='left', padx=10)
                self._btn(row, "", lambda g=gname: self._delete_group(g),
                           icon="🗑", color=C["accent3"], width=36).pack(side='right', padx=4)
        else:
            self._no_group_label.pack()

        # Refresh combos
        group_names = list(groups.keys())
        self.grp_display_combo.configure(values=group_names)
        self._refresh_all_combos()

    def _delete_group(self, name):
        if messagebox.askyesno("Supprimer", f"Supprimer le groupe « {name} » ?"):
            self.data_mgr.delete_group(name)
            self._refresh_groups_display()

    def _show_group_table(self, choice=None):
        name = self.grp_display_var.get()
        if not name or name == "—":
            return
        df = self.data_mgr.get_group_descriptive_table(name)
        self.group_desc_table.load_dataframe(df)

    # ─────────────────────────────── PAGE : Bivariée ─────────────────────────

    def _build_bivariate_page(self):
        page = ctk.CTkFrame(self.main_area, fg_color=C["bg"], corner_radius=0)
        self.pages["bivariate"] = page

        self._header(page, "⚖️  Analyse bivariée",
                      "Tests statistiques entre la variable dépendante et les groupes")

        content = ctk.CTkFrame(page, fg_color=C["bg"])
        content.pack(fill='both', expand=True, padx=16, pady=12)

        # ── Paramètres ────────────────────────────────────────────────────────
        params_card = self._card(content, "Paramètres de l'analyse")
        params_card.pack(fill='x', pady=(0, 10))
        params_inner = ctk.CTkFrame(params_card, fg_color="transparent")
        params_inner.pack(fill='x', padx=16, pady=10)

        # Variable dépendante
        col1 = ctk.CTkFrame(params_inner, fg_color="transparent")
        col1.pack(side='left', padx=(0, 20))
        self._label(col1, "Variable dépendante", bold=True).pack(anchor='w', pady=(0, 4))
        self.dep_var = tk.StringVar()
        self.dep_combo = ctk.CTkComboBox(col1, variable=self.dep_var,
                                          values=[], width=220,
                                          font=ctk.CTkFont(size=11))
        self.dep_combo.pack()

        # Mode : un groupe ou tous les groupes
        col2 = ctk.CTkFrame(params_inner, fg_color="transparent")
        col2.pack(side='left', padx=(0, 20))
        self._label(col2, "Périmètre d'analyse", bold=True).pack(anchor='w', pady=(0, 4))
        self.biv_mode_var = tk.StringVar(value="all")
        mode_frame = ctk.CTkFrame(col2, fg_color="#EFF6FF", corner_radius=8)
        mode_frame.pack()
        ctk.CTkRadioButton(mode_frame, text="Tous les groupes",
                            variable=self.biv_mode_var, value="all",
                            font=ctk.CTkFont(size=11),
                            fg_color=C["accent2"],
                            command=self._on_biv_mode_change).pack(side='left', padx=10, pady=6)
        ctk.CTkRadioButton(mode_frame, text="Un seul groupe",
                            variable=self.biv_mode_var, value="one",
                            font=ctk.CTkFont(size=11),
                            fg_color=C["accent"],
                            command=self._on_biv_mode_change).pack(side='left', padx=10, pady=6)

        # Sélecteur de groupe (visible seulement en mode "un seul groupe")
        col3 = ctk.CTkFrame(params_inner, fg_color="transparent")
        col3.pack(side='left', padx=(0, 20))
        self.biv_group_label = self._label(col3, "Groupe à analyser", bold=True)
        self.biv_group_label.pack(anchor='w', pady=(0, 4))
        self.biv_group_var = tk.StringVar()
        self.biv_group_combo = ctk.CTkComboBox(col3, variable=self.biv_group_var,
                                                values=[], width=220,
                                                font=ctk.CTkFont(size=11))
        self.biv_group_combo.pack()
        self.biv_group_col = col3   # pour show/hide

        # Boutons lancer
        col4 = ctk.CTkFrame(params_inner, fg_color="transparent")
        col4.pack(side='left', pady=(18, 0))
        self._btn(col4, "Lancer l'analyse", self._run_bivariate,
                   icon="▶", color=C["accent2"], width=160).pack()

        # ── Légende ───────────────────────────────────────────────────────────
        legend_frame = ctk.CTkFrame(content, fg_color="#F8FAFC",
                                     corner_radius=8, border_width=1,
                                     border_color=C["border"])
        legend_frame.pack(fill='x', pady=(0, 8))
        leg_inner = ctk.CTkFrame(legend_frame, fg_color="transparent")
        leg_inner.pack(fill='x', padx=12, pady=6)

        legends = [
            ("Italique gris", "#64748B", "= Modalité de référence"),
            ("Vert gras",     "#15803D", "= OR [IC 95%]"),
            ("Bleu marine",   "#1E3A5F", "= p-value (affiché sur la 1ère ligne)"),
            ("n(%)",          "#1E293B", "= Effectif et pourcentage dans chaque groupe"),
        ]
        for label, color, desc in legends:
            pill = tk.Label(leg_inner, text=f"  {label}  ", font=("Segoe UI", 8, "italic"),
                             bg=color, fg="white", relief='flat', padx=4)
            pill.pack(side='left', padx=(0, 2))
            tk.Label(leg_inner, text=desc + "    ", font=("Segoe UI", 8),
                      bg="#F8FAFC", fg="#475569").pack(side='left')

        # ── Tableau résultats ─────────────────────────────────────────────────
        res_card = self._card(content, "Tableau de l'analyse bivariée — Format publication")
        res_card.pack(fill='both', expand=True)

        # Info bar
        self.biv_info_bar = ctk.CTkFrame(res_card, fg_color="transparent")
        self.biv_info_bar.pack(fill='x', padx=8, pady=(4, 0))
        self.biv_info_label = self._label(self.biv_info_bar,
                                           "Lancez une analyse pour afficher les résultats.",
                                           color=C["text_secondary"], size=9)
        self.biv_info_label.pack(side='left')

        # Export rapide
        self._btn(self.biv_info_bar, "Export Excel", self._export_biv_excel,
                   icon="📊", color=C["accent2"], width=130).pack(side='right', padx=4)
        self._btn(self.biv_info_bar, "Export Word", self._export_biv_word,
                   icon="📄", color=C["accent5"], width=130).pack(side='right', padx=4)

        # Tableau publication
        table_frame = tk.Frame(res_card, bg="#FFFFFF",
                                relief='flat', bd=0)
        table_frame.pack(fill='both', expand=True, padx=8, pady=8)

        self.biv_pub_table = BivariateTable(table_frame)
        self.biv_pub_table.pack(fill='both', expand=True)

    def _on_biv_mode_change(self):
        """Affiche/masque le sélecteur de groupe selon le mode."""
        if self.biv_mode_var.get() == "all":
            self.biv_group_col.pack_forget()
        else:
            self.biv_group_col.pack(side='left', padx=(0, 20),
                                     before=self.biv_group_col.master.winfo_children()[-1])

    def _run_bivariate(self):
        dep = self.dep_var.get()
        mode = self.biv_mode_var.get()

        if not dep:
            messagebox.showwarning("Attention", "Sélectionnez une variable dépendante.")
            return
        if not self.data_mgr.variable_groups:
            messagebox.showwarning("Attention", "Aucun groupe de variables défini.")
            return

        try:
            if mode == "all":
                # ── Tous les groupes ──────────────────────────────────────────
                results = self.data_mgr.bivariate_analysis_all_groups(dep)
                scope_label = f"Tous les groupes ({len(self.data_mgr.variable_groups)})"
            else:
                # ── Un seul groupe ────────────────────────────────────────────
                grp = self.biv_group_var.get()
                if not grp or grp not in self.data_mgr.variable_groups:
                    messagebox.showwarning("Attention", "Sélectionnez un groupe valide.")
                    return
                results = self.data_mgr.bivariate_analysis(dep, grp)
                # Ajouter la ligne de section pour ce groupe
                if results:
                    dep_cats = results[0].get("__dep_cats__", [])
                    results.insert(0, {
                        "Variable": grp,
                        "__is_section__": True,
                        "__is_ref__": False,
                        "__var_first_row__": False,
                        "__dep_cats__": dep_cats,
                    })
                scope_label = f"Groupe : {grp}"

            if not results:
                messagebox.showinfo("Résultat", "Aucun résultat disponible.")
                return

            self.last_bivariate_results = results
            self.biv_pub_table.load_results(results, dep_var=dep)

            n_vars = sum(1 for r in results if r.get("__var_first_row__", False))
            n_sig  = sum(1 for r in results
                         if r.get("__var_first_row__") and
                         self._is_significant(r.get("p", "")))

            self.biv_info_label.configure(
                text=(f"✅  {n_vars} variable(s) — {n_sig} significative(s) (p<0,05)   |   "
                      f"Variable dépendante : {dep}   |   {scope_label}"),
                text_color=C["accent2"]
            )

        except Exception as e:
            messagebox.showerror("Erreur d'analyse", str(e))

    @staticmethod
    def _is_significant(p_str: str) -> bool:
        """Vérifie si la p-value est < 0.05."""
        if not p_str or p_str in ("—", ""):
            return False
        p_str = p_str.replace(",", ".")
        if p_str.startswith("<"):
            return True
        try:
            return float(p_str) < 0.05
        except ValueError:
            return False

    def _export_biv_excel(self):
        self._quick_export("excel", {
            "completeness": False, "descriptive": False,
            "groups": False, "bivariate": True,
            "bivariate_data": self.last_bivariate_results
        })

    def _export_biv_word(self):
        self._quick_export("word", {
            "completeness": False, "descriptive": False,
            "groups": False, "bivariate": True,
            "bivariate_data": self.last_bivariate_results
        })

    # ─────────────────────────────── PAGE : Export ───────────────────────────

    def _build_export_page(self):
        page = ctk.CTkFrame(self.main_area, fg_color=C["bg"], corner_radius=0)
        self.pages["export"] = page

        self._header(page, "💾  Exportation des résultats",
                      "Générez un rapport complet au format Excel ou Word")

        content = ctk.CTkScrollableFrame(page, fg_color=C["bg"], corner_radius=0)
        content.pack(fill='both', expand=True, padx=16, pady=12)

        # Sélection du contenu
        sel_card = self._card(content, "Contenu à exporter")
        sel_card.pack(fill='x', pady=(0, 12))
        sel_inner = ctk.CTkFrame(sel_card, fg_color="transparent")
        sel_inner.pack(fill='x', padx=16, pady=12)

        self.exp_completeness = tk.BooleanVar(value=True)
        self.exp_descriptive = tk.BooleanVar(value=True)
        self.exp_groups = tk.BooleanVar(value=True)
        self.exp_bivariate = tk.BooleanVar(value=True)

        checkboxes = [
            (self.exp_completeness, "📋  Analyse de complétude"),
            (self.exp_descriptive, "📈  Statistiques descriptives"),
            (self.exp_groups, "🗂️  Tableaux par groupes"),
            (self.exp_bivariate, "⚖️  Résultats bivariés"),
        ]
        for var, text in checkboxes:
            ctk.CTkCheckBox(sel_inner, text=text, variable=var,
                             font=ctk.CTkFont(size=11),
                             fg_color=C["accent"],
                             hover_color=C["sidebar_hover"]).pack(anchor='w', pady=4)

        # Boutons export
        exp_card = self._card(content, "Formats d'exportation")
        exp_card.pack(fill='x', pady=(0, 12))
        exp_inner = ctk.CTkFrame(exp_card, fg_color="transparent")
        exp_inner.pack(fill='x', padx=16, pady=16)

        # Excel
        excel_frame = ctk.CTkFrame(exp_inner, fg_color="#F0FDF4",
                                    corner_radius=10, border_width=1,
                                    border_color="#86EFAC")
        excel_frame.pack(side='left', fill='both', expand=True, padx=(0, 8))
        ctk.CTkLabel(excel_frame, text="📊",
                      font=ctk.CTkFont(size=36)).pack(pady=(16, 4))
        ctk.CTkLabel(excel_frame, text="Export Excel",
                      font=ctk.CTkFont(size=13, weight="bold"),
                      text_color="#15803D").pack()
        ctk.CTkLabel(excel_frame, text="Fichier .xlsx formaté\navec feuilles thématiques",
                      font=ctk.CTkFont(size=10), text_color=C["text_secondary"]).pack(pady=4)
        self._btn(excel_frame, "Exporter en Excel", self._export_full_excel,
                   color=C["accent2"], icon="💾", width=180).pack(pady=(8, 16))

        # Word
        word_frame = ctk.CTkFrame(exp_inner, fg_color="#EFF6FF",
                                   corner_radius=10, border_width=1,
                                   border_color="#93C5FD")
        word_frame.pack(side='left', fill='both', expand=True, padx=(8, 0))
        ctk.CTkLabel(word_frame, text="📄",
                      font=ctk.CTkFont(size=36)).pack(pady=(16, 4))
        ctk.CTkLabel(word_frame, text="Export Word",
                      font=ctk.CTkFont(size=13, weight="bold"),
                      text_color="#1D4ED8").pack()
        ctk.CTkLabel(word_frame, text="Document .docx prêt\npour publication / mémoire",
                      font=ctk.CTkFont(size=10), text_color=C["text_secondary"]).pack(pady=4)
        self._btn(word_frame, "Exporter en Word", self._export_full_word,
                   color=C["accent"], icon="💾", width=180).pack(pady=(8, 16))

        # Log
        log_card = self._card(content, "Journal des exports")
        log_card.pack(fill='x')
        self.export_log = ctk.CTkTextbox(log_card, height=100,
                                          font=ctk.CTkFont(family="Consolas", size=10),
                                          fg_color="#F8FAFC",
                                          text_color=C["text"])
        self.export_log.pack(fill='x', padx=8, pady=8)
        self.export_log.insert('end', "Prêt pour l'exportation...\n")
        self.export_log.configure(state='disabled')

    def _get_export_selections(self):
        # Pour l'export, l'analyse bivariée couvre toujours TOUS les groupes
        # si une variable dépendante est définie, sinon on utilise last_bivariate_results
        dep = self.dep_var.get() if hasattr(self, 'dep_var') else ""
        if (self.exp_bivariate.get() and dep and
                self.data_mgr.df is not None and self.data_mgr.variable_groups):
            biv_data = self.data_mgr.bivariate_analysis_all_groups(dep)
        else:
            biv_data = self.last_bivariate_results
        return {
            "completeness": self.exp_completeness.get(),
            "descriptive":  self.exp_descriptive.get(),
            "groups":       self.exp_groups.get(),
            "bivariate":    self.exp_bivariate.get(),
            "bivariate_data": biv_data,
        }

    def _export_full_excel(self):
        if self.data_mgr.df is None:
            messagebox.showwarning("Attention", "Aucune donnée chargée.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx")],
            title="Enregistrer le rapport Excel",
            initialfile="rapport_statistique.xlsx"
        )
        if not path:
            return
        try:
            from export.exporter import export_excel
            export_excel(self.data_mgr, path, self._get_export_selections())
            self._log(f"✅ Excel exporté : {path}")
            messagebox.showinfo("Succès", f"Rapport Excel enregistré :\n{path}")
        except Exception as e:
            self._log(f"❌ Erreur : {e}")
            messagebox.showerror("Erreur d'export", str(e))

    def _export_full_word(self):
        if self.data_mgr.df is None:
            messagebox.showwarning("Attention", "Aucune donnée chargée.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".docx",
            filetypes=[("Word", "*.docx")],
            title="Enregistrer le rapport Word",
            initialfile="rapport_statistique.docx"
        )
        if not path:
            return
        try:
            from export.exporter import export_word
            export_word(self.data_mgr, path, self._get_export_selections())
            self._log(f"✅ Word exporté : {path}")
            messagebox.showinfo("Succès", f"Rapport Word enregistré :\n{path}")
        except Exception as e:
            self._log(f"❌ Erreur : {e}")
            messagebox.showerror("Erreur d'export", str(e))

    def _quick_export(self, fmt: str, selections: dict):
        if self.data_mgr.df is None:
            messagebox.showwarning("Attention", "Aucune donnée chargée.")
            return
        ext = ".xlsx" if fmt == "excel" else ".docx"
        ftype = [("Excel", "*.xlsx")] if fmt == "excel" else [("Word", "*.docx")]
        path = filedialog.asksaveasfilename(defaultextension=ext, filetypes=ftype)
        if not path:
            return
        try:
            if fmt == "excel":
                from export.exporter import export_excel
                export_excel(self.data_mgr, path, selections)
            else:
                from export.exporter import export_word
                export_word(self.data_mgr, path, selections)
            messagebox.showinfo("Succès", f"Fichier enregistré :\n{path}")
        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    def _log(self, msg: str):
        self.export_log.configure(state='normal')
        self.export_log.insert('end', msg + "\n")
        self.export_log.see('end')
        self.export_log.configure(state='disabled')

    # ─── Rafraîchissement global des combos ──────────────────────────────────

    def _refresh_all_combos(self):
        if self.data_mgr.df is None:
            return
        all_vars = list(self.data_mgr.df.columns)
        qual = self.data_mgr.qualitative_vars
        quant = self.data_mgr.quantitative_vars
        groups = list(self.data_mgr.variable_groups.keys())

        self.qual_combo.configure(values=qual)
        if qual:
            self.qual_combo.set(qual[0])
            self._on_qual_select()

        self.quant_combo.configure(values=quant)
        if quant:
            self.quant_combo.set(quant[0])
            self._on_quant_select()

        self.dep_combo.configure(values=all_vars)
        if all_vars:
            self.dep_combo.set(all_vars[0])

        self.biv_group_combo.configure(values=groups)
        if groups:
            self.biv_group_combo.set(groups[0])

        self.grp_display_combo.configure(values=groups)

        # Remplir la listbox des variables
        self.var_listbox.delete(0, 'end')
        for v in all_vars:
            label = f"{v}  [{'Q' if v in quant else 'C'}]"
            self.var_listbox.insert('end', v)

    # ─────────────────────────────── PAGE : Dossier patient ──────────────────

    def _build_dossier_page(self):
        """Intègre la page dossier clinique diabétique."""
        page = DossierPatientPage(self.main_area)
        self.pages["dossier"] = page
