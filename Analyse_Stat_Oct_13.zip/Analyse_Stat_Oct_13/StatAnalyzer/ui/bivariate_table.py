"""
Widget tableau bivariée — Format publication médicale
Reproduit exactement le format : Variable | Modalité | Oui n(%) | Non n(%) | Total n(%) | p | Test/OR [IC 95%]
"""

import tkinter as tk
from tkinter import ttk
import customtkinter as ctk

# ─── Palette ──────────────────────────────────────────────────────────────────
HEADER_BG  = "#2E7D52"   # vert foncé entête
HEADER_FG  = "#FFFFFF"
SUBHDR_BG  = "#4E9E72"   # vert moyen sous-section
ROW_ODD    = "#FFFFFF"
ROW_EVEN   = "#F0FDF6"   # vert très pâle
REF_FG     = "#64748B"   # gris italique (modalité de référence)
OR_FG      = "#15803D"   # vert vif pour les OR
PVAL_FG    = "#1E3A5F"   # bleu marine pour la p-value
VAR_FG     = "#1E293B"   # texte variable (gras)
BORDER_CLR = "#CBD5E1"
FONT_BODY  = ("Segoe UI", 9)
FONT_BOLD  = ("Segoe UI", 9, "bold")
FONT_ITAL  = ("Segoe UI", 9, "italic")
FONT_HDR   = ("Segoe UI", 9, "bold")


class BivariateTable(tk.Frame):
    """
    Tableau de résultats bivariés au format publication médicale.
    Prend en entrée la liste de dicts retournée par data_manager.bivariate_analysis().
    """

    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg="#FFFFFF", **kwargs)
        self._results = []
        self._canvas = None
        self._inner = None
        self._build_shell()

    # ──────────────────────────────────────────────────────────────────────────
    # Construction du shell scrollable
    # ──────────────────────────────────────────────────────────────────────────

    def _build_shell(self):
        # Scrollbars
        vsb = ttk.Scrollbar(self, orient='vertical')
        hsb = ttk.Scrollbar(self, orient='horizontal')
        vsb.pack(side='right', fill='y')
        hsb.pack(side='bottom', fill='x')

        self._canvas = tk.Canvas(self, bg="#FFFFFF",
                                  yscrollcommand=vsb.set,
                                  xscrollcommand=hsb.set,
                                  highlightthickness=0)
        self._canvas.pack(fill='both', expand=True)

        vsb.config(command=self._canvas.yview)
        hsb.config(command=self._canvas.xview)

        self._inner = tk.Frame(self._canvas, bg="#FFFFFF")
        self._win_id = self._canvas.create_window((0, 0), window=self._inner, anchor='nw')

        self._inner.bind('<Configure>', self._on_inner_configure)
        self._canvas.bind('<Configure>', self._on_canvas_configure)
        self._canvas.bind_all('<MouseWheel>', self._on_mousewheel)

    def _on_inner_configure(self, event=None):
        self._canvas.configure(scrollregion=self._canvas.bbox('all'))

    def _on_canvas_configure(self, event=None):
        self._canvas.itemconfig(self._win_id, width=event.width)

    def _on_mousewheel(self, event):
        self._canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')

    # ──────────────────────────────────────────────────────────────────────────
    # Chargement des données
    # ──────────────────────────────────────────────────────────────────────────

    def load_results(self, results: list, dep_var: str = ""):
        """Affiche les résultats au format publication."""
        # Vider l'inner frame
        for w in self._inner.winfo_children():
            w.destroy()

        if not results:
            tk.Label(self._inner, text="Aucun résultat.",
                     font=FONT_BODY, bg="#FFFFFF", fg=REF_FG).pack(pady=20)
            return

        self._results = results
        dep_cats = results[0].get("__dep_cats__", [])

        # ── Construire les colonnes dynamiquement ─────────────────────────────
        # Colonnes fixes : Variable | Modalité | [dep_cats...] | Total n(%) | p | Test/OR [IC 95%]
        cols_dep = [str(c) for c in dep_cats]

        # Largeurs en pixels (approximatif)
        col_widths = {
            "Variable":          140,
            "Modalité":          120,
            "Total n(%)":        100,
            "p":                  72,
            "Test / OR [IC 95%]": 170,
        }
        for c in cols_dep:
            col_widths[c] = 110

        col_order = ["Variable", "Modalité"] + cols_dep + ["Total n(%)", "p", "Test / OR [IC 95%]"]

        # ── En-tête principal ─────────────────────────────────────────────────
        self._draw_header(col_order, col_widths, dep_var, dep_cats)

        # ── Lignes de données ─────────────────────────────────────────────────
        row_idx = 0
        current_section = None

        for res in results:
            is_section = res.get("__is_section__", False)
            is_ref     = res.get("__is_ref__", False)
            is_first   = res.get("__var_first_row__", False)
            var_name   = res.get("Variable", "")

            # Ligne de sous-section (titre de groupe)
            if is_section:
                self._draw_section_row(res.get("Variable", ""), col_order, col_widths)
                current_section = var_name
                continue

            bg = ROW_ODD if row_idx % 2 == 0 else ROW_EVEN
            self._draw_data_row(res, col_order, col_widths, bg, is_ref, is_first)
            row_idx += 1

        self._on_inner_configure()

    # ──────────────────────────────────────────────────────────────────────────
    # Dessin des rangées
    # ──────────────────────────────────────────────────────────────────────────

    def _draw_header(self, col_order, col_widths, dep_var, dep_cats):
        """Deux rangées d'en-têtes : ligne 1 globale, ligne 2 colonnes."""

        # Rangée 1 : titre des colonnes dépendantes (fusionnées)
        row1 = tk.Frame(self._inner, bg=HEADER_BG)
        row1.pack(fill='x')

        for col in col_order:
            if col in ("Variable", "Modalité"):
                lbl_text = col
                span_w = col_widths[col]
                rows = 2  # rowspan visuel simulé par height
                fg = HEADER_FG
            elif col in [str(c) for c in dep_cats]:
                # on affichera "Oui n(%)" etc. dans la rangée 2 uniquement
                lbl_text = f"{dep_var}" if col == str(dep_cats[0]) else ""
                span_w = col_widths[col]
                fg = HEADER_FG
            elif col == "Total n(%)":
                lbl_text = "Total n(%)"
                span_w = col_widths[col]
                fg = HEADER_FG
            elif col == "p":
                lbl_text = "p"
                span_w = col_widths[col]
                fg = HEADER_FG
            else:
                lbl_text = "Test / OR [IC 95%]"
                span_w = col_widths[col]
                fg = HEADER_FG

            tk.Label(row1, text=lbl_text,
                     font=FONT_HDR, bg=HEADER_BG, fg=fg,
                     width=span_w // 8,
                     relief='flat', bd=0,
                     anchor='center', wraplength=span_w - 8,
                     padx=6, pady=5).pack(side='left',
                                           ipadx=0, ipady=0)
            # Séparateur vertical léger
            tk.Frame(row1, bg="#1E6040", width=1).pack(side='left', fill='y')

        # Rangée 2 : noms des catégories de la variable dépendante
        row2 = tk.Frame(self._inner, bg=HEADER_BG)
        row2.pack(fill='x')

        for col in col_order:
            if col == "Variable":
                txt = ""
            elif col == "Modalité":
                txt = "Modalité"
            elif col in [str(c) for c in dep_cats]:
                txt = f"{col} n(%)"
            elif col == "Total n(%)":
                txt = "Total n(%)"
            elif col == "p":
                txt = "p"
            else:
                txt = "Test / OR [IC 95%]"

            w = col_widths[col]
            tk.Label(row2, text=txt,
                     font=FONT_HDR, bg=HEADER_BG, fg=HEADER_FG,
                     width=w // 8,
                     relief='flat', bd=0,
                     anchor='center', wraplength=w - 8,
                     padx=6, pady=4).pack(side='left')
            tk.Frame(row2, bg="#1E6040", width=1).pack(side='left', fill='y')

        # Trait séparateur
        tk.Frame(self._inner, bg=BORDER_CLR, height=1).pack(fill='x')

    def _draw_section_row(self, title: str, col_order, col_widths):
        """Ligne de titre de sous-section (ex: '1.1 Caractéristiques socio-démographiques')."""
        total_w = sum(col_widths[c] for c in col_order)
        row = tk.Frame(self._inner, bg=SUBHDR_BG)
        row.pack(fill='x')
        tk.Label(row, text=f"  {title}",
                 font=("Segoe UI", 9, "bold"), bg=SUBHDR_BG, fg=HEADER_FG,
                 anchor='w', padx=8, pady=4).pack(side='left', fill='x', expand=True)
        tk.Frame(self._inner, bg=BORDER_CLR, height=1).pack(fill='x')

    def _draw_data_row(self, res: dict, col_order, col_widths, bg: str,
                        is_ref: bool, is_first: bool):
        """Ligne de données avec mise en forme conditionnelle."""

        row_frame = tk.Frame(self._inner, bg=bg)
        row_frame.pack(fill='x')

        for col in col_order:
            val = res.get(col, "")
            w = col_widths[col]

            # ── Formatage conditionnel ────────────────────────────────────────
            if col == "Variable":
                # Nom de la variable : gras sur la première ligne
                lbl = tk.Label(row_frame, text=str(val) if is_first else "",
                                font=FONT_BOLD if is_first else FONT_BODY,
                                bg=bg, fg=VAR_FG,
                                anchor='w', padx=8, pady=3,
                                width=w // 8, wraplength=w - 12)

            elif col == "Modalité":
                # Modalité de référence en italique gris
                font = FONT_ITAL if is_ref else FONT_BODY
                fg   = REF_FG   if is_ref else VAR_FG
                txt  = str(val)
                lbl = tk.Label(row_frame, text=txt,
                                font=font, bg=bg, fg=fg,
                                anchor='w', padx=8, pady=3,
                                width=w // 8, wraplength=w - 12)

            elif col == "p":
                # p-value en gras bleu marine si non vide
                txt = str(val) if val else ""
                font = ("Segoe UI", 9, "bold") if txt else FONT_BODY
                fg   = PVAL_FG if txt else VAR_FG
                lbl = tk.Label(row_frame, text=txt,
                                font=font, bg=bg, fg=fg,
                                anchor='center', padx=4, pady=3,
                                width=w // 8)

            elif col == "Test / OR [IC 95%]":
                txt = str(val) if val else ""
                # "Réf." en gris italique, OR en vert gras
                if txt == "Réf.":
                    font, fg = FONT_ITAL, REF_FG
                elif txt and txt not in ("—", ""):
                    font, fg = ("Segoe UI", 9, "bold"), OR_FG
                else:
                    font, fg = FONT_BODY, VAR_FG
                lbl = tk.Label(row_frame, text=txt,
                                font=font, bg=bg, fg=fg,
                                anchor='center', padx=4, pady=3,
                                width=w // 8, wraplength=w - 8)

            else:
                # Colonnes n(%) : centré
                lbl = tk.Label(row_frame, text=str(val) if val else "",
                                font=FONT_BODY, bg=bg, fg=VAR_FG,
                                anchor='center', padx=4, pady=3,
                                width=w // 8)

            lbl.pack(side='left')
            tk.Frame(row_frame, bg=BORDER_CLR, width=1).pack(side='left', fill='y')

        # Trait séparateur horizontal fin
        tk.Frame(self._inner, bg=BORDER_CLR, height=1).pack(fill='x')
