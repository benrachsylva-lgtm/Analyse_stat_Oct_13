"""
Page UI — Dossier clinique patient diabétique
Formulaire complet organisé en sections avec onglets
"""

import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, filedialog
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.patient_diabete import (
    PatientDiabete, calculer_imc, interpreter_imc,
    interpreter_hba1c, interpreter_pa, interpreter_glycemie_jeun,
    interpreter_dfg, calculer_age, calculer_duree_diabete,
    score_risque_cardiovasculaire, exporter_dossier_word
)

C = {
    "bg":         "#F0F4F8",
    "card":       "#FFFFFF",
    "border":     "#CBD5E1",
    "header_bg":  "#1E3A5F",
    "accent":     "#2563EB",
    "accent2":    "#16A34A",
    "accent3":    "#DC2626",
    "accent4":    "#D97706",
    "accent5":    "#7C3AED",
    "accent6":    "#0891B2",
    "text":       "#1E293B",
    "text2":      "#64748B",
    "ok":         "#DCFCE7",
    "warn":       "#FEF3C7",
    "danger":     "#FEE2E2",
    "info":       "#EFF6FF",
}

SEC = {                  # couleur par section
    "identite":    "#1E3A5F",
    "antecedents": "#7C3AED",
    "traitement":  "#7C3AED",
    "clinique":    "#0891B2",
    "biologie":    "#DC2626",
    "paraclinique":"#16A34A",
    "synthese":    "#1E3A5F",
}


class EntryLabeled(ctk.CTkFrame):
    """Champ label + entry dans un cadre horizontal."""
    def __init__(self, parent, label, var=None, width=180, placeholder="", **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        ctk.CTkLabel(self, text=label,
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"], width=170, anchor="e").pack(side='left', padx=(0,6))
        self.var = var or tk.StringVar()
        ctk.CTkEntry(self, textvariable=self.var, width=width,
                      placeholder_text=placeholder,
                      font=ctk.CTkFont("Segoe UI", 10),
                      corner_radius=6, height=30).pack(side='left')

    def get(self): return self.var.get()
    def set(self, v): self.var.set(v)


class CheckRow(ctk.CTkFrame):
    """Ligne de checkboxes côte à côte."""
    def __init__(self, parent, label, items: list, color="#2563EB", **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        ctk.CTkLabel(self, text=label,
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"], width=170, anchor="e").pack(side='left', padx=(0,6))
        self.vars = {}
        for name in items:
            v = tk.BooleanVar()
            ctk.CTkCheckBox(self, text=name, variable=v,
                             font=ctk.CTkFont("Segoe UI", 9),
                             fg_color=color, hover_color="#1E3A5F",
                             checkbox_width=16, checkbox_height=16,
                             corner_radius=4).pack(side='left', padx=5)
            self.vars[name] = v

    def get(self): return {k: v.get() for k, v in self.vars.items()}


class ComboLabeled(ctk.CTkFrame):
    def __init__(self, parent, label, values, var=None, width=200, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        ctk.CTkLabel(self, text=label,
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"], width=170, anchor="e").pack(side='left', padx=(0,6))
        self.var = var or tk.StringVar()
        ctk.CTkComboBox(self, variable=self.var, values=values,
                         width=width, font=ctk.CTkFont("Segoe UI", 10),
                         corner_radius=6, height=30).pack(side='left')

    def get(self): return self.var.get()
    def set(self, v): self.var.set(v)


class InterprCard(ctk.CTkFrame):
    """Carte d'interprétation colorée."""
    def __init__(self, parent, label, **kwargs):
        super().__init__(parent, fg_color="#F8FAFC", corner_radius=8,
                          border_width=1, border_color=C["border"], **kwargs)
        self._lbl = ctk.CTkLabel(self, text=label,
                                  font=ctk.CTkFont("Segoe UI", 9, weight="bold"),
                                  text_color=C["text2"])
        self._lbl.pack(side='left', padx=8)
        self._val = ctk.CTkLabel(self, text="—",
                                  font=ctk.CTkFont("Segoe UI", 9),
                                  text_color=C["text"])
        self._val.pack(side='left', padx=4)

    def update(self, text, color="#1E293B"):
        self._val.configure(text=text, text_color=color)
        self.configure(fg_color=color + "15" if len(color) == 7 else "#F8FAFC")


# ─────────────────────────────────────────────────────────────────────────────

class DossierPatientPage(ctk.CTkFrame):
    """Page complète du dossier clinique patient diabétique."""

    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color=C["bg"], corner_radius=0, **kwargs)
        self._patient = PatientDiabete()
        self._build()

    # ──────────────────────────────────────────────────────────────
    # Build principal
    # ──────────────────────────────────────────────────────────────

    def _build(self):
        # ── En-tête page ──────────────────────────────────────────
        hdr = ctk.CTkFrame(self, fg_color=C["header_bg"], corner_radius=0, height=64)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text="🩺  Dossier Clinique — Patient Diabétique",
                      font=ctk.CTkFont("Segoe UI", 15, weight="bold"),
                      text_color="white").pack(side='left', padx=20, pady=12)
        ctk.CTkLabel(hdr, text="Formulaire complet de suivi — Paramètres cliniques, biologiques & paracliniques",
                      font=ctk.CTkFont("Segoe UI", 9),
                      text_color="#94A3B8").pack(side='left', padx=4)

        # ── Barre d'actions ───────────────────────────────────────
        bar = ctk.CTkFrame(self, fg_color=C["card"],
                            border_width=1, border_color=C["border"],
                            corner_radius=0, height=50)
        bar.pack(fill='x')
        bar.pack_propagate(False)

        def _btn(txt, cmd, color, icon="", w=150):
            return ctk.CTkButton(bar, text=f"{icon} {txt}", command=cmd,
                                  fg_color=color, hover_color="#1E3A5F",
                                  font=ctk.CTkFont("Segoe UI", 11),
                                  corner_radius=8, height=34, width=w)

        _btn("Nouveau dossier", self._nouveau, "#475569", icon="📄", w=160).pack(side='left', padx=8, pady=8)
        _btn("Calculer / Actualiser", self._actualiser, C["accent"], icon="🔄", w=180).pack(side='left', padx=4)
        _btn("Exporter Word",  self._exporter_word, C["accent3"], icon="📄", w=150).pack(side='right', padx=8)
        _btn("Exporter Excel", self._exporter_excel, C["accent2"], icon="📊", w=150).pack(side='right', padx=4)

        # ── Tableau de bord synthèse (bandeau supérieur) ──────────
        self._bord_frame = ctk.CTkFrame(self, fg_color=C["info"],
                                         border_width=1, border_color="#BFDBFE",
                                         corner_radius=0, height=56)
        self._bord_frame.pack(fill='x')
        self._bord_frame.pack_propagate(False)
        self._build_bord()

        # ── Onglets ───────────────────────────────────────────────
        self._tabs = ctk.CTkTabview(
            self,
            fg_color=C["card"],
            segmented_button_fg_color=C["header_bg"],
            segmented_button_selected_color=C["accent"],
            segmented_button_unselected_color=C["header_bg"],
            segmented_button_selected_hover_color="#1D4ED8",
            text_color="white",
        )
        self._tabs.pack(fill='both', expand=True, padx=12, pady=8)

        tab_names = [
            "👤 Identité",
            "📋 Antécédents",
            "💊 Traitement",
            "🩺 Clinique",
            "🔬 Biologie",
            "📡 Paraclinique",
            "📝 Synthèse",
        ]
        for t in tab_names:
            self._tabs.add(t)

        self._build_tab_identite(self._tabs.tab("👤 Identité"))
        self._build_tab_antecedents(self._tabs.tab("📋 Antécédents"))
        self._build_tab_traitement(self._tabs.tab("💊 Traitement"))
        self._build_tab_clinique(self._tabs.tab("🩺 Clinique"))
        self._build_tab_biologie(self._tabs.tab("🔬 Biologie"))
        self._build_tab_paraclinique(self._tabs.tab("📡 Paraclinique"))
        self._build_tab_synthese(self._tabs.tab("📝 Synthèse"))

    # ── Bandeau synthèse ──────────────────────────────────────────

    def _build_bord(self):
        for w in self._bord_frame.winfo_children():
            w.destroy()
        indicators = [
            ("IMC",       "imc_bord"),
            ("HbA1c",     "hba1c_bord"),
            ("TA",        "ta_bord"),
            ("DFG",       "dfg_bord"),
            ("Risque CV", "cv_bord"),
        ]
        for label, attr in indicators:
            pill = ctk.CTkFrame(self._bord_frame, fg_color="#DBEAFE",
                                 corner_radius=20, height=36)
            pill.pack(side='left', padx=8, pady=10)
            pill.pack_propagate(False)
            lbl_txt = ctk.CTkLabel(pill,
                                    text=f"{label} : —",
                                    font=ctk.CTkFont("Segoe UI", 9, weight="bold"),
                                    text_color=C["accent"])
            lbl_txt.pack(padx=12, pady=6)
            setattr(self, attr, lbl_txt)

    def _update_bord(self):
        """Recalcule et met à jour le bandeau synthèse."""
        p = self._collect_patient()

        # IMC
        imc = calculer_imc(p.poids, p.taille) if p.poids and p.taille else None
        if imc:
            interp = interpreter_imc(imc)
            color = "#16A34A" if imc < 25 else ("#D97706" if imc < 30 else "#DC2626")
            self.imc_bord.configure(text=f"IMC : {imc}  ({interp[:12]}…)" if len(interp)>12 else f"IMC : {imc}  ({interp})",
                                     text_color=color)

        # HbA1c
        if p.hba1c:
            ih, c = interpreter_hba1c(p.hba1c)
            self.hba1c_bord.configure(text=f"HbA1c : {p.hba1c}%  ({ih[:18]}…)" if len(ih)>18 else f"HbA1c : {p.hba1c}%  ({ih})",
                                       text_color=c)

        # TA
        if p.pa_systolique and p.pa_diastolique:
            ipa, c = interpreter_pa(p.pa_systolique, p.pa_diastolique)
            self.ta_bord.configure(text=f"TA : {p.pa_systolique}/{p.pa_diastolique}  ({ipa[:14]}…)" if len(ipa)>14 else f"TA : {p.pa_systolique}/{p.pa_diastolique}  ({ipa})",
                                    text_color=c)

        # DFG
        if p.dfg:
            idfg, c = interpreter_dfg(p.dfg)
            self.dfg_bord.configure(text=f"DFG : {p.dfg}  ({idfg[:12]}…)" if len(idfg)>12 else f"DFG : {p.dfg}  ({idfg})",
                                     text_color=c)

        # Risque CV
        score, niveau, c = score_risque_cardiovasculaire(p)
        self.cv_bord.configure(text=f"Risque CV : {niveau} ({score}/10)", text_color=c)

    # ──────────────────────────────────────────────────────────────
    # ONGLET 1 — Identité
    # ──────────────────────────────────────────────────────────────

    def _build_tab_identite(self, tab):
        sc = ctk.CTkScrollableFrame(tab, fg_color=C["bg"])
        sc.pack(fill='both', expand=True)
        self._sec_title(sc, "👤  Informations administratives", SEC["identite"])

        card = self._card(sc)
        g = ctk.CTkFrame(card, fg_color="transparent")
        g.pack(fill='x', padx=16, pady=12)

        self.e_nom       = EntryLabeled(g, "Nom *", width=200); self.e_nom.pack(anchor='w', pady=3)
        self.e_prenom    = EntryLabeled(g, "Prénom *", width=200); self.e_prenom.pack(anchor='w', pady=3)
        self.e_ddn       = EntryLabeled(g, "Date de naissance", placeholder="JJ/MM/AAAA", width=140)
        self.e_ddn.pack(anchor='w', pady=3)

        # Age calculé
        self._age_label = ctk.CTkLabel(g, text="", font=ctk.CTkFont("Segoe UI", 9),
                                        text_color=C["accent"])
        self._age_label.pack(anchor='w', padx=180)
        self.e_ddn.var.trace_add('write', self._on_ddn_change)

        self.c_sexe   = ComboLabeled(g, "Sexe", ["Masculin","Féminin","Autre"], width=160)
        self.c_sexe.pack(anchor='w', pady=3)
        self.e_tel    = EntryLabeled(g, "Téléphone", width=180); self.e_tel.pack(anchor='w', pady=3)
        self.e_addr   = EntryLabeled(g, "Adresse", width=300); self.e_addr.pack(anchor='w', pady=3)
        self.e_ndoss  = EntryLabeled(g, "N° Dossier", width=120); self.e_ndoss.pack(anchor='w', pady=3)
        self.e_date_c = EntryLabeled(g, "Date consultation", placeholder="JJ/MM/AAAA", width=140)
        self.e_date_c.pack(anchor='w', pady=3)

        self._sec_title(sc, "👨‍⚕️  Praticien", SEC["identite"])
        card2 = self._card(sc)
        g2 = ctk.CTkFrame(card2, fg_color="transparent")
        g2.pack(fill='x', padx=16, pady=12)
        self.e_medecin      = EntryLabeled(g2, "Nom du médecin", width=200); self.e_medecin.pack(anchor='w', pady=3)
        self.e_service      = EntryLabeled(g2, "Service / Unité", width=240); self.e_service.pack(anchor='w', pady=3)

    def _on_ddn_change(self, *args):
        age = calculer_age(self.e_ddn.get())
        self._age_label.configure(text=f"  → {age} ans" if age else "")

    # ──────────────────────────────────────────────────────────────
    # ONGLET 2 — Antécédents
    # ──────────────────────────────────────────────────────────────

    def _build_tab_antecedents(self, tab):
        sc = ctk.CTkScrollableFrame(tab, fg_color=C["bg"])
        sc.pack(fill='both', expand=True)
        self._sec_title(sc, "📋  Histoire du diabète", SEC["antecedents"])
        card = self._card(sc)
        g = ctk.CTkFrame(card, fg_color="transparent")
        g.pack(fill='x', padx=16, pady=12)

        self.c_type_diab = ComboLabeled(g, "Type de diabète *",
                                         ["Type 1","Type 2","Gestationnel","MODY","Autre"], width=180)
        self.c_type_diab.pack(anchor='w', pady=3)
        self.e_date_diag = EntryLabeled(g, "Date du diagnostic", placeholder="JJ/MM/AAAA", width=140)
        self.e_date_diag.pack(anchor='w', pady=3)
        self._duree_label = ctk.CTkLabel(g, text="", font=ctk.CTkFont("Segoe UI", 9),
                                          text_color=C["accent"])
        self._duree_label.pack(anchor='w', padx=180)
        self.e_date_diag.var.trace_add('write', self._on_diag_change)

        self._sec_title(sc, "🧬  Antécédents", SEC["antecedents"])
        card2 = self._card(sc)
        g2 = ctk.CTkFrame(card2, fg_color="transparent")
        g2.pack(fill='x', padx=16, pady=12)

        ctk.CTkLabel(g2, text="Antécédents familiaux :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"]).pack(anchor='w')
        self.tx_atcd_fam = ctk.CTkTextbox(g2, height=60, font=ctk.CTkFont("Segoe UI", 10))
        self.tx_atcd_fam.pack(fill='x', pady=(2,8))

        ctk.CTkLabel(g2, text="Antécédents personnels :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"]).pack(anchor='w')
        self.tx_atcd_perso = ctk.CTkTextbox(g2, height=60, font=ctk.CTkFont("Segoe UI", 10))
        self.tx_atcd_perso.pack(fill='x', pady=(2,8))

        self.e_allergies = EntryLabeled(g2, "Allergies connues", width=280)
        self.e_allergies.pack(anchor='w', pady=3)

    def _on_diag_change(self, *args):
        d = calculer_duree_diabete(self.e_date_diag.get())
        self._duree_label.configure(text=f"  → Durée : {d}" if d else "")

    # ──────────────────────────────────────────────────────────────
    # ONGLET 3 — Traitement
    # ──────────────────────────────────────────────────────────────

    def _build_tab_traitement(self, tab):
        sc = ctk.CTkScrollableFrame(tab, fg_color=C["bg"])
        sc.pack(fill='both', expand=True)
        self._sec_title(sc, "💊  Traitement en cours", SEC["traitement"])
        card = self._card(sc)
        g = ctk.CTkFrame(card, fg_color="transparent")
        g.pack(fill='x', padx=16, pady=12)

        chk_row = ctk.CTkFrame(g, fg_color="transparent")
        chk_row.pack(anchor='w', pady=4)
        ctk.CTkLabel(chk_row, text="Type(s) :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"], width=170, anchor="e").pack(side='left', padx=(0,6))
        self.v_insuline = tk.BooleanVar()
        self.v_aod      = tk.BooleanVar()
        ctk.CTkCheckBox(chk_row, text="Insuline", variable=self.v_insuline,
                         fg_color=C["accent3"], font=ctk.CTkFont("Segoe UI",10)).pack(side='left', padx=8)
        ctk.CTkCheckBox(chk_row, text="Antidiabétiques oraux", variable=self.v_aod,
                         fg_color=C["accent"], font=ctk.CTkFont("Segoe UI",10)).pack(side='left', padx=8)

        self.e_trait_autre = EntryLabeled(g, "Autre traitement", width=240)
        self.e_trait_autre.pack(anchor='w', pady=3)

        ctk.CTkLabel(g, text="Détail du traitement :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"]).pack(anchor='w', pady=(8,2))
        self.tx_traitement = ctk.CTkTextbox(g, height=80, font=ctk.CTkFont("Segoe UI", 10))
        self.tx_traitement.pack(fill='x', pady=(0,8))

        self.c_observance = ComboLabeled(g, "Observance",
                                          ["Bonne","Moyenne","Mauvaise","Non évaluée"], width=160)
        self.c_observance.pack(anchor='w', pady=3)

    # ──────────────────────────────────────────────────────────────
    # ONGLET 4 — Clinique
    # ──────────────────────────────────────────────────────────────

    def _build_tab_clinique(self, tab):
        sc = ctk.CTkScrollableFrame(tab, fg_color=C["bg"])
        sc.pack(fill='both', expand=True)

        # A. Poids/IMC
        self._sec_title(sc, "A. Poids & IMC", SEC["clinique"])
        c1 = self._card(sc)
        g1 = ctk.CTkFrame(c1, fg_color="transparent")
        g1.pack(fill='x', padx=16, pady=10)
        self.e_poids   = EntryLabeled(g1, "Poids (kg)", placeholder="ex: 72.5", width=100)
        self.e_poids.pack(anchor='w', pady=3)
        self.e_taille  = EntryLabeled(g1, "Taille (cm)", placeholder="ex: 168", width=100)
        self.e_taille.pack(anchor='w', pady=3)
        self.e_tour_t  = EntryLabeled(g1, "Tour de taille (cm)", width=100)
        self.e_tour_t.pack(anchor='w', pady=3)
        self.imc_card  = InterprCard(g1, "IMC calculé →")
        self.imc_card.pack(anchor='w', pady=4)
        for v in (self.e_poids.var, self.e_taille.var):
            v.trace_add('write', self._on_imc_change)

        # B. Pression artérielle
        self._sec_title(sc, "B. Pression artérielle", SEC["clinique"])
        c2 = self._card(sc)
        g2 = ctk.CTkFrame(c2, fg_color="transparent")
        g2.pack(fill='x', padx=16, pady=10)
        self.e_pa_s = EntryLabeled(g2, "PAS (mmHg)", placeholder="ex: 130", width=100)
        self.e_pa_s.pack(anchor='w', pady=3)
        self.e_pa_d = EntryLabeled(g2, "PAD (mmHg)", placeholder="ex: 85", width=100)
        self.e_pa_d.pack(anchor='w', pady=3)
        self.ta_card = InterprCard(g2, "TA →")
        self.ta_card.pack(anchor='w', pady=4)
        for v in (self.e_pa_s.var, self.e_pa_d.var):
            v.trace_add('write', self._on_ta_change)

        # C. Symptômes hyperglycémie
        self._sec_title(sc, "C. Symptômes d'hyperglycémie", SEC["clinique"])
        c3 = self._card(sc)
        g3 = ctk.CTkFrame(c3, fg_color="transparent")
        g3.pack(fill='x', padx=16, pady=10)
        self.chk_sym = CheckRow(g3, "Symptômes",
                                 ["Polyurie","Polydipsie","Polyphagie","Amaigrissement","Fatigue"],
                                 color=C["accent6"])
        self.chk_sym.pack(anchor='w', pady=4)
        self.e_sym_autres = EntryLabeled(g3, "Autres symptômes", width=280)
        self.e_sym_autres.pack(anchor='w', pady=3)

        # D. Hypoglycémie
        self._sec_title(sc, "D. Épisodes d'hypoglycémie", SEC["clinique"])
        c4 = self._card(sc)
        g4 = ctk.CTkFrame(c4, fg_color="transparent")
        g4.pack(fill='x', padx=16, pady=10)
        self.chk_hypo = CheckRow(g4, "Signes présents",
                                  ["Sueurs","Tremblements","Confusion","Palpitations"],
                                  color=C["accent4"])
        self.chk_hypo.pack(anchor='w', pady=4)

        # E. Pieds
        self._sec_title(sc, "E. Examen des pieds", SEC["clinique"])
        c5 = self._card(sc)
        g5 = ctk.CTkFrame(c5, fg_color="transparent")
        g5.pack(fill='x', padx=16, pady=10)
        self.chk_pied = CheckRow(g5, "Anomalies",
                                  ["Plaies","Ulcérations","Mycoses","Perte sensibilité","Déformations"],
                                  color=C["accent3"])
        self.chk_pied.pack(anchor='w', pady=4)
        self.e_pied_cm = EntryLabeled(g5, "Commentaire pieds", width=300)
        self.e_pied_cm.pack(anchor='w', pady=3)

        # F. Neurologique
        self._sec_title(sc, "F. Évaluation neurologique", SEC["clinique"])
        c6 = self._card(sc)
        g6 = ctk.CTkFrame(c6, fg_color="transparent")
        g6.pack(fill='x', padx=16, pady=10)
        self.chk_neuro = CheckRow(g6, "Neuropathie",
                                   ["Paresthésies","Douleurs","Hypoesthésie","Perte sensibilité plantaire"],
                                   color=C["accent5"])
        self.chk_neuro.pack(anchor='w', pady=4)

        # G. Cardiovasculaire
        self._sec_title(sc, "G. Examen cardiovasculaire", SEC["clinique"])
        c7 = self._card(sc)
        g7 = ctk.CTkFrame(c7, fg_color="transparent")
        g7.pack(fill='x', padx=16, pady=10)
        self.chk_cv = CheckRow(g7, "Complications CV",
                                ["Insuf. cardiaque","Artériopathie","AVC","Coronaropathie"],
                                color=C["accent3"])
        self.chk_cv.pack(anchor='w', pady=4)

        # H. Ophtalmologie
        self._sec_title(sc, "H. Surveillance ophtalmologique", SEC["clinique"])
        c8 = self._card(sc)
        g8 = ctk.CTkFrame(c8, fg_color="transparent")
        g8.pack(fill='x', padx=16, pady=10)
        self.chk_ophtalmo = CheckRow(g8, "Anomalies",
                                      ["Rétinopathie","Baisse de vision"],
                                      color=C["accent4"])
        self.chk_ophtalmo.pack(anchor='w', pady=4)
        self.e_fond_oeil = EntryLabeled(g8, "Dernier fond d'œil", placeholder="JJ/MM/AAAA", width=140)
        self.e_fond_oeil.pack(anchor='w', pady=3)

    def _on_imc_change(self, *args):
        try:
            p = float(self.e_poids.get()); t = float(self.e_taille.get())
            imc = calculer_imc(p, t)
            if imc:
                interp = interpreter_imc(imc)
                c = "#16A34A" if imc < 25 else ("#D97706" if imc < 30 else "#DC2626")
                self.imc_card.update(f"{imc} kg/m²  —  {interp}", c)
        except (ValueError, TypeError):
            self.imc_card.update("—")

    def _on_ta_change(self, *args):
        try:
            s = float(self.e_pa_s.get()); d = float(self.e_pa_d.get())
            interp, c = interpreter_pa(s, d)
            self.ta_card.update(f"{s:.0f}/{d:.0f} mmHg  —  {interp}", c)
        except (ValueError, TypeError):
            self.ta_card.update("—")

    # ──────────────────────────────────────────────────────────────
    # ONGLET 5 — Biologie
    # ──────────────────────────────────────────────────────────────

    def _build_tab_biologie(self, tab):
        sc = ctk.CTkScrollableFrame(tab, fg_color=C["bg"])
        sc.pack(fill='both', expand=True)

        # A. Glycémie
        self._sec_title(sc, "A. Glycémie", SEC["biologie"])
        c1 = self._card(sc)
        g1 = ctk.CTkFrame(c1, fg_color="transparent")
        g1.pack(fill='x', padx=16, pady=10)

        row_gj = ctk.CTkFrame(g1, fg_color="transparent")
        row_gj.pack(anchor='w', pady=3)
        ctk.CTkLabel(row_gj, text="Glycémie à jeun :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"], width=170, anchor="e").pack(side='left', padx=(0,6))
        self.e_gly_j = tk.StringVar()
        ctk.CTkEntry(row_gj, textvariable=self.e_gly_j, width=90,
                      font=ctk.CTkFont("Segoe UI",10), corner_radius=6, height=30).pack(side='left')
        self.c_gly_j_u = tk.StringVar(value="g/L")
        ctk.CTkComboBox(row_gj, variable=self.c_gly_j_u,
                         values=["g/L","mmol/L"], width=90,
                         font=ctk.CTkFont("Segoe UI",10), height=30).pack(side='left', padx=4)
        self.gj_card = InterprCard(g1, "Interprétation →")
        self.gj_card.pack(anchor='w', pady=3)
        for v in (self.e_gly_j, self.c_gly_j_u):
            v.trace_add('write', self._on_gj_change)

        row_gpp = ctk.CTkFrame(g1, fg_color="transparent")
        row_gpp.pack(anchor='w', pady=3)
        ctk.CTkLabel(row_gpp, text="Glycémie postprandiale :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"], width=170, anchor="e").pack(side='left', padx=(0,6))
        self.e_gly_pp = tk.StringVar()
        ctk.CTkEntry(row_gpp, textvariable=self.e_gly_pp, width=90,
                      font=ctk.CTkFont("Segoe UI",10), corner_radius=6, height=30).pack(side='left')
        self.c_gly_pp_u = tk.StringVar(value="g/L")
        ctk.CTkComboBox(row_gpp, variable=self.c_gly_pp_u,
                         values=["g/L","mmol/L"], width=90,
                         font=ctk.CTkFont("Segoe UI",10), height=30).pack(side='left', padx=4)

        # B. HbA1c
        self._sec_title(sc, "B. HbA1c — Hémoglobine glyquée", SEC["biologie"])
        c2 = self._card(sc)
        g2 = ctk.CTkFrame(c2, fg_color="transparent")
        g2.pack(fill='x', padx=16, pady=10)
        row_hba = ctk.CTkFrame(g2, fg_color="transparent")
        row_hba.pack(anchor='w', pady=3)
        ctk.CTkLabel(row_hba, text="HbA1c (%) :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"], width=170, anchor="e").pack(side='left', padx=(0,6))
        self.e_hba1c = tk.StringVar()
        ctk.CTkEntry(row_hba, textvariable=self.e_hba1c, width=90,
                      font=ctk.CTkFont("Segoe UI",10), corner_radius=6, height=30).pack(side='left')
        ctk.CTkLabel(row_hba, text="%",
                      font=ctk.CTkFont("Segoe UI",10), text_color=C["text2"]).pack(side='left', padx=4)
        self.hba1c_card = InterprCard(g2, "Interprétation →")
        self.hba1c_card.pack(anchor='w', pady=3)
        self.e_hba1c.trace_add('write', self._on_hba1c_change)

        # C. Fonction rénale
        self._sec_title(sc, "C. Fonction rénale", SEC["biologie"])
        c3 = self._card(sc)
        g3 = ctk.CTkFrame(c3, fg_color="transparent")
        g3.pack(fill='x', padx=16, pady=10)
        self.e_creat = EntryLabeled(g3, "Créatinine (µmol/L)", width=100)
        self.e_creat.pack(anchor='w', pady=3)
        self.e_dfg   = EntryLabeled(g3, "DFG (mL/min/1,73 m²)", width=100)
        self.e_dfg.pack(anchor='w', pady=3)
        self.dfg_card = InterprCard(g3, "Stade MRC →")
        self.dfg_card.pack(anchor='w', pady=3)
        self.e_dfg.var.trace_add('write', self._on_dfg_change)

        # D. Albuminurie
        self._sec_title(sc, "D. Albuminurie / Microalbuminurie", SEC["biologie"])
        c4 = self._card(sc)
        g4 = ctk.CTkFrame(c4, fg_color="transparent")
        g4.pack(fill='x', padx=16, pady=10)
        self.e_albumin = EntryLabeled(g4, "Albuminurie (mg/24h)", width=110)
        self.e_albumin.pack(anchor='w', pady=3)
        chk_micro_row = ctk.CTkFrame(g4, fg_color="transparent")
        chk_micro_row.pack(anchor='w', pady=3)
        ctk.CTkLabel(chk_micro_row, text="Microalbuminurie positive :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"], width=170, anchor="e").pack(side='left', padx=(0,6))
        self.v_microalb = tk.BooleanVar()
        ctk.CTkCheckBox(chk_micro_row, text="Oui", variable=self.v_microalb,
                         fg_color=C["accent3"], font=ctk.CTkFont("Segoe UI",10)).pack(side='left')

        # E. Bilan lipidique
        self._sec_title(sc, "E. Bilan lipidique", SEC["biologie"])
        c5 = self._card(sc)
        g5 = ctk.CTkFrame(c5, fg_color="transparent")
        g5.pack(fill='x', padx=16, pady=10)
        self.e_chol  = EntryLabeled(g5, "Cholestérol total (g/L)", width=100)
        self.e_chol.pack(anchor='w', pady=3)
        self.e_ldl   = EntryLabeled(g5, "LDL (g/L)", width=100)
        self.e_ldl.pack(anchor='w', pady=3)
        self.e_hdl   = EntryLabeled(g5, "HDL (g/L)", width=100)
        self.e_hdl.pack(anchor='w', pady=3)
        self.e_tg    = EntryLabeled(g5, "Triglycérides (g/L)", width=100)
        self.e_tg.pack(anchor='w', pady=3)

        # F. Bandelette urinaire
        self._sec_title(sc, "F. Bandelette urinaire", SEC["biologie"])
        c6 = self._card(sc)
        g6 = ctk.CTkFrame(c6, fg_color="transparent")
        g6.pack(fill='x', padx=16, pady=10)
        self.c_bu_glu  = ComboLabeled(g6, "Glucose", ["Négatif","+","++","+++"], width=120)
        self.c_bu_glu.pack(anchor='w', pady=3)
        self.c_bu_prot = ComboLabeled(g6, "Protéines", ["Négatif","+","++","+++"], width=120)
        self.c_bu_prot.pack(anchor='w', pady=3)
        self.c_bu_inf  = ComboLabeled(g6, "Infection urinaire", ["Absent","Présent","Douteux"], width=120)
        self.c_bu_inf.pack(anchor='w', pady=3)

        # G. Cétonémie
        self._sec_title(sc, "G. Cétonémie / Cétonurie", SEC["biologie"])
        c7 = self._card(sc)
        g7 = ctk.CTkFrame(c7, fg_color="transparent")
        g7.pack(fill='x', padx=16, pady=10)
        self.e_cetone  = EntryLabeled(g7, "Cétonémie (mmol/L)", width=100)
        self.e_cetone.pack(anchor='w', pady=3)
        self.c_cetonurie = ComboLabeled(g7, "Cétonurie",
                                         ["Négative","+","++","+++","Non réalisée"], width=140)
        self.c_cetonurie.pack(anchor='w', pady=3)

    def _on_gj_change(self, *args):
        try:
            v = float(self.e_gly_j.get())
            interp, c = interpreter_glycemie_jeun(v, self.c_gly_j_u.get())
            self.gj_card.update(interp, c)
        except (ValueError, TypeError):
            self.gj_card.update("—")

    def _on_hba1c_change(self, *args):
        try:
            v = float(self.e_hba1c.get())
            interp, c = interpreter_hba1c(v)
            self.hba1c_card.update(interp, c)
        except (ValueError, TypeError):
            self.hba1c_card.update("—")

    def _on_dfg_change(self, *args):
        try:
            v = float(self.e_dfg.get())
            interp, c = interpreter_dfg(v)
            self.dfg_card.update(interp, c)
        except (ValueError, TypeError):
            self.dfg_card.update("—")

    # ──────────────────────────────────────────────────────────────
    # ONGLET 6 — Paraclinique
    # ──────────────────────────────────────────────────────────────

    def _build_tab_paraclinique(self, tab):
        sc = ctk.CTkScrollableFrame(tab, fg_color=C["bg"])
        sc.pack(fill='both', expand=True)

        self._sec_title(sc, "📡  Examens paracliniques", SEC["paraclinique"])
        card = self._card(sc)
        g = ctk.CTkFrame(card, fg_color="transparent")
        g.pack(fill='x', padx=16, pady=12)

        ctk.CTkLabel(g, text="ECG — Résultat :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"]).pack(anchor='w', pady=(4,2))
        self.tx_ecg = ctk.CTkTextbox(g, height=60, font=ctk.CTkFont("Segoe UI", 10))
        self.tx_ecg.pack(fill='x', pady=(0,8))

        ctk.CTkLabel(g, text="Doppler artériel — Résultat :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"]).pack(anchor='w', pady=(4,2))
        self.tx_doppler = ctk.CTkTextbox(g, height=60, font=ctk.CTkFont("Segoe UI", 10))
        self.tx_doppler.pack(fill='x', pady=(0,8))

        ctk.CTkLabel(g, text="Fond d'œil — Résultat :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"]).pack(anchor='w', pady=(4,2))
        self.tx_fond_oeil_res = ctk.CTkTextbox(g, height=60, font=ctk.CTkFont("Segoe UI", 10))
        self.tx_fond_oeil_res.pack(fill='x', pady=(0,8))

    # ──────────────────────────────────────────────────────────────
    # ONGLET 7 — Synthèse
    # ──────────────────────────────────────────────────────────────

    def _build_tab_synthese(self, tab):
        sc = ctk.CTkScrollableFrame(tab, fg_color=C["bg"])
        sc.pack(fill='both', expand=True)

        self._sec_title(sc, "📝  Synthèse clinique & Plan thérapeutique", SEC["synthese"])
        card = self._card(sc)
        g = ctk.CTkFrame(card, fg_color="transparent")
        g.pack(fill='x', padx=16, pady=12)

        self.c_equilibre = ComboLabeled(g, "Équilibre glycémique",
                                         ["Bon","Moyen","Mauvais","À réévaluer"], width=160)
        self.c_equilibre.pack(anchor='w', pady=4)

        ctk.CTkLabel(g, text="Complications actives :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"]).pack(anchor='w', pady=(8,2))
        self.tx_complic = ctk.CTkTextbox(g, height=60, font=ctk.CTkFont("Segoe UI", 10))
        self.tx_complic.pack(fill='x', pady=(0,8))

        ctk.CTkLabel(g, text="Plan thérapeutique :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"]).pack(anchor='w', pady=(4,2))
        self.tx_plan = ctk.CTkTextbox(g, height=80, font=ctk.CTkFont("Segoe UI", 10))
        self.tx_plan.pack(fill='x', pady=(0,8))

        self.e_rdv = EntryLabeled(g, "Prochain rendez-vous", placeholder="JJ/MM/AAAA", width=140)
        self.e_rdv.pack(anchor='w', pady=3)

        ctk.CTkLabel(g, text="Notes du médecin :",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color=C["text"]).pack(anchor='w', pady=(8,2))
        self.tx_notes = ctk.CTkTextbox(g, height=80, font=ctk.CTkFont("Segoe UI", 10))
        self.tx_notes.pack(fill='x', pady=(0,8))

        # Carte de risque CV
        self._sec_title(sc, "⚡  Score de risque cardiovasculaire (simplifié)", "#DC2626")
        card_cv = ctk.CTkFrame(sc, fg_color=C["card"], corner_radius=10,
                                border_width=1, border_color=C["border"])
        card_cv.pack(fill='x', padx=8, pady=4)
        cv_inner = ctk.CTkFrame(card_cv, fg_color="transparent")
        cv_inner.pack(fill='x', padx=16, pady=12)

        self.cv_score_label = ctk.CTkLabel(cv_inner,
                                            text="Calculez en appuyant sur 'Actualiser'",
                                            font=ctk.CTkFont("Segoe UI", 13, weight="bold"),
                                            text_color=C["text2"])
        self.cv_score_label.pack()
        ctk.CTkLabel(cv_inner,
                      text="Basé sur : HbA1c, TA, LDL, IMC, antécédents CV, âge, type diabète",
                      font=ctk.CTkFont("Segoe UI", 9), text_color=C["text2"]).pack()

        self._btn_actu = ctk.CTkButton(sc, text="🔄  Calculer le score de risque CV",
                                        command=self._actualiser,
                                        fg_color=C["accent"], hover_color="#1E3A5F",
                                        font=ctk.CTkFont("Segoe UI",11),
                                        corner_radius=8, height=36)
        self._btn_actu.pack(pady=8)

    # ──────────────────────────────────────────────────────────────
    # Helpers UI
    # ──────────────────────────────────────────────────────────────

    def _sec_title(self, parent, text, color):
        f = ctk.CTkFrame(parent, fg_color=color, corner_radius=6, height=30)
        f.pack(fill='x', padx=8, pady=(8, 2))
        f.pack_propagate(False)
        ctk.CTkLabel(f, text=f"  {text}",
                      font=ctk.CTkFont("Segoe UI", 10, weight="bold"),
                      text_color="white").pack(side='left', padx=6, pady=4)

    def _card(self, parent):
        f = ctk.CTkFrame(parent, fg_color=C["card"], corner_radius=8,
                          border_width=1, border_color=C["border"])
        f.pack(fill='x', padx=8, pady=4)
        return f

    # ──────────────────────────────────────────────────────────────
    # Collecte des données du formulaire → PatientDiabete
    # ──────────────────────────────────────────────────────────────

    def _float_or_none(self, s: str):
        try:
            return float(s.strip().replace(",", "."))
        except (ValueError, AttributeError):
            return None

    def _text(self, widget) -> str:
        return widget.get("1.0", "end").strip()

    def _collect_patient(self) -> PatientDiabete:
        sym   = self.chk_sym.get()
        hypo  = self.chk_hypo.get()
        pied  = self.chk_pied.get()
        neuro = self.chk_neuro.get()
        cv    = self.chk_cv.get()
        opht  = self.chk_ophtalmo.get()

        return PatientDiabete(
            # Identité
            nom=self.e_nom.get(), prenom=self.e_prenom.get(),
            date_naissance=self.e_ddn.get(), sexe=self.c_sexe.get(),
            telephone=self.e_tel.get(), adresse=self.e_addr.get(),
            num_dossier=self.e_ndoss.get(), date_consultation=self.e_date_c.get(),
            medecin_nom=self.e_medecin.get(), medecin_service=self.e_service.get(),
            # Antécédents
            type_diabete=self.c_type_diab.get(), date_diagnostic=self.e_date_diag.get(),
            antecedents_familiaux=self._text(self.tx_atcd_fam),
            antecedents_personnels=self._text(self.tx_atcd_perso),
            allergies=self.e_allergies.get(),
            # Traitement
            traitement_insuline=self.v_insuline.get(), traitement_aod=self.v_aod.get(),
            traitement_autre=self.e_trait_autre.get(),
            detail_traitement=self._text(self.tx_traitement),
            observance=self.c_observance.get(),
            # Clinique
            poids=self._float_or_none(self.e_poids.get()),
            taille=self._float_or_none(self.e_taille.get()),
            tour_taille=self._float_or_none(self.e_tour_t.get()),
            pa_systolique=self._float_or_none(self.e_pa_s.get()),
            pa_diastolique=self._float_or_none(self.e_pa_d.get()),
            sym_polyurie=sym.get("Polyurie",False), sym_polydipsie=sym.get("Polydipsie",False),
            sym_polyphagie=sym.get("Polyphagie",False),
            sym_amaigrissement=sym.get("Amaigrissement",False),
            sym_fatigue=sym.get("Fatigue",False), sym_autres=self.e_sym_autres.get(),
            hypo_sueurs=hypo.get("Sueurs",False), hypo_tremblements=hypo.get("Tremblements",False),
            hypo_confusion=hypo.get("Confusion",False), hypo_palpitations=hypo.get("Palpitations",False),
            pied_plaie=pied.get("Plaies",False), pied_ulceration=pied.get("Ulcérations",False),
            pied_mycose=pied.get("Mycoses",False),
            pied_perte_sensibilite=pied.get("Perte sensibilité",False),
            pied_deformation=pied.get("Déformations",False),
            pied_commentaire=self.e_pied_cm.get(),
            neuro_paresthesies=neuro.get("Paresthésies",False),
            neuro_douleurs=neuro.get("Douleurs",False),
            neuro_hypoesthesie=neuro.get("Hypoesthésie",False),
            neuro_perte_sensib_plantaire=neuro.get("Perte sensibilité plantaire",False),
            cv_insuffisance_cardiaque=cv.get("Insuf. cardiaque",False),
            cv_arteriopathie=cv.get("Artériopathie",False),
            cv_avc=cv.get("AVC",False), cv_coronaropathie=cv.get("Coronaropathie",False),
            ophtalmo_retinopathie=opht.get("Rétinopathie",False),
            ophtalmo_baisse_vision=opht.get("Baisse de vision",False),
            dernier_fond_oeil=self.e_fond_oeil.get(),
            # Biologie
            glycemie_jeun=self._float_or_none(self.e_gly_j.get()),
            glycemie_jeun_unite=self.c_gly_j_u.get(),
            glycemie_postprandiale=self._float_or_none(self.e_gly_pp.get()),
            glycemie_pp_unite=self.c_gly_pp_u.get(),
            hba1c=self._float_or_none(self.e_hba1c.get()),
            creatinine=self._float_or_none(self.e_creat.get()),
            dfg=self._float_or_none(self.e_dfg.get()),
            albuminurie=self._float_or_none(self.e_albumin.get()),
            microalbuminurie_positive=self.v_microalb.get(),
            chol_total=self._float_or_none(self.e_chol.get()),
            ldl=self._float_or_none(self.e_ldl.get()),
            hdl=self._float_or_none(self.e_hdl.get()),
            triglycerides=self._float_or_none(self.e_tg.get()),
            cetonemie=self._float_or_none(self.e_cetone.get()),
            cetonurie=self.c_cetonurie.get(),
            bu_glucose=self.c_bu_glu.get(), bu_proteines=self.c_bu_prot.get(),
            bu_infection=self.c_bu_inf.get(),
            # Paraclinique
            ecg_resultat=self._text(self.tx_ecg),
            doppler_resultat=self._text(self.tx_doppler),
            # Synthèse
            equilibre_glycemique=self.c_equilibre.get(),
            complications_actives=self._text(self.tx_complic),
            plan_therapeutique=self._text(self.tx_plan),
            prochain_rdv=self.e_rdv.get(),
            notes_medecin=self._text(self.tx_notes),
        )

    # ──────────────────────────────────────────────────────────────
    # Actions
    # ──────────────────────────────────────────────────────────────

    def _actualiser(self):
        """Recalcule tous les indicateurs et met à jour le bandeau + score CV."""
        p = self._collect_patient()
        self._update_bord()
        # Mise à jour score CV dans l'onglet synthèse
        score, niveau, color = score_risque_cardiovasculaire(p)
        self.cv_score_label.configure(
            text=f"Score de risque CV : {niveau}  ({score} / 10)",
            text_color=color
        )

    def _nouveau(self):
        if messagebox.askyesno("Nouveau dossier",
                                "Créer un nouveau dossier ?\nLes données non enregistrées seront perdues."):
            self._reset_form()

    def _reset_form(self):
        """Réinitialise tous les champs."""
        for attr in ['e_nom','e_prenom','e_ddn','e_tel','e_addr','e_ndoss',
                     'e_date_c','e_medecin','e_service','e_date_diag','e_allergies',
                     'e_poids','e_taille','e_tour_t','e_pa_s','e_pa_d',
                     'e_sym_autres','e_pied_cm','e_creat','e_dfg','e_albumin',
                     'e_chol','e_ldl','e_hdl','e_tg','e_cetone','e_fond_oeil','e_rdv',
                     'e_trait_autre']:
            if hasattr(self, attr):
                getattr(self, attr).set("")
        for attr in ['e_gly_j','e_gly_pp','e_hba1c']:
            if hasattr(self, attr):
                getattr(self, attr).set("")
        for attr in ['v_insuline','v_aod','v_microalb']:
            if hasattr(self, attr):
                getattr(self, attr).set(False)
        for attr in ['tx_atcd_fam','tx_atcd_perso','tx_traitement',
                     'tx_ecg','tx_doppler','tx_fond_oeil_res',
                     'tx_complic','tx_plan','tx_notes']:
            if hasattr(self, attr):
                getattr(self, attr).delete("1.0","end")
        for attr in ['chk_sym','chk_hypo','chk_pied','chk_neuro','chk_cv','chk_ophtalmo']:
            if hasattr(self, attr):
                for v in getattr(self, attr).vars.values():
                    v.set(False)

    def _exporter_word(self):
        p = self._collect_patient()
        if not p.nom and not p.prenom:
            messagebox.showwarning("Attention", "Renseignez au moins le nom du patient.")
            return
        default = f"dossier_{p.nom}_{p.prenom}.docx".replace(" ","_")
        path = filedialog.asksaveasfilename(
            defaultextension=".docx",
            filetypes=[("Word", "*.docx")],
            initialfile=default,
            title="Enregistrer le dossier patient"
        )
        if not path:
            return
        try:
            exporter_dossier_word(p, path)
            messagebox.showinfo("Succès", f"Dossier exporté :\n{path}")
        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    def _exporter_excel(self):
        """Export du résumé patient en Excel."""
        p = self._collect_patient()
        if not p.nom and not p.prenom:
            messagebox.showwarning("Attention", "Renseignez au moins le nom du patient.")
            return
        default = f"dossier_{p.nom}_{p.prenom}.xlsx".replace(" ","_")
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx")],
            initialfile=default,
            title="Enregistrer le résumé Excel"
        )
        if not path:
            return
        try:
            self._export_patient_excel(p, path)
            messagebox.showinfo("Succès", f"Résumé Excel exporté :\n{path}")
        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    def _export_patient_excel(self, p: PatientDiabete, path: str):
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Dossier Patient"
        ws.sheet_view.showGridLines = False

        HDR_FILL = PatternFill("solid", fgColor="1E3A5F")
        SEC_FILL = PatternFill("solid", fgColor="2563EB")
        ALT_FILL = PatternFill("solid", fgColor="EFF6FF")
        HDR_FONT = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
        SEC_FONT = Font(name="Calibri", bold=True, color="FFFFFF", size=10)
        BODY     = Font(name="Calibri", size=10)
        BOLD     = Font(name="Calibri", bold=True, size=10)
        THIN     = Border(
            left=Side('thin', color='CBD5E1'), right=Side('thin', color='CBD5E1'),
            top=Side('thin', color='CBD5E1'), bottom=Side('thin', color='CBD5E1')
        )
        CENTER   = Alignment(horizontal='center', vertical='center', wrap_text=True)
        LEFT     = Alignment(horizontal='left',   vertical='center', wrap_text=True)

        # Titre
        ws.merge_cells('A1:C1')
        ws['A1'] = f"DOSSIER PATIENT DIABÉTIQUE — {p.nom.upper()} {p.prenom}"
        ws['A1'].font  = HDR_FONT
        ws['A1'].fill  = HDR_FILL
        ws['A1'].alignment = CENTER

        ws.column_dimensions['A'].width = 32
        ws.column_dimensions['B'].width = 30
        ws.column_dimensions['C'].width = 22

        row = 2
        imc = calculer_imc(p.poids, p.taille) if p.poids and p.taille else None
        age = calculer_age(p.date_naissance)
        duree = calculer_duree_diabete(p.date_diagnostic) if p.date_diagnostic else ""

        sections = [
            ("IDENTITÉ", [
                ("Nom & Prénom",    f"{p.nom.upper()} {p.prenom}", ""),
                ("Date naissance",  p.date_naissance, f"{age} ans" if age else ""),
                ("Sexe",           p.sexe, ""),
                ("N° Dossier",     p.num_dossier, ""),
                ("Date consultation", p.date_consultation, ""),
                ("Médecin",        p.medecin_nom, p.medecin_service),
            ]),
            ("DIABÈTE & ANTÉCÉDENTS", [
                ("Type de diabète",  p.type_diabete, ""),
                ("Date diagnostic",  p.date_diagnostic, f"Durée : {duree}" if duree else ""),
                ("Antécédents fam.", p.antecedents_familiaux or "—", ""),
                ("Antécédents perso", p.antecedents_personnels or "—", ""),
                ("Allergies",        p.allergies or "—", ""),
                ("Traitement",       "Insuline" if p.traitement_insuline else "" +
                                     " | ADO" if p.traitement_aod else "", p.observance),
            ]),
            ("PARAMÈTRES CLINIQUES", [
                ("Poids / Taille",   f"{p.poids} kg" if p.poids else "—",
                                     f"{p.taille} cm" if p.taille else "—"),
                ("IMC",              f"{imc} kg/m²" if imc else "—",
                                     interpreter_imc(imc) if imc else "—"),
                ("Tour de taille",   f"{p.tour_taille} cm" if p.tour_taille else "—", ""),
                ("Pression artérielle",
                                     f"{p.pa_systolique}/{p.pa_diastolique} mmHg"
                                     if p.pa_systolique else "—",
                                     interpreter_pa(p.pa_systolique, p.pa_diastolique)[0]
                                     if p.pa_systolique and p.pa_diastolique else "—"),
            ]),
            ("PARAMÈTRES BIOLOGIQUES", [
                ("Glycémie à jeun",  f"{p.glycemie_jeun} {p.glycemie_jeun_unite}"
                                     if p.glycemie_jeun else "—",
                                     interpreter_glycemie_jeun(p.glycemie_jeun,
                                     p.glycemie_jeun_unite)[0] if p.glycemie_jeun else "—"),
                ("HbA1c",            f"{p.hba1c} %" if p.hba1c else "—",
                                     interpreter_hba1c(p.hba1c)[0] if p.hba1c else "—"),
                ("Créatinine",       f"{p.creatinine} µmol/L" if p.creatinine else "—", ""),
                ("DFG",              f"{p.dfg} mL/min" if p.dfg else "—",
                                     interpreter_dfg(p.dfg)[0] if p.dfg else "—"),
                ("Cholestérol total", f"{p.chol_total} g/L" if p.chol_total else "—", ""),
                ("LDL / HDL",        f"{p.ldl} / {p.hdl} g/L"
                                     if p.ldl and p.hdl else "—", ""),
                ("Triglycérides",    f"{p.triglycerides} g/L" if p.triglycerides else "—", ""),
            ]),
            ("SYNTHÈSE", [
                ("Équilibre glycémique", p.equilibre_glycemique or "—", ""),
                ("Risque CV",        score_risque_cardiovasculaire(p)[1],
                                     f"Score {score_risque_cardiovasculaire(p)[0]}/10"),
                ("Complications",    p.complications_actives or "—", ""),
                ("Plan thérap.",     p.plan_therapeutique or "—", ""),
                ("Prochain RDV",     p.prochain_rdv or "—", ""),
            ]),
        ]

        for sec_title, items in sections:
            # Titre de section
            row += 1
            ws.merge_cells(f'A{row}:C{row}')
            ws[f'A{row}'] = sec_title
            ws[f'A{row}'].font  = SEC_FONT
            ws[f'A{row}'].fill  = SEC_FILL
            ws[f'A{row}'].alignment = LEFT
            ws.row_dimensions[row].height = 18
            row += 1

            for i, (label, val1, val2) in enumerate(items):
                fill = ALT_FILL if i % 2 == 0 else PatternFill(fill_type=None)
                for col, (cell_val, font, align) in enumerate([
                    (label, BOLD, LEFT),
                    (str(val1) if val1 else "—", BODY, LEFT),
                    (str(val2) if val2 else "", BODY, CENTER),
                ], 1):
                    c = ws.cell(row=row, column=col, value=cell_val)
                    c.font = font; c.alignment = align; c.border = THIN; c.fill = fill
                ws.row_dimensions[row].height = 16
                row += 1

        wb.save(path)
