"""
Module d'exportation — Excel et Word
Graphiques automatiques intégrés : un par variable / tableau.
  - Qualitative  → Camembert (si C1–C4 réunis) ou Barres
  - Quantitative → Boxplot
"""

import io
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.drawing.image import Image as XlImage

from docx import Document
from docx.shared import Pt, Cm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from core.chart_export import auto_chart


# ═══════════════════════════════════════════════════════ Styles Excel ══════════

HEADER_FILL = PatternFill(start_color="1E3A5F", end_color="1E3A5F", fill_type="solid")
ALT_FILL    = PatternFill(start_color="EFF6FF", end_color="EFF6FF", fill_type="solid")
GREEN_HDR   = PatternFill(start_color="2E7D52", end_color="2E7D52", fill_type="solid")
GREEN_SUB   = PatternFill(start_color="4E9E72", end_color="4E9E72", fill_type="solid")
GREEN_ALT   = PatternFill(start_color="F0FDF6", end_color="F0FDF6", fill_type="solid")
EMPTY_FILL  = PatternFill(fill_type=None)

HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
BODY_FONT   = Font(name="Calibri", size=10)
BOLD_FONT   = Font(name="Calibri", size=10, bold=True)

THIN_BORDER = Border(
    left   = Side(style="thin", color="CBD5E1"),
    right  = Side(style="thin", color="CBD5E1"),
    top    = Side(style="thin", color="CBD5E1"),
    bottom = Side(style="thin", color="CBD5E1"),
)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT   = Alignment(horizontal="left",   vertical="center", wrap_text=True)


# ══════════════════════════════════════════════ Utilitaires Excel ══════════════

def _auto_col_width(ws, min_w=8, max_w=45):
    for col in ws.columns:
        best = min_w
        for cell in col:
            try:
                best = min(max(best, len(str(cell.value or "")) + 2), max_w)
            except Exception:
                pass
        ws.column_dimensions[get_column_letter(col[0].column)].width = best


def _write_header_row(ws, row: int, columns: list,
                       fill=None, font=None):
    f = fill or HEADER_FILL
    fo = font or HEADER_FONT
    for j, col_name in enumerate(columns, 1):
        c = ws.cell(row=row, column=j, value=str(col_name))
        c.fill = f; c.font = fo
        c.alignment = CENTER; c.border = THIN_BORDER


def _write_data_rows(ws, df: pd.DataFrame, start_row: int,
                     alt_fill=None, row_meta: list = None) -> int:
    """Écrit les données + mise en forme conditionnelle bivariée. Retourne la prochaine ligne."""
    for i, row_data in enumerate(df.itertuples(index=False)):
        r_idx = start_row + i
        meta       = (row_meta or [{}] * len(df))[i]
        is_ref     = meta.get("__is_ref__",       False)
        is_section = meta.get("__is_section__",   False)
        is_first   = meta.get("__var_first_row__", False)
        bg = ALT_FILL if (i % 2 == 1) else EMPTY_FILL

        for j, (col_name, val) in enumerate(zip(df.columns, row_data), 1):
            txt  = str(val) if pd.notna(val) else ""
            cell = ws.cell(row=r_idx, column=j, value=txt)
            cell.border = THIN_BORDER

            if is_section:
                cell.fill = GREEN_SUB
                cell.font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
                cell.alignment = LEFT
            elif col_name == "Variable" and is_first:
                cell.fill = bg; cell.font = BOLD_FONT; cell.alignment = LEFT
            elif col_name == "Modalité" and is_ref:
                cell.fill = bg
                cell.font = Font(name="Calibri", size=10, italic=True, color="64748B")
                cell.alignment = LEFT
            elif col_name == "Test / OR [IC 95%]":
                cell.fill = bg; cell.alignment = CENTER
                if txt == "Réf.":
                    cell.font = Font(name="Calibri", size=10, italic=True, color="64748B")
                elif txt not in ("—", "", "nan"):
                    cell.font = Font(name="Calibri", size=10, bold=True,  color="15803D")
                else:
                    cell.font = BODY_FONT
            elif col_name == "p":
                cell.fill = bg; cell.alignment = CENTER
                cell.font = (Font(name="Calibri", size=10, bold=True, color="1E3A5F")
                             if txt not in ("", "—", "nan") else BODY_FONT)
            else:
                cell.fill = bg; cell.font = BODY_FONT
                cell.alignment = LEFT if j == 1 else CENTER

    return start_row + len(df)


def _section_title(ws, row: int, text: str, color: str = "1E3A5F") -> int:
    ws.cell(row=row, column=1, value=text).font = \
        Font(name="Calibri", size=12, bold=True, color=color)
    return row + 1


def _insert_chart_excel(ws, img_bytes: bytes, anchor: str,
                         w_cm: float = 11, h_cm: float = 7.5):
    if not img_bytes:
        return
    buf = io.BytesIO(img_bytes)
    img = XlImage(buf)
    img.width  = int(w_cm / 2.54 * 96)
    img.height = int(h_cm / 2.54 * 96)
    ws.add_image(img, anchor)


# ═══════════════════════════════════════════════ Export Excel ══════════════════

def export_excel(data_manager, output_path: str, selections: dict):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    # ── Page de garde ──────────────────────────────────────────────────────────
    ws = wb.create_sheet("Accueil")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["B"].width = 70
    ws["B3"] = "RAPPORT D'ANALYSE STATISTIQUE"
    ws["B3"].font = Font(name="Calibri", size=18, bold=True, color="1E3A5F")
    ws["B4"] = "StatAnalyzer — Logiciel d'analyse pour la recherche médicale"
    ws["B4"].font = Font(name="Calibri", size=11, color="475569")
    ws["B6"] = f"Date : {datetime.now().strftime('%d/%m/%Y %H:%M')}"
    ws["B6"].font = Font(name="Calibri", size=10, color="475569")
    if data_manager.file_path:
        ws["B7"] = f"Fichier source : {Path(data_manager.file_path).name}"
        ws["B7"].font = Font(name="Calibri", size=10, color="475569")
    if data_manager.df is not None:
        ws["B8"] = (f"Observations : {len(data_manager.df)} "
                     f"| Variables : {len(data_manager.df.columns)}")
        ws["B8"].font = Font(name="Calibri", size=10, color="475569")

    # ── Complétude ─────────────────────────────────────────────────────────────
    if selections.get("completeness") and data_manager.df is not None:
        ws = wb.create_sheet("Complétude")
        ws.sheet_view.showGridLines = False
        df_c = data_manager.get_completeness_table()
        row = _section_title(ws, 2, "Analyse de complétude des données")
        _write_header_row(ws, row, list(df_c.columns))
        _write_data_rows(ws, df_c, row + 1, alt_fill=ALT_FILL)
        _auto_col_width(ws)

    # ── Statistiques descriptives ──────────────────────────────────────────────
    if selections.get("descriptive") and data_manager.df is not None:

        # ─ Variables qualitatives
        if data_manager.qualitative_vars:
            ws = wb.create_sheet("Qualitatives")
            ws.sheet_view.showGridLines = False
            _section_title(ws, 1, "Variables Qualitatives — Statistiques descriptives")
            cur = 3

            for var in data_manager.qualitative_vars:
                df_q = data_manager.get_qualitative_stats(var)
                if df_q.empty:
                    continue

                series = data_manager.df[var].dropna()
                img_bytes, chart_type = auto_chart(series, var, "qualitative", dpi=130)
                chart_name = "Camembert" if chart_type == "pie" else "Diagramme en barres"

                # Titre variable
                ws.cell(row=cur, column=1, value=var).font = \
                    Font(name="Calibri", size=11, bold=True, color="2563EB")
                ws.cell(row=cur, column=4,
                        value=f"► {chart_name}  |  N={len(series)}").font = \
                    Font(name="Calibri", size=9, italic=True, color="64748B")
                cur += 1

                # Tableau
                fill_q = PatternFill(start_color="2563EB", end_color="2563EB",
                                     fill_type="solid")
                _write_header_row(ws, cur, list(df_q.columns), fill=fill_q)
                table_end = _write_data_rows(ws, df_q, cur + 1, alt_fill=ALT_FILL)

                # Graphique dans la colonne E
                chart_col = get_column_letter(len(df_q.columns) + 2)
                _insert_chart_excel(ws, img_bytes, f"{chart_col}{cur}",
                                     w_cm=11, h_cm=7)

                cur = max(table_end, cur + 20) + 2

            _auto_col_width(ws)

        # ─ Variables quantitatives
        if data_manager.quantitative_vars:
            ws = wb.create_sheet("Quantitatives")
            ws.sheet_view.showGridLines = False
            _section_title(ws, 1, "Variables Quantitatives — Statistiques descriptives")
            cur = 3

            # Tableau récap global
            all_stats = []
            for var in data_manager.quantitative_vars:
                s = data_manager.get_quantitative_stats(var)
                if s:
                    s["Variable"] = var
                    all_stats.append(s)
            if all_stats:
                SCOLS = ["Variable", "N", "Moyenne", "Médiane", "Mode",
                         "Minimum", "Maximum", "Écart-type",
                         "Q1 (25%)", "Q3 (75%)", "IQR"]
                df_qt = pd.DataFrame(all_stats)[[c for c in SCOLS if c in all_stats[0]]]
                fill_qt = PatternFill(start_color="16A34A", end_color="16A34A",
                                      fill_type="solid")
                _write_header_row(ws, cur, list(df_qt.columns), fill=fill_qt)
                cur = _write_data_rows(ws, df_qt, cur + 1, alt_fill=ALT_FILL) + 3

            # Boxplots individuels
            ws.cell(row=cur, column=1, value="Boxplots individuels").font = \
                Font(name="Calibri", size=11, bold=True, color="16A34A")
            cur += 2

            for var in data_manager.quantitative_vars:
                series = pd.to_numeric(data_manager.df[var],
                                        errors="coerce").dropna()
                if len(series) < 2:
                    continue
                series.name = var
                img_bytes, _ = auto_chart(series, var, "quantitative", dpi=130)

                ws.cell(row=cur, column=1, value=f"Boxplot — {var}").font = \
                    Font(name="Calibri", size=10, bold=True, color="1E293B")
                _insert_chart_excel(ws, img_bytes, f"A{cur + 1}",
                                     w_cm=10, h_cm=8)
                cur += 26

            _auto_col_width(ws)

    # ── Groupes ────────────────────────────────────────────────────────────────
    if selections.get("groups") and data_manager.variable_groups:
        ws = wb.create_sheet("Groupes")
        ws.sheet_view.showGridLines = False
        _section_title(ws, 1, "Analyse descriptive par groupe")
        cur = 3

        for grp_name, grp_vars in data_manager.variable_groups.items():
            ws.cell(row=cur, column=1,
                    value=f"Groupe : {grp_name}").font = \
                Font(name="Calibri", size=11, bold=True, color="7C3AED")
            cur += 1

            df_grp = data_manager.get_group_descriptive_table(grp_name)
            if not df_grp.empty:
                fill_g = PatternFill(start_color="7C3AED", end_color="7C3AED",
                                     fill_type="solid")
                _write_header_row(ws, cur, list(df_grp.columns), fill=fill_g)
                cur = _write_data_rows(ws, df_grp, cur + 1, alt_fill=ALT_FILL) + 2

            # Graphiques des variables du groupe
            ws.cell(row=cur, column=1,
                    value="Graphiques").font = \
                Font(name="Calibri", size=10, bold=True, color="7C3AED")
            cur += 1

            for var in grp_vars:
                if var not in data_manager.df.columns:
                    continue
                series = data_manager.df[var].dropna()
                var_type = ("qualitative" if var in data_manager.qualitative_vars
                             else "quantitative")
                if var_type == "quantitative":
                    series = pd.to_numeric(series, errors="coerce").dropna()
                if len(series) < 2:
                    continue
                series.name = var
                img_bytes, chart_type = auto_chart(series, var, var_type, dpi=110)

                ws.cell(row=cur, column=1, value=var).font = \
                    Font(name="Calibri", size=9, italic=True, color="64748B")
                _insert_chart_excel(ws, img_bytes, f"A{cur + 1}",
                                     w_cm=9, h_cm=6.5)
                cur += 22

            cur += 2

        _auto_col_width(ws)

    # ── Bivariée ───────────────────────────────────────────────────────────────
    if selections.get("bivariate"):
        biv_results = selections.get("bivariate_data", [])
        if biv_results:
            ws = wb.create_sheet("Analyse bivariée")
            ws.sheet_view.showGridLines = False

            clean = [{k: v for k, v in r.items() if not k.startswith("__")}
                     for r in biv_results]
            df_biv = pd.DataFrame(clean)
            ordered = (["Variable", "Modalité"] +
                       [c for c in df_biv.columns
                        if c not in ("Variable", "Modalité")])
            df_biv = df_biv.reindex(
                columns=[c for c in ordered if c in df_biv.columns])

            _section_title(ws, 1, "Analyse bivariée — Format publication")
            _write_header_row(ws, 3, list(df_biv.columns), fill=GREEN_HDR)
            _write_data_rows(ws, df_biv, 4,
                              alt_fill=GREEN_ALT, row_meta=biv_results)
            _auto_col_width(ws)

    wb.save(output_path)


# ═══════════════════════════════════════════════ Utilitaires Word ══════════════

def _set_cell_bg(cell, hex_color: str):
    tc   = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd  = OxmlElement("w:shd")
    shd.set(qn("w:val"),   "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"),  hex_color)
    tcPr.append(shd)


def _word_heading(doc, text: str, level: int, color: RGBColor):
    h = doc.add_heading(text, level=level)
    if h.runs:
        h.runs[0].font.color.rgb = color
    return h


def _add_table_word(doc: Document, df: pd.DataFrame,
                     header_color: str = "1E3A5F",
                     row_meta: list = None):
    if df.empty:
        return
    table = doc.add_table(rows=1, cols=len(df.columns))
    table.style = "Table Grid"

    # En-têtes
    hdr = table.rows[0].cells
    for i, col_name in enumerate(df.columns):
        hdr[i].text = str(col_name)
        _set_cell_bg(hdr[i], header_color)
        p = hdr[i].paragraphs[0]
        if p.runs:
            p.runs[0].font.bold = True
            p.runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            p.runs[0].font.size = Pt(8)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Données
    for idx, row_data in enumerate(df.itertuples(index=False)):
        meta       = (row_meta or [{}] * len(df))[idx]
        is_ref     = meta.get("__is_ref__",       False)
        is_section = meta.get("__is_section__",   False)
        is_first   = meta.get("__var_first_row__", False)
        bg         = "EFF6FF" if idx % 2 == 1 else "FFFFFF"

        cells = table.add_row().cells
        for j, (col_name, val) in enumerate(zip(df.columns, row_data)):
            txt = str(val) if pd.notna(val) and str(val) != "nan" else ""
            cells[j].text = txt
            _set_cell_bg(cells[j], "4E9E72" if is_section else bg)
            p   = cells[j].paragraphs[0]
            if not p.runs:
                continue
            run = p.runs[0]
            run.font.size = Pt(8)

            if is_section:
                run.font.bold = True
                run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            elif col_name == "Variable" and is_first:
                run.font.bold = True
                run.font.color.rgb = RGBColor(0x1E, 0x29, 0x3B)
            elif col_name == "Modalité" and is_ref:
                run.font.italic = True
                run.font.color.rgb = RGBColor(0x64, 0x74, 0x8B)
            elif col_name == "Test / OR [IC 95%]":
                if txt == "Réf.":
                    run.font.italic = True
                    run.font.color.rgb = RGBColor(0x64, 0x74, 0x8B)
                elif txt not in ("—", ""):
                    run.font.bold = True
                    run.font.color.rgb = RGBColor(0x15, 0x80, 0x3D)
            elif col_name == "p" and txt not in ("—", ""):
                run.font.bold = True
                run.font.color.rgb = RGBColor(0x1E, 0x3A, 0x5F)

            if col_name not in ("Variable", "Modalité"):
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph()


def _insert_chart_word(doc: Document, img_bytes: bytes,
                        caption: str = "", width_inches: float = 5.2):
    if not img_bytes:
        return
    buf = io.BytesIO(img_bytes)
    doc.add_picture(buf, width=Inches(width_inches))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER

    if caption:
        p = doc.add_paragraph(caption)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if p.runs:
            p.runs[0].font.size   = Pt(8)
            p.runs[0].font.italic = True
            p.runs[0].font.color.rgb = RGBColor(0x64, 0x74, 0x8B)
    doc.add_paragraph()


# ═══════════════════════════════════════════════ Export Word ═══════════════════

BLUE  = RGBColor(0x1E, 0x3A, 0x5F)

_CHART_LABELS = {"pie": "Camembert", "bar": "Diagramme en barres", "boxplot": "Boxplot"}


def export_word(data_manager, output_path: str, selections: dict):
    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(11)
    for section in doc.sections:
        section.top_margin    = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin   = Cm(2.5)
        section.right_margin  = Cm(2.5)

    # ── Page de titre ──────────────────────────────────────────────────────────
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("RAPPORT D'ANALYSE STATISTIQUE")
    r.font.size = Pt(20); r.font.bold = True; r.font.color.rgb = BLUE

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run("StatAnalyzer — Logiciel d'analyse pour la recherche médicale")
    r2.font.size = Pt(12); r2.font.color.rgb = RGBColor(0x47, 0x55, 0x69)

    doc.add_paragraph()
    meta = doc.add_paragraph()
    meta.add_run(f"Date : {datetime.now().strftime('%d/%m/%Y %H:%M')}\n").font.size = Pt(10)
    if data_manager.file_path:
        meta.add_run(f"Fichier : {Path(data_manager.file_path).name}\n").font.size = Pt(10)
    if data_manager.df is not None:
        meta.add_run(
            f"Observations : {len(data_manager.df)}  |  "
            f"Variables : {len(data_manager.df.columns)}"
        ).font.size = Pt(10)
    doc.add_page_break()

    # ── 1. Complétude ──────────────────────────────────────────────────────────
    if selections.get("completeness") and data_manager.df is not None:
        _word_heading(doc, "1. Analyse de complétude des données", 1, BLUE)
        _add_table_word(doc, data_manager.get_completeness_table(), "1E3A5F")

    # ── 2. Statistiques descriptives ───────────────────────────────────────────
    if selections.get("descriptive") and data_manager.df is not None:
        _word_heading(doc, "2. Statistiques descriptives", 1, BLUE)

        # 2.1 Qualitatives
        if data_manager.qualitative_vars:
            _word_heading(doc, "2.1 Variables qualitatives", 2,
                          RGBColor(0x25, 0x63, 0xEB))

            for var in data_manager.qualitative_vars:
                df_q = data_manager.get_qualitative_stats(var)
                if df_q.empty:
                    continue

                series = data_manager.df[var].dropna()
                img_bytes, chart_type = auto_chart(series, var, "qualitative", dpi=150)

                # Titre
                pv = doc.add_paragraph()
                rv = pv.add_run(var)
                rv.bold = True; rv.font.size = Pt(10)
                rv.font.color.rgb = RGBColor(0x25, 0x63, 0xEB)

                # Tableau
                _add_table_word(doc, df_q, "2563EB")

                # Graphique
                caption = (f"Figure — {var}  "
                           f"({_CHART_LABELS.get(chart_type, chart_type)})  "
                           f"[N = {len(series)}]")
                _insert_chart_word(doc, img_bytes, caption=caption, width_inches=4.8)

        # 2.2 Quantitatives
        if data_manager.quantitative_vars:
            _word_heading(doc, "2.2 Variables quantitatives", 2,
                          RGBColor(0x16, 0xA3, 0x4A))

            # Tableau récap global
            all_stats = []
            for var in data_manager.quantitative_vars:
                s = data_manager.get_quantitative_stats(var)
                if s:
                    s["Variable"] = var; all_stats.append(s)

            if all_stats:
                COLS = ["Variable", "N", "Moyenne", "Médiane", "Mode",
                        "Minimum", "Maximum", "Écart-type",
                        "Q1 (25%)", "Q3 (75%)", "IQR"]
                df_qt = pd.DataFrame(all_stats)
                df_qt = df_qt[[c for c in COLS if c in df_qt.columns]]
                _add_table_word(doc, df_qt, "16A34A")

            # Boxplot individuel par variable
            for var in data_manager.quantitative_vars:
                series = pd.to_numeric(data_manager.df[var],
                                        errors="coerce").dropna()
                if len(series) < 2:
                    continue
                series.name = var
                img_bytes, _ = auto_chart(series, var, "quantitative", dpi=150)

                pv = doc.add_paragraph()
                rv = pv.add_run(var)
                rv.bold = True; rv.font.size = Pt(10)
                rv.font.color.rgb = RGBColor(0x16, 0xA3, 0x4A)

                caption = f"Figure — Boxplot de {var}  [N = {len(series)}]"
                _insert_chart_word(doc, img_bytes, caption=caption, width_inches=4.2)

    # ── 3. Groupes ─────────────────────────────────────────────────────────────
    if selections.get("groups") and data_manager.variable_groups:
        _word_heading(doc, "3. Analyse descriptive par groupe", 1, BLUE)

        for grp_name, grp_vars in data_manager.variable_groups.items():
            _word_heading(doc, f"Groupe : {grp_name}", 2,
                          RGBColor(0x7C, 0x3A, 0xED))

            pi = doc.add_paragraph(f"Variables : {', '.join(grp_vars)}")
            if pi.runs:
                pi.runs[0].font.size = Pt(9); pi.runs[0].font.italic = True

            df_grp = data_manager.get_group_descriptive_table(grp_name)
            if not df_grp.empty:
                _add_table_word(doc, df_grp, "7C3AED")

            # Graphique par variable du groupe
            for var in grp_vars:
                if var not in data_manager.df.columns:
                    continue
                series = data_manager.df[var].dropna()
                var_type = ("qualitative" if var in data_manager.qualitative_vars
                             else "quantitative")
                if var_type == "quantitative":
                    series = pd.to_numeric(series, errors="coerce").dropna()
                if len(series) < 2:
                    continue
                series.name = var
                img_bytes, chart_type = auto_chart(series, var, var_type, dpi=150)
                caption = (f"Figure — {var}  "
                           f"({_CHART_LABELS.get(chart_type, chart_type)})  "
                           f"[N = {len(series)}]")
                _insert_chart_word(doc, img_bytes, caption=caption, width_inches=4.5)

    # ── 4. Bivariée ────────────────────────────────────────────────────────────
    if selections.get("bivariate"):
        biv_results = selections.get("bivariate_data", [])
        if biv_results:
            _word_heading(doc, "4. Analyse bivariée", 1, BLUE)
            clean = [{k: v for k, v in r.items() if not k.startswith("__")}
                     for r in biv_results]
            if clean:
                df_biv = pd.DataFrame(clean)
                ordered = (["Variable", "Modalité"] +
                           [c for c in df_biv.columns
                            if c not in ("Variable", "Modalité")])
                df_biv = df_biv.reindex(
                    columns=[c for c in ordered if c in df_biv.columns])
                _add_table_word(doc, df_biv, "2E7D52", row_meta=biv_results)

    doc.save(output_path)
