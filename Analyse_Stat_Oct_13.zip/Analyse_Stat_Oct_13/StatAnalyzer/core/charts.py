"""
Module de génération de graphiques
"""

import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


COLORS = ['#2563EB', '#16A34A', '#DC2626', '#D97706', '#7C3AED',
          '#0891B2', '#BE185D', '#65A30D', '#EA580C', '#4338CA']

CHART_STYLE = {
    'axes.facecolor': '#F8FAFC',
    'figure.facecolor': '#FFFFFF',
    'axes.edgecolor': '#CBD5E1',
    'axes.labelcolor': '#1E293B',
    'xtick.color': '#475569',
    'ytick.color': '#475569',
    'grid.color': '#E2E8F0',
    'grid.linewidth': 0.8,
    'font.family': 'DejaVu Sans',
}


def apply_style(ax, title="", xlabel="", ylabel=""):
    ax.set_title(title, fontsize=13, fontweight='bold', color='#1E293B', pad=12)
    ax.set_xlabel(xlabel, fontsize=10, color='#475569')
    ax.set_ylabel(ylabel, fontsize=10, color='#475569')
    ax.grid(axis='y', alpha=0.5, linestyle='--')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#CBD5E1')
    ax.spines['bottom'].set_color('#CBD5E1')


def create_bar_chart(data: pd.DataFrame, col: str) -> Figure:
    """Diagramme en barres pour variable qualitative"""
    with plt.style.context(CHART_STYLE):
        fig, ax = plt.subplots(figsize=(8, 5))
        stats = data[col].value_counts()
        bars = ax.bar(range(len(stats)), stats.values,
                      color=COLORS[:len(stats)], width=0.6, edgecolor='white', linewidth=1.2)

        ax.set_xticks(range(len(stats)))
        ax.set_xticklabels([str(l) for l in stats.index], rotation=30, ha='right', fontsize=9)

        for bar, val in zip(bars, stats.values):
            pct = val / stats.values.sum() * 100
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.3,
                    f'{val}\n({pct:.1f}%)',
                    ha='center', va='bottom', fontsize=8.5, color='#1E293B')

        apply_style(ax, title=f"Distribution — {col}", ylabel="Effectif")
        fig.tight_layout()
    return fig


def create_pie_chart(data: pd.DataFrame, col: str) -> Figure:
    """Diagramme circulaire pour variable qualitative"""
    with plt.style.context(CHART_STYLE):
        fig, ax = plt.subplots(figsize=(7, 6))
        stats = data[col].value_counts()

        wedges, texts, autotexts = ax.pie(
            stats.values,
            labels=None,
            autopct='%1.1f%%',
            colors=COLORS[:len(stats)],
            startangle=140,
            pctdistance=0.8,
            wedgeprops={'edgecolor': 'white', 'linewidth': 1.5},
        )
        for t in autotexts:
            t.set_fontsize(9)
            t.set_color('white')
            t.set_fontweight('bold')

        legend_labels = [f"{label} (n={val})" for label, val in zip(stats.index, stats.values)]
        ax.legend(wedges, legend_labels, loc='lower center',
                  bbox_to_anchor=(0.5, -0.12), ncol=2, fontsize=9, framealpha=0.8)

        ax.set_title(f"Distribution — {col}", fontsize=13, fontweight='bold',
                     color='#1E293B', pad=12)
        fig.tight_layout()
    return fig


def create_histogram(data: pd.DataFrame, col: str) -> Figure:
    """Histogramme pour variable quantitative"""
    with plt.style.context(CHART_STYLE):
        series = pd.to_numeric(data[col], errors='coerce').dropna()
        fig, ax = plt.subplots(figsize=(8, 5))

        n_bins = min(30, max(10, len(series) // 10))
        n, bins, patches = ax.hist(series, bins=n_bins, color='#2563EB',
                                   edgecolor='white', linewidth=0.8, alpha=0.85)

        # Courbe de densité
        from scipy.stats import gaussian_kde
        if len(series) > 3:
            try:
                kde = gaussian_kde(series)
                x_range = np.linspace(series.min(), series.max(), 200)
                ax2 = ax.twinx()
                ax2.plot(x_range, kde(x_range), color='#DC2626', linewidth=2, label='Densité')
                ax2.set_ylabel('Densité', fontsize=9, color='#DC2626')
                ax2.tick_params(axis='y', colors='#DC2626')
                ax2.spines['top'].set_visible(False)
                ax2.yaxis.set_tick_params(labelsize=8)
            except Exception:
                pass

        # Ligne moyenne / médiane
        ax.axvline(series.mean(), color='#F59E0B', linewidth=1.8, linestyle='--',
                   label=f'Moyenne: {series.mean():.2f}')
        ax.axvline(series.median(), color='#16A34A', linewidth=1.8, linestyle='-.',
                   label=f'Médiane: {series.median():.2f}')
        ax.legend(fontsize=8.5, loc='upper right')

        apply_style(ax, title=f"Histogramme — {col}", xlabel=col, ylabel="Fréquence")
        fig.tight_layout()
    return fig


def create_boxplot(data: pd.DataFrame, col: str, group_col: str = None) -> Figure:
    """Boxplot pour variable quantitative"""
    with plt.style.context(CHART_STYLE):
        series = pd.to_numeric(data[col], errors='coerce')
        fig, ax = plt.subplots(figsize=(7, 5))

        if group_col and group_col in data.columns:
            groups = data[group_col].dropna().unique()
            plot_data = [pd.to_numeric(data[col][data[group_col] == g], errors='coerce').dropna()
                         for g in groups]
            bp = ax.boxplot(plot_data, patch_artist=True, notch=False,
                            medianprops={'color': '#DC2626', 'linewidth': 2})
            for patch, color in zip(bp['boxes'], COLORS):
                patch.set_facecolor(color)
                patch.set_alpha(0.7)
            ax.set_xticklabels(groups, rotation=30, ha='right', fontsize=9)
            title = f"Boxplot — {col} par {group_col}"
        else:
            bp = ax.boxplot(series.dropna(), patch_artist=True,
                            medianprops={'color': '#DC2626', 'linewidth': 2})
            bp['boxes'][0].set_facecolor('#2563EB')
            bp['boxes'][0].set_alpha(0.7)
            title = f"Boxplot — {col}"

        apply_style(ax, title=title, ylabel=col)
        fig.tight_layout()
    return fig
