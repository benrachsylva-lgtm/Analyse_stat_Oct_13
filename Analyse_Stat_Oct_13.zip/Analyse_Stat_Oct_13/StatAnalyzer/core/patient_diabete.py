"""
Module dossier clinique — Patient diabétique
Modèle de données, calculs automatiques et génération de rapport
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Optional
import math


# ─────────────────────────────────────────────────────────────────────────────
# Modèle de données
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PatientDiabete:
    # ── Identité ───────────────────────────────────────────────────────────
    nom:          str  = ""
    prenom:       str  = ""
    date_naissance: str = ""   # JJ/MM/AAAA
    sexe:         str  = ""    # "Masculin" | "Féminin"
    adresse:      str  = ""
    telephone:    str  = ""
    num_dossier:  str  = ""
    date_consultation: str = ""

    # ── Antécédents ────────────────────────────────────────────────────────
    type_diabete: str  = ""    # "Type 1" | "Type 2" | "Gestationnel" | "MODY" | "Autre"
    date_diagnostic: str = ""
    duree_diabete: str = ""    # calculée automatiquement si date_diagnostic renseignée
    antecedents_familiaux: str = ""
    antecedents_personnels: str = ""
    allergies:    str  = ""

    # ── Traitement actuel ──────────────────────────────────────────────────
    traitement_insuline: bool = False
    traitement_aod:      bool = False   # antidiabétiques oraux
    traitement_autre:    str  = ""
    detail_traitement:   str  = ""
    observance:          str  = ""   # "Bonne" | "Moyenne" | "Mauvaise"

    # ── A. Paramètres cliniques ────────────────────────────────────────────
    # Poids / IMC
    poids:   Optional[float] = None   # kg
    taille:  Optional[float] = None   # cm
    tour_taille: Optional[float] = None  # cm

    # Pression artérielle
    pa_systolique:  Optional[float] = None   # mmHg
    pa_diastolique: Optional[float] = None   # mmHg

    # Symptômes hyperglycémie (cases à cocher)
    sym_polyurie:    bool = False
    sym_polydipsie:  bool = False
    sym_polyphagie:  bool = False
    sym_amaigrissement: bool = False
    sym_fatigue:     bool = False
    sym_autres:      str  = ""

    # Hypoglycémie
    hypo_sueurs:       bool = False
    hypo_tremblements: bool = False
    hypo_confusion:    bool = False
    hypo_palpitations: bool = False

    # Examen des pieds
    pied_plaie:          bool = False
    pied_ulceration:     bool = False
    pied_mycose:         bool = False
    pied_perte_sensibilite: bool = False
    pied_deformation:    bool = False
    pied_commentaire:    str  = ""

    # Neuropathie
    neuro_paresthesies:  bool = False
    neuro_douleurs:      bool = False
    neuro_hypoesthesie:  bool = False
    neuro_perte_sensib_plantaire: bool = False

    # Cardiovasculaire
    cv_insuffisance_cardiaque: bool = False
    cv_arteriopathie:   bool = False
    cv_avc:             bool = False
    cv_coronaropathie:  bool = False

    # Ophtalmologie
    ophtalmo_retinopathie: bool = False
    ophtalmo_baisse_vision: bool = False
    dernier_fond_oeil:   str  = ""   # date

    # ── B. Paramètres biologiques ──────────────────────────────────────────
    glycemie_jeun:         Optional[float] = None   # mmol/L ou g/L
    glycemie_jeun_unite:   str = "g/L"
    glycemie_postprandiale: Optional[float] = None
    glycemie_pp_unite:     str = "g/L"

    hba1c:                 Optional[float] = None   # %

    creatinine:            Optional[float] = None   # µmol/L
    dfg:                   Optional[float] = None   # mL/min/1,73m²

    albuminurie:           Optional[float] = None   # mg/24h
    microalbuminurie_positive: bool = False

    chol_total:            Optional[float] = None   # g/L
    ldl:                   Optional[float] = None
    hdl:                   Optional[float] = None
    triglycerides:         Optional[float] = None

    cetonemie:             Optional[float] = None   # mmol/L
    cetonurie:             str = ""    # "Négative" | "+" | "++" | "+++"

    bu_glucose:    str = ""   # bandelette
    bu_proteines:  str = ""
    bu_infection:  str = ""

    # ── C. Paracliniques ──────────────────────────────────────────────────
    ecg_resultat:          str  = ""
    doppler_resultat:      str  = ""

    # ── Conclusion ─────────────────────────────────────────────────────────
    equilibre_glycemique:  str  = ""   # "Bon" | "Moyen" | "Mauvais"
    complications_actives: str  = ""
    plan_therapeutique:    str  = ""
    prochain_rdv:          str  = ""
    notes_medecin:         str  = ""

    # ── Praticien ─────────────────────────────────────────────────────────
    medecin_nom:           str  = ""
    medecin_service:       str  = ""
    medecin_signature:     str  = ""


# ─────────────────────────────────────────────────────────────────────────────
# Calculs automatiques
# ─────────────────────────────────────────────────────────────────────────────

def calculer_imc(poids_kg: float, taille_cm: float) -> Optional[float]:
    if poids_kg and taille_cm and taille_cm > 0:
        taille_m = taille_cm / 100
        return round(poids_kg / (taille_m ** 2), 1)
    return None


def interpreter_imc(imc: float) -> str:
    if imc < 18.5:  return "Insuffisance pondérale"
    if imc < 25.0:  return "Corpulence normale"
    if imc < 30.0:  return "Surpoids"
    if imc < 35.0:  return "Obésité modérée (classe I)"
    if imc < 40.0:  return "Obésité sévère (classe II)"
    return "Obésité morbide (classe III)"


def interpreter_hba1c(hba1c: float) -> tuple[str, str]:
    """Retourne (interprétation, couleur_hex)"""
    if hba1c < 6.5:
        return "Objectif atteint (< 6,5 %)", "#16A34A"
    if hba1c < 7.0:
        return "Objectif atteint (< 7 %)", "#16A34A"
    if hba1c < 8.0:
        return "Contrôle insuffisant — à optimiser", "#D97706"
    if hba1c < 9.0:
        return "Mauvais équilibre — révision traitement", "#EA580C"
    return "Déséquilibre sévère — risque de complications", "#DC2626"


def interpreter_pa(syst: float, diast: float) -> tuple[str, str]:
    if syst < 120 and diast < 80:
        return "Normale", "#16A34A"
    if syst < 130 and diast < 80:
        return "Normale haute", "#65A30D"
    if syst < 140 or diast < 90:
        return "HTA stade 1", "#D97706"
    if syst < 160 or diast < 100:
        return "HTA stade 2 — objectif non atteint", "#EA580C"
    return "HTA sévère — urgence thérapeutique", "#DC2626"


def interpreter_glycemie_jeun(val: float, unite: str) -> tuple[str, str]:
    """Convertit en g/L si nécessaire, puis interprète."""
    v = val
    if unite == "mmol/L":
        v = val * 0.18  # conversion approximative mmol/L → g/L
    if v < 0.70:
        return "Hypoglycémie", "#DC2626"
    if v < 1.10:
        return "Normale", "#16A34A"
    if v < 1.26:
        return "Hyperglycémie modérée à jeun", "#D97706"
    return "Diabète non contrôlé", "#DC2626"


def interpreter_dfg(dfg: float) -> tuple[str, str]:
    if dfg >= 90:   return "G1 — Normale ou augmentée", "#16A34A"
    if dfg >= 60:   return "G2 — Légèrement diminuée", "#65A30D"
    if dfg >= 45:   return "G3a — Légère à modérée", "#D97706"
    if dfg >= 30:   return "G3b — Modérée à sévère", "#EA580C"
    if dfg >= 15:   return "G4 — Sévèrement diminuée", "#DC2626"
    return "G5 — Insuffisance rénale terminale", "#7C3AED"


def calculer_age(date_naissance_str: str) -> Optional[int]:
    try:
        j, m, a = date_naissance_str.strip().split("/")
        dn = date(int(a), int(m), int(j))
        today = date.today()
        return today.year - dn.year - ((today.month, today.day) < (dn.month, dn.day))
    except Exception:
        return None


def calculer_duree_diabete(date_diag_str: str) -> Optional[str]:
    try:
        j, m, a = date_diag_str.strip().split("/")
        dd = date(int(a), int(m), int(j))
        today = date.today()
        ans = today.year - dd.year - ((today.month, today.day) < (dd.month, dd.day))
        mois = (today.month - dd.month) % 12
        if ans > 0:
            return f"{ans} an(s) {mois} mois"
        return f"{mois} mois"
    except Exception:
        return None


def score_risque_cardiovasculaire(p: PatientDiabete) -> tuple[int, str, str]:
    """Score simplifié de risque CV (0-10)."""
    score = 0
    if p.hba1c and p.hba1c >= 8:       score += 2
    if p.pa_systolique and p.pa_systolique >= 140: score += 2
    if p.ldl and p.ldl > 1.3:          score += 1
    if p.triglycerides and p.triglycerides > 1.5: score += 1
    poids, taille = p.poids, p.taille
    if poids and taille:
        imc = calculer_imc(poids, taille)
        if imc and imc >= 30:           score += 1
    if p.cv_coronaropathie or p.cv_avc or p.cv_arteriopathie: score += 3
    if p.type_diabete == "Type 2":      score += 1

    age = calculer_age(p.date_naissance)
    if age and age >= 65:               score += 1

    if score <= 2:   return score, "Faible",  "#16A34A"
    if score <= 5:   return score, "Modéré",  "#D97706"
    if score <= 7:   return score, "Élevé",   "#EA580C"
    return score, "Très élevé", "#DC2626"


# ─────────────────────────────────────────────────────────────────────────────
# Export Word du dossier
# ─────────────────────────────────────────────────────────────────────────────

def exporter_dossier_word(p: PatientDiabete, output_path: str):
    from docx import Document
    from docx.shared import Pt, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    doc = Document()

    # Marges
    for s in doc.sections:
        s.top_margin    = Cm(2)
        s.bottom_margin = Cm(2)
        s.left_margin   = Cm(2.5)
        s.right_margin  = Cm(2.5)

    def _shd(cell, hex_c):
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'), 'clear')
        shd.set(qn('w:color'), 'auto')
        shd.set(qn('w:fill'), hex_c)
        tcPr.append(shd)

    def h1(txt, color="1E3A5F"):
        p = doc.add_paragraph()
        run = p.add_run(txt)
        run.bold = True
        run.font.size = Pt(13)
        run.font.color.rgb = RGBColor(
            int(color[0:2],16), int(color[2:4],16), int(color[4:6],16))
        p.paragraph_format.space_before = Pt(10)
        p.paragraph_format.space_after  = Pt(3)
        # Trait sous le titre
        border = OxmlElement('w:pBdr')
        bottom = OxmlElement('w:bottom')
        bottom.set(qn('w:val'), 'single')
        bottom.set(qn('w:sz'), '6')
        bottom.set(qn('w:space'), '1')
        bottom.set(qn('w:color'), color)
        border.append(bottom)
        p._p.get_or_add_pPr().append(border)

    def h2(txt, color="2563EB"):
        p = doc.add_paragraph()
        run = p.add_run(f"  {txt}")
        run.bold = True
        run.font.size = Pt(10)
        run.font.color.rgb = RGBColor(
            int(color[0:2],16), int(color[2:4],16), int(color[4:6],16))
        p.paragraph_format.space_before = Pt(6)

    def row2(label, value, table=None):
        if table is None:
            doc.add_paragraph(f"• {label} : {value or '—'}",
                               style='Normal').runs[0].font.size = Pt(9)
            return
        r = table.add_row()
        r.cells[0].text = label
        r.cells[1].text = str(value) if value else "—"
        r.cells[0].paragraphs[0].runs[0].font.bold = True
        r.cells[0].paragraphs[0].runs[0].font.size = Pt(9)
        r.cells[1].paragraphs[0].runs[0].font.size = Pt(9)

    def add_table(labels_values: list, header=None, h_color="1E3A5F"):
        t = doc.add_table(rows=0, cols=2)
        t.style = 'Table Grid'
        if header:
            hr = t.add_row()
            hr.cells[0].merge(hr.cells[1])
            hr.cells[0].text = header
            for run in hr.cells[0].paragraphs[0].runs:
                run.font.bold  = True
                run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                run.font.size  = Pt(9)
            _shd(hr.cells[0], h_color)
        for label, value in labels_values:
            r = t.add_row()
            r.cells[0].text = str(label)
            r.cells[1].text = str(value) if value not in (None, "") else "—"
            r.cells[0].paragraphs[0].runs[0].font.bold = True
            r.cells[0].paragraphs[0].runs[0].font.size = Pt(9)
            r.cells[1].paragraphs[0].runs[0].font.size = Pt(9)
        # Largeur colonnes
        from docx.shared import Cm as Cm2
        for row in t.rows:
            row.cells[0].width = Cm2(5)
            row.cells[1].width = Cm2(10)
        doc.add_paragraph()
        return t

    def coche(val: bool) -> str:
        return "✔ Oui" if val else "✘ Non"

    def liste_coches(items: list[tuple[str,bool]]) -> str:
        pos = [n for n, v in items if v]
        return ", ".join(pos) if pos else "Aucun"

    # ═══════════════════════════════════════════════════════════════
    # PAGE DE TITRE
    # ═══════════════════════════════════════════════════════════════
    titre = doc.add_paragraph()
    titre.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = titre.add_run("DOSSIER CLINIQUE — PATIENT DIABÉTIQUE")
    run.font.bold = True
    run.font.size = Pt(16)
    run.font.color.rgb = RGBColor(0x1E, 0x3A, 0x5F)

    doc.add_paragraph()
    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.add_run(f"Consulté le : {p.date_consultation or datetime.now().strftime('%d/%m/%Y')}  |  "
                f"Dossier N° : {p.num_dossier or '—'}  |  "
                f"Dr {p.medecin_nom or '—'}").font.size = Pt(10)

    doc.add_paragraph()

    # ═══════════════════════════════════════════════════════════════
    # 1. IDENTITÉ
    # ═══════════════════════════════════════════════════════════════
    h1("1. IDENTITÉ DU PATIENT")
    age = calculer_age(p.date_naissance)
    add_table([
        ("Nom & Prénom",       f"{p.nom.upper()} {p.prenom}"),
        ("Date de naissance",  f"{p.date_naissance}  ({'–' if not age else str(age)+' ans'})"),
        ("Sexe",               p.sexe),
        ("Téléphone",          p.telephone),
        ("Adresse",            p.adresse),
    ], header="Informations administratives")

    # ═══════════════════════════════════════════════════════════════
    # 2. ANTÉCÉDENTS
    # ═══════════════════════════════════════════════════════════════
    h1("2. ANTÉCÉDENTS & HISTOIRE DU DIABÈTE")
    duree = calculer_duree_diabete(p.date_diagnostic) if p.date_diagnostic else p.duree_diabete
    add_table([
        ("Type de diabète",         p.type_diabete),
        ("Date du diagnostic",      p.date_diagnostic),
        ("Durée du diabète",        duree),
        ("Antécédents familiaux",   p.antecedents_familiaux),
        ("Antécédents personnels",  p.antecedents_personnels),
        ("Allergies connues",       p.allergies),
    ], header="Historique", h_color="2563EB")

    # ═══════════════════════════════════════════════════════════════
    # 3. TRAITEMENT
    # ═══════════════════════════════════════════════════════════════
    h1("3. TRAITEMENT EN COURS")
    traitements = []
    if p.traitement_insuline: traitements.append("Insulinothérapie")
    if p.traitement_aod:      traitements.append("Antidiabétiques oraux")
    if p.traitement_autre:    traitements.append(p.traitement_autre)
    add_table([
        ("Type(s) de traitement",   ", ".join(traitements) or "—"),
        ("Détail",                  p.detail_traitement),
        ("Observance",              p.observance),
    ], header="Traitement", h_color="7C3AED")

    # ═══════════════════════════════════════════════════════════════
    # 4. PARAMÈTRES CLINIQUES
    # ═══════════════════════════════════════════════════════════════
    h1("4. PARAMÈTRES CLINIQUES")

    h2("A. Poids & IMC")
    imc = calculer_imc(p.poids, p.taille) if p.poids and p.taille else None
    interp_imc = interpreter_imc(imc) if imc else "—"
    add_table([
        ("Poids",        f"{p.poids} kg"   if p.poids  else "—"),
        ("Taille",       f"{p.taille} cm"  if p.taille else "—"),
        ("Tour de taille", f"{p.tour_taille} cm" if p.tour_taille else "—"),
        ("IMC calculé",  f"{imc} kg/m²  →  {interp_imc}" if imc else "—"),
    ], h_color="0891B2")

    h2("B. Pression artérielle")
    if p.pa_systolique and p.pa_diastolique:
        interp_pa, _ = interpreter_pa(p.pa_systolique, p.pa_diastolique)
    else:
        interp_pa = "—"
    add_table([
        ("TA mesurée",   f"{p.pa_systolique or '–'}/{p.pa_diastolique or '–'} mmHg"),
        ("Interprétation", interp_pa),
        ("Objectif",     "< 140/90 mmHg (selon profil)"),
    ], h_color="0891B2")

    h2("C. Symptômes hyperglycémie")
    sym = liste_coches([
        ("Polyurie", p.sym_polyurie), ("Polydipsie", p.sym_polydipsie),
        ("Polyphagie", p.sym_polyphagie), ("Amaigrissement", p.sym_amaigrissement),
        ("Fatigue", p.sym_fatigue)
    ])
    add_table([
        ("Symptômes présents", sym),
        ("Autres",             p.sym_autres or "—"),
    ], h_color="0891B2")

    h2("D. Épisodes d'hypoglycémie")
    hypo = liste_coches([
        ("Sueurs", p.hypo_sueurs), ("Tremblements", p.hypo_tremblements),
        ("Confusion", p.hypo_confusion), ("Palpitations", p.hypo_palpitations)
    ])
    add_table([("Signes présents", hypo)], h_color="0891B2")

    h2("E. Examen des pieds")
    pied = liste_coches([
        ("Plaies", p.pied_plaie), ("Ulcérations", p.pied_ulceration),
        ("Mycoses", p.pied_mycose), ("Perte de sensibilité", p.pied_perte_sensibilite),
        ("Déformations", p.pied_deformation)
    ])
    add_table([
        ("Signes présents",  pied),
        ("Commentaire",      p.pied_commentaire or "—"),
    ], h_color="0891B2")

    h2("F. Évaluation neurologique")
    neuro = liste_coches([
        ("Paresthésies", p.neuro_paresthesies), ("Douleurs", p.neuro_douleurs),
        ("Hypoesthésie", p.neuro_hypoesthesie),
        ("Perte sensibilité plantaire", p.neuro_perte_sensib_plantaire)
    ])
    add_table([("Neuropathie — signes", neuro)], h_color="0891B2")

    h2("G. Examen cardiovasculaire")
    cv = liste_coches([
        ("Insuffisance cardiaque", p.cv_insuffisance_cardiaque),
        ("Artériopathie", p.cv_arteriopathie),
        ("AVC", p.cv_avc), ("Coronaropathie", p.cv_coronaropathie)
    ])
    add_table([("Complications CV présentes", cv)], h_color="0891B2")

    h2("H. Surveillance ophtalmologique")
    add_table([
        ("Rétinopathie",     coche(p.ophtalmo_retinopathie)),
        ("Baisse de vision", coche(p.ophtalmo_baisse_vision)),
        ("Dernier fond d'œil", p.dernier_fond_oeil or "—"),
    ], h_color="0891B2")

    doc.add_page_break()

    # ═══════════════════════════════════════════════════════════════
    # 5. PARAMÈTRES BIOLOGIQUES
    # ═══════════════════════════════════════════════════════════════
    h1("5. PARAMÈTRES BIOLOGIQUES")

    h2("A. Glycémie")
    if p.glycemie_jeun:
        ig, _ = interpreter_glycemie_jeun(p.glycemie_jeun, p.glycemie_jeun_unite)
    else:
        ig = "—"
    add_table([
        ("Glycémie à jeun",
         f"{p.glycemie_jeun} {p.glycemie_jeun_unite}  →  {ig}" if p.glycemie_jeun else "—"),
        ("Glycémie postprandiale",
         f"{p.glycemie_postprandiale} {p.glycemie_pp_unite}" if p.glycemie_postprandiale else "—"),
    ], header="Glycémie", h_color="DC2626")

    h2("B. HbA1c")
    if p.hba1c:
        ih, _ = interpreter_hba1c(p.hba1c)
    else:
        ih = "—"
    add_table([
        ("HbA1c",            f"{p.hba1c} %" if p.hba1c else "—"),
        ("Interprétation",   ih),
        ("Objectif habituel", "< 7 %  (selon âge et terrain)"),
    ], h_color="DC2626")

    h2("C. Fonction rénale")
    if p.dfg:
        id_dfg, _ = interpreter_dfg(p.dfg)
    else:
        id_dfg = "—"
    add_table([
        ("Créatinine",   f"{p.creatinine} µmol/L" if p.creatinine else "—"),
        ("DFG estimé",   f"{p.dfg} mL/min/1,73 m²  →  {id_dfg}" if p.dfg else "—"),
    ], h_color="DC2626")

    h2("D. Albuminurie")
    add_table([
        ("Albuminurie",              f"{p.albuminurie} mg/24h" if p.albuminurie else "—"),
        ("Microalbuminurie positive", coche(p.microalbuminurie_positive)),
    ], h_color="DC2626")

    h2("E. Bilan lipidique")
    add_table([
        ("Cholestérol total", f"{p.chol_total} g/L" if p.chol_total else "—"),
        ("LDL",               f"{p.ldl} g/L"        if p.ldl        else "—"),
        ("HDL",               f"{p.hdl} g/L"        if p.hdl        else "—"),
        ("Triglycérides",     f"{p.triglycerides} g/L" if p.triglycerides else "—"),
    ], h_color="DC2626")

    h2("F. Bandelette urinaire")
    add_table([
        ("Glucose",    p.bu_glucose   or "—"),
        ("Protéines",  p.bu_proteines or "—"),
        ("Infection",  p.bu_infection or "—"),
    ], h_color="DC2626")

    h2("G. Cétonémie / Cétonurie")
    add_table([
        ("Cétonémie",  f"{p.cetonemie} mmol/L" if p.cetonemie else "—"),
        ("Cétonurie",  p.cetonurie or "—"),
    ], h_color="DC2626")

    # ═══════════════════════════════════════════════════════════════
    # 6. PARACLINIQUES
    # ═══════════════════════════════════════════════════════════════
    h1("6. EXAMENS PARACLINIQUES")
    add_table([
        ("ECG",              p.ecg_resultat     or "—"),
        ("Doppler artériel", p.doppler_resultat or "—"),
        ("Fond d'œil",       p.dernier_fond_oeil or "—"),
    ], header="Résultats", h_color="4E9E72")

    # ═══════════════════════════════════════════════════════════════
    # 7. SYNTHÈSE & PLAN
    # ═══════════════════════════════════════════════════════════════
    h1("7. SYNTHÈSE & PLAN THÉRAPEUTIQUE")
    score, niveau_risque, _ = score_risque_cardiovasculaire(p)
    add_table([
        ("Équilibre glycémique",     p.equilibre_glycemique or "—"),
        ("Risque CV simplifié",      f"{niveau_risque}  (score {score}/10)"),
        ("Complications actives",    p.complications_actives or "—"),
        ("Plan thérapeutique",       p.plan_therapeutique or "—"),
        ("Prochain rendez-vous",     p.prochain_rdv or "—"),
        ("Notes du médecin",         p.notes_medecin or "—"),
    ], header="Conclusion", h_color="1E3A5F")

    # Signature
    doc.add_paragraph()
    sig_para = doc.add_paragraph()
    sig_para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    sig_run = sig_para.add_run(
        f"Dr {p.medecin_nom}  —  {p.medecin_service}\n"
        f"Date : {p.date_consultation or datetime.now().strftime('%d/%m/%Y')}"
    )
    sig_run.font.size = Pt(9)
    sig_run.italic = True

    doc.save(output_path)
