"""
Générateur de graphiques pour l'export (Word / Excel)
Produit des figures matplotlib sous forme de bytes PNG prêtes à intégrer.

Logique de sélection automatique :
  - Quantitative  → Boxplot
  - Qualitative   → Camembert si les 4 critères sont réunis, sinon Barres
      C1 : variable qualitative (toujours vrai ici)
      C2 : ≤ 5 modalités
      C3 : somme des proportions ≈ 100 %  (toujours vrai si données complètes)
      C4 : aucune modalité < 5 %
"""

import io
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')          # backend sans fenêtre (thread-safe pour l'export)
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.figure import Figure

# ─── Palette cohérente avec l'UI ─────────────────────────────────────────────
PALETTE = [
    "#2563EB", "#16A34A", "#DC2626", "#D97706",
    "#7C3AED", "#0891B2", "#BE185D", "#65A30D",
]

STYLE = {
    "axes.facecolor":    "#F8FAFC",
    "figure.facecolor":  "#FFFFFF",
    "axes.edgecolor":    "#CBD5E1",
    "axes.labelcolor":   "#1E293B",
    "xtick.color":       "#475569",
    "ytick.color":       "#475569",
    "grid.color":        "#E2E8F0",
    "grid.linewidth":    0.7,
    "font.family":       "DejaVu Sans",
}


# ─── Critères camembert ───────────────────────────────────────────────────────

def _should_use_pie(series: pd.Series) -> bool:
    """Vérifie les 4 critères pour choisir le camembert."""
    counts = series.value_counts(dropna=True)
    n_total = counts.sum()
    if n_total == 0:
        return False

    # C2 : ≤ 5 modalités
    if len(counts) > 5:
        return False

    # C3 : somme ≈ 100 % (toujours vrai sur données non-manquantes, mais on vérifie)
    if abs(counts.sum() - n_total) > 1:
        return False

    # C4 : aucune proportion < 5 %
    proportions = counts / n_total * 100
    if (proportions < 5).any():
        return False

    return True


# ─── Graphiques ───────────────────────────────────────────────────────────────

def _fig_to_bytes(fig: Figure, dpi: int = 150) -> bytes:
    """Convertit une figure matplotlib en bytes PNG."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close(fig)
    buf.seek(0)
    return buf.read()


def make_bar_chart(series: pd.Series, title: str, dpi: int = 150) -> bytes:
    """Diagramme en barres horizontal si > 4 modalités, vertical sinon."""
    with plt.style.context(STYLE):
        counts = series.value_counts(dropna=True).sort_index()
        n_cats = len(counts)
        n_total = counts.sum()

        horiz = n_cats > 4
        fig, ax = plt.subplots(figsize=(7, max(3.5, n_cats * 0.55)) if horiz else (7, 4))

        colors = [PALETTE[i % len(PALETTE)] for i in range(n_cats)]
        labels = [str(l) for l in counts.index]
        values = counts.values

        if horiz:
            bars = ax.barh(range(n_cats), values, color=colors,
                           edgecolor="white", linewidth=1, height=0.65)
            ax.set_yticks(range(n_cats))
            ax.set_yticklabels(labels, fontsize=9)
            ax.invert_yaxis()
            for bar, val in zip(bars, values):
                pct = val / n_total * 100
                ax.text(bar.get_width() + max(values) * 0.01,
                        bar.get_y() + bar.get_height() / 2,
                        f"{val} ({pct:.1f}%)",
                        va="center", ha="left", fontsize=8, color="#1E293B")
            ax.set_xlabel("Effectif", fontsize=9)
            ax.grid(axis="x", alpha=0.4, linestyle="--")
        else:
            bars = ax.bar(range(n_cats), values, color=colors,
                          edgecolor="white", linewidth=1.2, width=0.6)
            ax.set_xticks(range(n_cats))
            ax.set_xticklabels(labels, rotation=25 if n_cats > 3 else 0,
                               ha="right" if n_cats > 3 else "center", fontsize=9)
            for bar, val in zip(bars, values):
                pct = val / n_total * 100
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + max(values) * 0.015,
                        f"{val}\n({pct:.1f}%)",
                        ha="center", va="bottom", fontsize=8, color="#1E293B")
            ax.set_ylabel("Effectif", fontsize=9)
            ax.grid(axis="y", alpha=0.4, linestyle="--")

        # Cosmétique — pas de titre (géré par la légende du rapport)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        # Légende N total
        ax.annotate(f"N = {n_total}", xy=(0.98, 0.02),
                    xycoords="axes fraction", ha="right", va="bottom",
                    fontsize=8, color="#64748B",
                    bbox=dict(boxstyle="round,pad=0.3", fc="#F1F5F9", ec="#CBD5E1"))

        fig.tight_layout()
    return _fig_to_bytes(fig, dpi)


def make_pie_chart(series: pd.Series, title: str, dpi: int = 150) -> bytes:
    """Diagramme circulaire avec légende externe propre."""
    with plt.style.context(STYLE):
        counts = series.value_counts(dropna=True).sort_values(ascending=False)
        n_total = counts.sum()
        labels  = [str(l) for l in counts.index]
        values  = counts.values
        colors  = [PALETTE[i % len(PALETTE)] for i in range(len(counts))]

        fig, ax = plt.subplots(figsize=(6.5, 5))

        wedges, _, autotexts = ax.pie(
            values,
            labels=None,
            autopct="%1.1f%%",
            colors=colors,
            startangle=140,
            pctdistance=0.75,
            wedgeprops={"edgecolor": "white", "linewidth": 2},
        )
        for t in autotexts:
            t.set_fontsize(9)
            t.set_color("white")
            t.set_fontweight("bold")

        # Légende avec n et %
        legend_labels = [
            f"{lbl}  —  {val} ({val/n_total*100:.1f}%)"
            for lbl, val in zip(labels, values)
        ]
        ax.legend(
            wedges, legend_labels,
            loc="lower center",
            bbox_to_anchor=(0.5, -0.18),
            ncol=2 if len(labels) > 3 else 1,
            fontsize=8.5,
            framealpha=0.9,
            edgecolor="#CBD5E1",
        )

        # N total
        ax.annotate(f"N = {n_total}", xy=(0.98, 0.98),
                    xycoords="axes fraction", ha="right", va="top",
                    fontsize=8, color="#64748B",
                    bbox=dict(boxstyle="round,pad=0.3", fc="#F1F5F9", ec="#CBD5E1"))

        fig.tight_layout()
    return _fig_to_bytes(fig, dpi)


def make_boxplot(series: pd.Series, title: str, dpi: int = 150) -> bytes:
    """Boxplot avec statistiques annotées."""
    with plt.style.context(STYLE):
        data = pd.to_numeric(series, errors="coerce").dropna()
        if len(data) < 2:
            return b""

        fig, ax = plt.subplots(figsize=(5, 5))

        bp = ax.boxplot(
            data,
            patch_artist=True,
            notch=False,
            widths=0.45,
            medianprops={"color": "#DC2626", "linewidth": 2.5},
            whiskerprops={"color": "#475569", "linewidth": 1.4},
            capprops={"color": "#475569", "linewidth": 1.8},
            flierprops={"marker": "o", "markerfacecolor": "#DC2626",
                        "markersize": 4, "alpha": 0.55, "markeredgewidth": 0},
            boxprops={"linewidth": 1.4},
        )
        bp["boxes"][0].set_facecolor("#BFDBFE")   # bleu pâle
        bp["boxes"][0].set_alpha(0.85)

        # Annotations statistiques à droite
        q1   = float(np.percentile(data, 25))
        med  = float(np.median(data))
        q3   = float(np.percentile(data, 75))
        mean = float(data.mean())
        mn   = float(data.min())
        mx   = float(data.max())
        iqr  = q3 - q1

        stats_txt = (
            f"Moyenne : {mean:.2f}\n"
            f"Médiane : {med:.2f}\n"
            f"Q1 : {q1:.2f}\n"
            f"Q3 : {q3:.2f}\n"
            f"IQR : {iqr:.2f}\n"
            f"Min : {mn:.2f}\n"
            f"Max : {mx:.2f}\n"
            f"N : {len(data)}"
        )
        ax.text(1.35, med, stats_txt,
                transform=ax.get_yaxis_transform(),
                fontsize=8, va="center", color="#1E293B",
                bbox=dict(boxstyle="round,pad=0.5", fc="#F8FAFC",
                          ec="#CBD5E1", alpha=0.95))

        # Ligne de la moyenne
        ax.axhline(mean, color="#D97706", linewidth=1.4,
                   linestyle="--", alpha=0.8, label=f"Moyenne : {mean:.2f}")
        ax.legend(fontsize=8, loc="upper left")

        ax.set_xticks([1])
        ax.set_xticklabels([series.name or ""], fontsize=9)
        ax.set_ylabel("Valeur", fontsize=9)
        # pas de set_title — le titre est géré par la légende du rapport
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(axis="y", alpha=0.4, linestyle="--")

        fig.tight_layout()
    return _fig_to_bytes(fig, dpi)


def make_grouped_boxplot(df: pd.DataFrame, quant_col: str,
                          qual_col: str, title: str, dpi: int = 150) -> bytes:
    """Boxplot groupé par modalités d'une variable qualitative."""
    with plt.style.context(STYLE):
        cats = sorted(df[qual_col].dropna().unique().tolist(), key=str)
        groups = [
            pd.to_numeric(df[quant_col][df[qual_col] == c], errors="coerce").dropna()
            for c in cats
        ]
        groups = [(c, g) for c, g in zip(cats, groups) if len(g) >= 2]
        if not groups:
            return b""

        fig, ax = plt.subplots(figsize=(max(5, len(groups) * 1.4), 5))

        bp = ax.boxplot(
            [g for _, g in groups],
            patch_artist=True,
            notch=False,
            widths=0.55,
            medianprops={"color": "#DC2626", "linewidth": 2},
            whiskerprops={"color": "#475569", "linewidth": 1.2},
            capprops={"color": "#475569", "linewidth": 1.5},
            flierprops={"marker": "o", "markersize": 3,
                        "alpha": 0.5, "markeredgewidth": 0},
        )
        for patch, color in zip(bp["boxes"], PALETTE):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)

        ax.set_xticks(range(1, len(groups) + 1))
        ax.set_xticklabels([c for c, _ in groups],
                           rotation=20 if len(groups) > 3 else 0,
                           ha="right" if len(groups) > 3 else "center",
                           fontsize=9)
        ax.set_ylabel(quant_col, fontsize=9)
        ax.set_xlabel(qual_col, fontsize=9)
        # pas de set_title
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(axis="y", alpha=0.4, linestyle="--")

        fig.tight_layout()
    return _fig_to_bytes(fig, dpi)


# ─── Fonction principale ──────────────────────────────────────────────────────

def auto_chart(series: pd.Series, title: str,
               var_type: str, dpi: int = 150) -> tuple[bytes, str]:
    """
    Sélectionne et génère automatiquement le graphique adapté.

    Paramètres
    ----------
    series   : pandas Series de la variable
    title    : titre du graphique
    var_type : "qualitative" | "quantitative"
    dpi      : résolution PNG

    Retourne
    --------
    (bytes_png, chart_type_str)
    chart_type_str : "pie" | "bar" | "boxplot"
    """
    if var_type == "quantitative":
        img = make_boxplot(series, title, dpi)
        return img, "boxplot"
    else:
        # Application des 4 critères
        if _should_use_pie(series):
            img = make_pie_chart(series, title, dpi)
            return img, "pie"
        else:
            img = make_bar_chart(series, title, dpi)
            return img, "bar"
