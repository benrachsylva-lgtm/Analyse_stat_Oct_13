"""
Module de gestion des données
Importation, détection de types, analyse de complétude
"""

import pandas as pd
import numpy as np
from pathlib import Path


class DataManager:
    def __init__(self):
        self.df = None
        self.file_path = None
        self.sheet_name = None
        self.qualitative_vars = []
        self.quantitative_vars = []
        self.variable_groups = {}  # {nom_groupe: [liste_variables]}

    def get_excel_sheets(self, file_path: str) -> list:
        """Retourne la liste des feuilles d'un fichier Excel"""
        try:
            xl = pd.ExcelFile(file_path)
            return xl.sheet_names
        except Exception as e:
            raise ValueError(f"Impossible de lire le fichier Excel : {e}")

    def load_file(self, file_path: str, sheet_name=None) -> pd.DataFrame:
        """Charge un fichier Excel ou CSV"""
        self.file_path = file_path
        path = Path(file_path)
        ext = path.suffix.lower()

        try:
            if ext in ['.xlsx', '.xls']:
                if sheet_name:
                    self.df = pd.read_excel(file_path, sheet_name=sheet_name)
                    self.sheet_name = sheet_name
                else:
                    self.df = pd.read_excel(file_path)
                    self.sheet_name = 0
            elif ext == '.csv':
                # Essai avec différents séparateurs
                try:
                    self.df = pd.read_csv(file_path, sep=';', encoding='utf-8')
                    if len(self.df.columns) == 1:
                        self.df = pd.read_csv(file_path, sep=',', encoding='utf-8')
                except UnicodeDecodeError:
                    self.df = pd.read_csv(file_path, sep=';', encoding='latin-1')
            else:
                raise ValueError(f"Format non supporté : {ext}")

            self._detect_variable_types()
            return self.df

        except Exception as e:
            raise ValueError(f"Erreur lors du chargement : {e}")

    def _detect_variable_types(self):
        """Détecte automatiquement les types de variables"""
        self.qualitative_vars = []
        self.quantitative_vars = []

        for col in self.df.columns:
            series = self.df[col].dropna()
            if len(series) == 0:
                self.qualitative_vars.append(col)
                continue

            dtype = self.df[col].dtype
            if dtype in [np.int64, np.int32, np.float64, np.float32]:
                # Vérifier si c'est vraiment numérique ou un code
                n_unique = self.df[col].nunique()
                if n_unique <= 10 and dtype in [np.int64, np.int32]:
                    # Potentiellement qualitative (codes)
                    self.qualitative_vars.append(col)
                else:
                    self.quantitative_vars.append(col)
            elif dtype == object:
                # Tenter conversion numérique
                try:
                    pd.to_numeric(series, errors='raise')
                    self.quantitative_vars.append(col)
                except (ValueError, TypeError):
                    self.qualitative_vars.append(col)
            else:
                self.qualitative_vars.append(col)

    def get_completeness_table(self) -> pd.DataFrame:
        """Génère le tableau d'analyse de complétude"""
        if self.df is None:
            return pd.DataFrame()

        n_total = len(self.df)
        rows = []

        for col in self.df.columns:
            n_filled = self.df[col].notna().sum()
            n_missing = self.df[col].isna().sum()
            pct_complete = round(n_filled / n_total * 100, 2) if n_total > 0 else 0
            pct_missing = round(n_missing / n_total * 100, 2) if n_total > 0 else 0
            var_type = "Qualitative" if col in self.qualitative_vars else "Quantitative"

            rows.append({
                "Variable": col,
                "Type": var_type,
                "Valeurs renseignées": n_filled,
                "Valeurs manquantes": n_missing,
                "Complétude (%)": pct_complete,
                "Manquantes (%)": pct_missing,
            })

        return pd.DataFrame(rows)

    def get_qualitative_stats(self, col: str) -> pd.DataFrame:
        """Statistiques descriptives pour une variable qualitative"""
        if self.df is None or col not in self.df.columns:
            return pd.DataFrame()

        series = self.df[col].dropna()
        n_total = len(series)
        counts = series.value_counts()
        pcts = (counts / n_total * 100).round(2)

        result = pd.DataFrame({
            "Modalité": counts.index,
            "Effectif": counts.values,
            "Pourcentage (%)": pcts.values,
        })
        return result

    def get_quantitative_stats(self, col: str) -> dict:
        """Statistiques descriptives pour une variable quantitative"""
        if self.df is None or col not in self.df.columns:
            return {}

        series = pd.to_numeric(self.df[col], errors='coerce').dropna()
        if len(series) == 0:
            return {}

        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)

        # Mode
        mode_vals = series.mode()
        mode_str = ", ".join([str(round(m, 4)) for m in mode_vals.values[:3]])

        return {
            "N": len(series),
            "Moyenne": round(series.mean(), 4),
            "Médiane": round(series.median(), 4),
            "Mode": mode_str,
            "Minimum": round(series.min(), 4),
            "Maximum": round(series.max(), 4),
            "Écart-type": round(series.std(), 4),
            "Variance": round(series.var(), 4),
            "Q1 (25%)": round(q1, 4),
            "Q3 (75%)": round(q3, 4),
            "IQR": round(q3 - q1, 4),
        }

    # ─── Gestion des groupes ──────────────────────────────────────────────────

    def create_group(self, group_name: str, variables: list):
        self.variable_groups[group_name] = variables

    def update_group(self, group_name: str, variables: list):
        if group_name in self.variable_groups:
            self.variable_groups[group_name] = variables

    def delete_group(self, group_name: str):
        if group_name in self.variable_groups:
            del self.variable_groups[group_name]

    def get_group_descriptive_table(self, group_name: str) -> pd.DataFrame:
        """Tableau descriptif pour un groupe de variables.
        - Colonne Type supprimée
        - Nom de la variable affiché uniquement sur la première ligne de chaque variable
        """
        if group_name not in self.variable_groups:
            return pd.DataFrame()

        variables = self.variable_groups[group_name]
        rows = []

        for var in variables:
            if var not in self.df.columns:
                continue
            if var in self.qualitative_vars:
                stats = self.get_qualitative_stats(var)
                for i, (_, row) in enumerate(stats.iterrows()):
                    rows.append({
                        "Variable": var if i == 0 else "",
                        "Modalité / Statistique": str(row["Modalité"]),
                        "Effectif / Valeur": row["Effectif"],
                        "Pourcentage (%)": row["Pourcentage (%)"],
                    })
            else:
                stats = self.get_quantitative_stats(var)
                for i, (key, val) in enumerate(stats.items()):
                    rows.append({
                        "Variable": var if i == 0 else "",
                        "Modalité / Statistique": key,
                        "Effectif / Valeur": val,
                        "Pourcentage (%)": "",
                    })

        return pd.DataFrame(rows)

    # ─── Analyse bivariée ────────────────────────────────────────────────────

    @staticmethod
    def _fmt_p(p: float) -> str:
        """Formatte une p-value selon les conventions scientifiques."""
        if p < 0.0001:
            return "<0,0001"
        elif p < 0.001:
            return f"{p:.4f}".replace(".", ",")
        else:
            return f"{p:.3f}".replace(".", ",")

    @staticmethod
    def _fmt_n_pct(n: int, total: int) -> str:
        """Retourne 'n (x,x%)' formaté."""
        pct = n / total * 100 if total > 0 else 0
        return f"{n} ({pct:.1f}%)".replace(".", ",")

    def bivariate_analysis(self, dep_var: str, group_name: str) -> list:
        """
        Analyse bivariée structurée au format publication :
        Variable | Modalité | Cat1 n(%) | Cat2 n(%) | Total n(%) | p | Test/OR [IC 95%]

        Retourne une liste de dicts (une ligne par modalité de la variable indépendante).
        """
        from scipy import stats
        import statsmodels.api as sm

        results = []
        if group_name not in self.variable_groups:
            return results

        group_vars = self.variable_groups[group_name]
        is_dep_qualitative = dep_var in self.qualitative_vars

        # ── Cas : variable dépendante qualitative (binaire ou non) ──────────
        if is_dep_qualitative:
            dep_cats = sorted(self.df[dep_var].dropna().unique().tolist(), key=str)
            n_dep_cats = len(dep_cats)

            # En-tête décrivant les colonnes dépendantes (1 ligne de métadonnées)
            col_labels = {f"__col_{i}__": str(c) for i, c in enumerate(dep_cats)}

            for var in group_vars:
                if var == dep_var or var not in self.df.columns:
                    continue

                df_clean = self.df[[dep_var, var]].dropna()
                if len(df_clean) < 5:
                    results.append({
                        "Variable": var,
                        "Modalité": "—",
                        **{str(c): "—" for c in dep_cats},
                        "Total n(%)": "—",
                        "p": "—",
                        "Test / OR [IC 95%]": "Données insuffisantes",
                        "__is_ref__": False,
                        "__var_first_row__": True,
                        "__dep_cats__": dep_cats,
                    })
                    continue

                dep = df_clean[dep_var]
                ind = df_clean[var]
                n_total_clean = len(df_clean)

                if var in self.qualitative_vars:
                    # ─ Variable indépendante qualitative ─────────────────────
                    ind_cats = sorted(ind.unique().tolist(), key=str)
                    contingency = pd.crosstab(dep, ind)

                    # Test statistique global
                    chi2, p_chi2, dof, expected = stats.chi2_contingency(contingency)
                    use_fisher = (expected < 5).any()
                    if use_fisher and contingency.shape == (2, 2):
                        _, p_val = stats.fisher_exact(contingency)
                        test_name = "Fisher"
                    else:
                        p_val = p_chi2
                        test_name = "Khi²"

                    p_str = self._fmt_p(p_val)

                    # Odds Ratio (2x2 uniquement)
                    is_binary_dep = (n_dep_cats == 2)
                    or_map = {}   # {modalité: "OR [IC]"}
                    if is_binary_dep and contingency.shape == (2, 2) and len(ind_cats) == 2:
                        try:
                            # Référence = première modalité ind_cats[0]
                            tbl = sm.stats.Table2x2(contingency.values)
                            or_val = tbl.oddsratio
                            lo, hi = tbl.oddsratio_confint()
                            or_map[ind_cats[1]] = (
                                f"{or_val:.2f} [{lo:.2f} – {hi:.2f}]"
                                .replace(".", ",")
                            )
                        except Exception:
                            pass

                    # Ligne pour chaque modalité de la variable indépendante
                    for i_cat, cat in enumerate(ind_cats):
                        is_ref = (i_cat == 0)
                        row_vals = {}
                        n_cat_total = int((ind == cat).sum())

                        for dep_cat in dep_cats:
                            n_cell = int(contingency.loc[dep_cat, cat]) if (dep_cat in contingency.index and cat in contingency.columns) else 0
                            n_dep = int((dep == dep_cat).sum())
                            row_vals[str(dep_cat)] = self._fmt_n_pct(n_cell, n_dep)

                        total_str = self._fmt_n_pct(n_cat_total, n_total_clean)
                        or_str = "Réf." if is_ref else or_map.get(cat, "—")
                        p_display = p_str if i_cat == 0 else ""

                        results.append({
                            "Variable": var if i_cat == 0 else "",
                            "Modalité": str(cat),
                            **row_vals,
                            "Total n(%)": total_str,
                            "p": p_display,
                            "Test / OR [IC 95%]": or_str,
                            "__is_ref__": is_ref,
                            "__var_first_row__": (i_cat == 0),
                            "__dep_cats__": dep_cats,
                            "__test__": test_name,
                        })

                else:
                    # ─ Variable indépendante quantitative ────────────────────
                    ind_num = pd.to_numeric(ind, errors='coerce')
                    groups_data = [
                        ind_num[dep == cat].dropna() for cat in dep_cats
                    ]
                    groups_data = [g for g in groups_data if len(g) >= 2]

                    moy_std_per_cat = {}
                    for dep_cat in dep_cats:
                        g = ind_num[dep == dep_cat].dropna()
                        if len(g):
                            moy_std_per_cat[str(dep_cat)] = (
                                f"{g.mean():.2f} ± {g.std():.2f}".replace(".", ",")
                            )
                        else:
                            moy_std_per_cat[str(dep_cat)] = "—"

                    total_g = ind_num.dropna()
                    total_str = f"{total_g.mean():.2f} ± {total_g.std():.2f}".replace(".", ",")

                    test_str = "—"
                    p_str = "—"
                    if len(groups_data) == 2:
                        t_stat, p_t = stats.ttest_ind(*groups_data)
                        u_stat, p_mw = stats.mannwhitneyu(*groups_data, alternative='two-sided')
                        p_str = self._fmt_p(min(p_t, p_mw))
                        test_str = f"t={t_stat:.2f} / U={u_stat:.0f}"
                    elif len(groups_data) > 2:
                        f_stat, p_anova = stats.f_oneway(*groups_data)
                        p_str = self._fmt_p(p_anova)
                        test_str = f"F={f_stat:.2f} (ANOVA)"

                    results.append({
                        "Variable": var,
                        "Modalité": "Moy ± ET",
                        **moy_std_per_cat,
                        "Total n(%)": total_str,
                        "p": p_str,
                        "Test / OR [IC 95%]": test_str,
                        "__is_ref__": False,
                        "__var_first_row__": True,
                        "__dep_cats__": dep_cats,
                        "__test__": "Student/Mann-Whitney",
                    })

        # ── Cas : variable dépendante quantitative ───────────────────────────
        else:
            dep_num = pd.to_numeric(self.df[dep_var], errors='coerce')

            for var in group_vars:
                if var == dep_var or var not in self.df.columns:
                    continue

                df_clean = self.df[[dep_var, var]].dropna()
                if len(df_clean) < 5:
                    results.append({
                        "Variable": var,
                        "Modalité": "—",
                        "Moy ± ET": "—",
                        "Total n(%)": "—",
                        "p": "—",
                        "Test / OR [IC 95%]": "Données insuffisantes",
                        "__is_ref__": False,
                        "__var_first_row__": True,
                        "__dep_cats__": [],
                    })
                    continue

                dep_clean = pd.to_numeric(df_clean[dep_var], errors='coerce')
                ind_clean = df_clean[var]

                if var in self.qualitative_vars:
                    ind_cats = sorted(ind_clean.unique().tolist(), key=str)
                    groups_data = [
                        dep_clean[ind_clean == cat].dropna() for cat in ind_cats
                    ]

                    if len(groups_data) == 2 and all(len(g) >= 2 for g in groups_data):
                        t_stat, p_t = stats.ttest_ind(*groups_data)
                        u_stat, p_mw = stats.mannwhitneyu(*groups_data, alternative='two-sided')
                        p_str = self._fmt_p(min(p_t, p_mw))
                        test_str = f"t={t_stat:.2f} / U={u_stat:.0f}"
                    elif len(groups_data) > 2:
                        valid = [g for g in groups_data if len(g) >= 2]
                        f_stat, p_anova = stats.f_oneway(*valid)
                        p_str = self._fmt_p(p_anova)
                        test_str = f"F={f_stat:.2f} (ANOVA)"
                    else:
                        p_str = "—"
                        test_str = "—"

                    for i_cat, (cat, grp) in enumerate(zip(ind_cats, groups_data)):
                        n_cat = len(grp)
                        n_total_clean = len(dep_clean.dropna())
                        moy_str = f"{grp.mean():.2f} ± {grp.std():.2f}".replace(".", ",") if len(grp) else "—"
                        total_str = self._fmt_n_pct(n_cat, n_total_clean)

                        results.append({
                            "Variable": var if i_cat == 0 else "",
                            "Modalité": str(cat),
                            "Moy ± ET": moy_str,
                            "Total n(%)": total_str,
                            "p": p_str if i_cat == 0 else "",
                            "Test / OR [IC 95%]": test_str if i_cat == 0 else "",
                            "__is_ref__": False,
                            "__var_first_row__": (i_cat == 0),
                            "__dep_cats__": [],
                        })
                else:
                    # quantitative vs quantitative → corrélation
                    ind_num_clean = pd.to_numeric(ind_clean, errors='coerce')
                    r, p_r = stats.pearsonr(dep_clean, ind_num_clean)
                    rho, p_rho = stats.spearmanr(dep_clean, ind_num_clean)
                    results.append({
                        "Variable": var,
                        "Modalité": "Corrélation",
                        "Moy ± ET": f"r={r:.3f} / ρ={rho:.3f}".replace(".", ","),
                        "Total n(%)": f"n={len(dep_clean)}",
                        "p": self._fmt_p(min(p_r, p_rho)),
                        "Test / OR [IC 95%]": "Pearson / Spearman",
                        "__is_ref__": False,
                        "__var_first_row__": True,
                        "__dep_cats__": [],
                    })

        return results

    def bivariate_analysis_all_groups(self, dep_var: str) -> list:
        """
        Lance l'analyse bivariée pour TOUS les groupes définis.
        Insère automatiquement une ligne de section pour chaque groupe.
        Retourne la liste complète de toutes les lignes résultat.
        """
        all_results = []
        for grp_name in self.variable_groups:
            grp_results = self.bivariate_analysis(dep_var, grp_name)
            if not grp_results:
                continue
            dep_cats = grp_results[0].get("__dep_cats__", [])
            section_row = {
                "Variable": grp_name,
                "__is_section__": True,
                "__is_ref__": False,
                "__var_first_row__": False,
                "__dep_cats__": dep_cats,
            }
            all_results.append(section_row)
            all_results.extend(grp_results)
        return all_results
