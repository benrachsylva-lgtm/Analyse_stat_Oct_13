"""
StatAnalyzer - Logiciel d'analyse statistique pour la recherche médicale
Point d'entrée principal
"""

import sys
import os

# Ajouter le répertoire parent au chemin
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import customtkinter as ctk
from ui.main_window import MainWindow

def main():
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")
    
    app = MainWindow()
    app.mainloop()

if __name__ == "__main__":
    main()
