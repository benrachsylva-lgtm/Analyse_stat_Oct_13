# StatAnalyzer — Logiciel d'Analyse Statistique Médicale

## Présentation

**StatAnalyzer** est un logiciel d'analyse statistique développé en Python, conçu pour la recherche scientifique et médicale. Il offre une interface graphique moderne et intuitive permettant d'analyser des données issues de fichiers Excel ou CSV sans écrire une seule ligne de code.

---

## Prérequis

- **Python 3.10 ou supérieur** — [Télécharger Python](https://www.python.org/downloads/)
- **Windows 10/11** (ou Linux/macOS avec Python)

---

## Installation et lancement

### Méthode rapide (Windows)

Double-cliquez sur `lancer_StatAnalyzer.bat`

Le script installera automatiquement les dépendances au premier lancement.

### Méthode manuelle

```bash
# Installer les dépendances
pip install -r requirements.txt

# Lancer l'application
python main.py
```

---

## Fonctionnalités

### 1. Importation des données
- Fichiers Excel (.xlsx, .xls) et CSV (.csv)
- Sélection de la feuille Excel
- Détection automatique des types de variables
- Tableau interactif avec tri et recherche

### 2. Analyse de complétude
- Nombre de valeurs renseignées / manquantes
- Pourcentages de complétude par variable
- Export Excel et Word

### 3. Analyse descriptive
**Variables qualitatives :**
- Modalités, effectifs, pourcentages
- Diagrammes en barres et camemberts

**Variables quantitatives :**
- Moyenne, médiane, mode, min, max
- Écart-type, variance, quartiles, IQR
- Histogrammes avec densité, boxplots

### 4. Groupes de variables
- Créer des groupes thématiques (ex: Variables socio-démographiques)
- Modifier et supprimer des groupes
- Tableaux descriptifs par groupe

### 5. Analyse bivariée
**Variable dépendante qualitative :**
- Test du Khi², Test exact de Fisher
- Odds Ratio avec intervalle de confiance à 95%
- p-value

**Variable dépendante quantitative :**
- Test t de Student, Mann-Whitney
- ANOVA, Kruskal-Wallis

### 6. Exportation
- **Excel** : Rapport multi-feuilles formaté
- **Word** : Document prêt pour publication/mémoire

---

## Structure du projet

```
StatAnalyzer/
├── main.py                    # Point d'entrée
├── requirements.txt           # Dépendances Python
├── lancer_StatAnalyzer.bat    # Lanceur Windows
├── core/
│   ├── data_manager.py        # Gestion des données et statistiques
│   └── charts.py              # Génération des graphiques
├── ui/
│   └── main_window.py         # Interface graphique principale
└── export/
    └── exporter.py            # Export Excel et Word
```

---

## Technologies utilisées

| Composant | Bibliothèque |
|-----------|-------------|
| Interface graphique | CustomTkinter |
| Manipulation données | pandas, numpy |
| Statistiques | scipy, statsmodels |
| Graphiques | matplotlib |
| Export Excel | openpyxl |
| Export Word | python-docx |

---

## Auteur

Développé pour la recherche médicale et scientifique.  
Interface : Python + CustomTkinter  
Statistiques : scipy + statsmodels
