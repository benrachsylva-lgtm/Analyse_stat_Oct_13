"""
DataAnalyser v4 — Application desktop complète
Nouveautés : Outliers, Imputation, VIF, Stepwise, ROC, Confusion, Heatmap,
             Violin, Tests numériques, Journal des actions, Sauvegarde session
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
import numpy as np
import threading, os, sys, json, datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.engine import (
    get_log, clear_log, log_action,
    analyze_missing, apply_missing_threshold, detect_variable_type,
    add_computed_variable, create_classes, descriptive_numeric, frequency_table,
    crosstab_analysis, numeric_vs_qualitative, logistic_regression,
    compute_vif, stepwise_logistic,
    outlier_summary, treat_outliers, detect_outliers,
    impute_missing, test_normalite,
    save_session, load_session,
)
from core.charts import (
    bar_chart, pie_chart, histogram, boxplot, grouped_bar_chart,
    forest_plot, roc_curve_plot, confusion_matrix_plot,
    correlation_heatmap, violin_plot, scatter_plot,
)

# ── Thème ─────────────────────────────────────────────────────────
C = {
    'bg':      '#F0F4FA', 'sidebar': '#1E4D2B',
    'accent':  '#2980B9', 'accent2': '#3498DB',
    'success': '#27AE60', 'warning': '#E67E22',
    'error':   '#C0392B', 'text':    '#1A1A2E',
    'textlt':  '#6B7A99', 'border':  '#D0D9EC',
    'alt':     '#EBF3FB', 'panel':   '#FFFFFF',
    'step_ok': '#EAFAF1',
}
FT  = ('Segoe UI', 10)
FTB = ('Segoe UI', 10, 'bold')
FTH = ('Segoe UI', 13, 'bold')
FTS = ('Segoe UI', 9)
FTM = ('Consolas', 9)


# ── Widgets utilitaires ───────────────────────────────────────────

class ScrollFrame(tk.Frame):
    def __init__(self, parent, bg=None, **kw):
        bg = bg or C['bg']
        super().__init__(parent, bg=bg, **kw)
        self._canvas = tk.Canvas(self, bg=bg, highlightthickness=0)
        sb = ttk.Scrollbar(self, orient='vertical', command=self._canvas.yview)
        self.inner = tk.Frame(self._canvas, bg=bg)
        self.inner.bind('<Configure>',
            lambda e: self._canvas.configure(scrollregion=self._canvas.bbox('all')))
        self._canvas.create_window((0,0), window=self.inner, anchor='nw')
        self._canvas.configure(yscrollcommand=sb.set)
        self._canvas.pack(side='left', fill='both', expand=True)
        sb.pack(side='right', fill='y')
        self._canvas.bind('<MouseWheel>',
            lambda e: self._canvas.yview_scroll(int(-1*(e.delta/120)),'units'))


def btn(parent, text, cmd, bg=None, fg='white', px=14, py=8):
    bg = bg or C['accent']
    b = tk.Button(parent, text=text, command=cmd, font=FTB, bg=bg, fg=fg,
                  activebackground=C['accent2'], activeforeground='white',
                  relief='flat', padx=px, pady=py, cursor='hand2', bd=0)
    b.bind('<Enter>', lambda e: b.config(bg=C['accent2']))
    b.bind('<Leave>', lambda e: b.config(bg=bg))
    return b


def sec_title(parent, text, bg=None):
    bg = bg or C['bg']
    frm = tk.Frame(parent, bg=bg)
    tk.Label(frm, text=text, font=FTH, bg=bg, fg=C['text']).pack(side='left')
    tk.Frame(frm, height=2, bg=C['accent']).pack(
        side='left', fill='x', expand=True, padx=10, pady=8)
    return frm


def labeled_entry(parent, label, default='', width=26):
    frm = tk.Frame(parent, bg=C['bg'])
    tk.Label(frm, text=label, font=FTS, bg=C['bg'], fg=C['textlt']).pack(anchor='w')
    var = tk.StringVar(value=default)
    e = tk.Entry(frm, textvariable=var, font=FT, width=width,
                 relief='flat', bg=C['panel'],
                 highlightbackground=C['border'], highlightthickness=1)
    e.pack(fill='x')
    frm.var = var
    return frm


def show_img(parent, img_bytes, max_w=500, max_h=340):
    if not img_bytes:
        return
    try:
        from PIL import Image, ImageTk
        import io
        img = Image.open(io.BytesIO(img_bytes))
        img.thumbnail((max_w, max_h))
        photo = ImageTk.PhotoImage(img)
        lbl = tk.Label(parent, image=photo, bg=C['panel'])
        lbl.image = photo
        lbl.pack(side='left', padx=6, pady=4)
    except Exception as e:
        tk.Label(parent, text=f"[Graphique : {e}]",
                 font=FTS, bg=C['panel'], fg=C['textlt']).pack(side='left', padx=6)


# ══════════════════════════════════════════════════════════════════
#  APPLICATION
# ══════════════════════════════════════════════════════════════════

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("DataAnalyser v4 — Analyse Statistique Complète")
        self.geometry("1300x840")
        self.minsize(1100, 700)
        self.configure(bg=C['bg'])

        # ── État ──────────────────────────────────────────────────
        self.df_raw        = None
        self.df_clean      = None
        self.file_path     = None
        self.missing_df    = None
        self.dropped_cols  = []
        self.var_types     = {}
        self.threshold     = tk.DoubleVar(value=30.0)
        self.outlier_results   = {}
        self.outlier_actions   = {}
        self.imputation_log    = []
        self.computed_vars = []
        self.class_vars    = []
        self.dep_var       = tk.StringVar()
        self.desc_checks   = {}
        self.indep_checks  = {}
        self.bivar_results  = {}
        self.num_results     = {}
        self.stepwise_result = None
        self.reg_result    = None
        self.regr_checks   = {}
        self.charts        = {}

        self._build()

    # ──────────────────────────────────────────────────────────────
    #  BUILD
    # ──────────────────────────────────────────────────────────────

    def _build(self):
        # Sidebar
        self.sb = tk.Frame(self, bg=C['sidebar'], width=230)
        self.sb.pack(side='left', fill='y')
        self.sb.pack_propagate(False)
        self._build_sb()

        # Notebook
        self.main = tk.Frame(self, bg=C['bg'])
        self.main.pack(side='left', fill='both', expand=True)
        self.nb = ttk.Notebook(self.main)
        self.nb.pack(fill='both', expand=True)
        style = ttk.Style()
        style.configure('TNotebook', background=C['bg'])
        style.configure('TNotebook.Tab', font=FTB, padding=[12,7])
        style.map('TNotebook.Tab',
                  background=[('selected',C['accent']),('!selected',C['bg'])],
                  foreground=[('selected','white'),('!selected',C['textlt'])])

        tabs = [
            ('tab_home',  "  🏠  Accueil  "),
            ('tab_clean', "  🧹  1. Nettoyage  "),
            ('tab_out',   "  🔍  Outliers  "),
            ('tab_prep',  "  ⚙️  2. Préparation  "),
            ('tab_desc',  "  📊  3a. Descriptif  "),
            ('tab_bivar', "  🔗  3b. Bivarié  "),
            ('tab_regr',  "  📈  3c. Régression  "),
            ('tab_log',   "  📋  Journal  "),
        ]
        for attr, label in tabs:
            frm = tk.Frame(self.nb, bg=C['bg'])
            setattr(self, attr, frm)
            self.nb.add(frm, text=label)

        self._build_home()
        self._build_clean()
        self._build_outliers()
        self._build_prep()
        self._build_desc()
        self._build_bivar()
        self._build_regr()
        self._build_log()

    def _build_sb(self):
        tk.Label(self.sb, text="Data", font=('Segoe UI',24,'bold'),
                 bg=C['sidebar'], fg='#2ECC71').pack(pady=(22,0))
        tk.Label(self.sb, text="Analyser  v4", font=('Segoe UI',11),
                 bg=C['sidebar'], fg='#AADDBB').pack()
        tk.Frame(self.sb, height=1, bg='#3A6A3A').pack(fill='x',padx=18,pady=14)

        for text, cmd in [
            ("📂  Charger Excel",       self._load),
            ("🧹  1. Nettoyage",         lambda: self.nb.select(1)),
            ("🔍  Outliers",             lambda: self.nb.select(2)),
            ("⚙️  2. Préparation",        lambda: self.nb.select(3)),
            ("📊  3a. Descriptif",        lambda: self.nb.select(4)),
            ("🔗  3b. Bivarié",           lambda: self.nb.select(5)),
            ("📈  3c. Régression",        lambda: self.nb.select(6)),
            ("📋  Journal",              lambda: self.nb.select(7)),
        ]:
            b = tk.Button(self.sb, text=text, command=cmd, font=FTB,
                          bg=C['sidebar'], fg='#C8E6C8',
                          activebackground='#2980B9', activeforeground='white',
                          relief='flat', bd=0, padx=14, pady=8,
                          anchor='w', cursor='hand2')
            b.pack(fill='x', padx=6, pady=2)
            b.bind('<Enter>', lambda e,b=b: b.config(bg='#2A5A2A', fg='white'))
            b.bind('<Leave>', lambda e,b=b: b.config(bg=C['sidebar'], fg='#C8E6C8'))

        tk.Frame(self.sb, height=1, bg='#3A6A3A').pack(fill='x',padx=18,pady=10)
        btn(self.sb, "💾  Exporter Word", self._export,
            bg='#16A085', px=14, py=8).pack(fill='x', padx=6, pady=2)
        btn(self.sb, "💿  Sauvegarder session", self._save_session,
            bg='#8E44AD', px=14, py=6).pack(fill='x', padx=6, pady=2)
        btn(self.sb, "📂  Charger session", self._load_session,
            bg='#8E44AD', px=14, py=6).pack(fill='x', padx=6, pady=2)

        tk.Frame(self.sb, height=1, bg='#3A6A3A').pack(fill='x',padx=18,pady=8)
        self.stat_lbl = tk.Label(self.sb, text="Aucun fichier",
                                  font=FTS, bg=C['sidebar'], fg='#88AA88',
                                  wraplength=200, justify='left')
        self.stat_lbl.pack(padx=12, pady=4, anchor='w')

    def _set_status(self, msg, col='#88AA88'):
        self.stat_lbl.config(text=msg, fg=col)

    # ──────────────────────────────────────────────────────────────
    #  ACCUEIL
    # ──────────────────────────────────────────────────────────────

    def _build_home(self):
        frm = tk.Frame(self.tab_home, bg=C['bg'])
        frm.place(relx=0.5, rely=0.45, anchor='center')
        tk.Label(frm, text="📊", font=('Segoe UI',56), bg=C['bg'], fg=C['accent']).pack()
        tk.Label(frm, text="DataAnalyser v4", font=('Segoe UI',26,'bold'),
                 bg=C['bg'], fg=C['text']).pack(pady=4)
        steps = [
            ("🧹","1. Nettoyage","Types · Manquants · Seuil d'exclusion"),
            ("🔍","Outliers","Détection IQR/Z-score · Winsorisation · Imputation"),
            ("⚙️","2. Préparation","Nouvelles variables · Discrétisation en classes"),
            ("📊","3a. Descriptif","Fréquences · Stats · Shapiro-Wilk · Graphiques"),
            ("🔗","3b. Bivarié","Chi²/Fisher · t/Mann-Whitney/ANOVA · Heatmap"),
            ("📈","3c. Régression","Stepwise · OR · VIF · ROC/AUC · Matrice confusion"),
        ]
        for icon, title, desc in steps:
            row = tk.Frame(frm, bg=C['alt'], padx=12, pady=7,
                           highlightbackground=C['border'], highlightthickness=1)
            row.pack(fill='x', pady=2)
            tk.Label(row, text=icon, font=('Segoe UI',16), bg=C['alt']).pack(side='left', padx=6)
            col_f = tk.Frame(row, bg=C['alt'])
            col_f.pack(side='left')
            tk.Label(col_f, text=title, font=FTB, bg=C['alt'], fg=C['text']).pack(anchor='w')
            tk.Label(col_f, text=desc, font=FTS, bg=C['alt'], fg=C['textlt']).pack(anchor='w')
        btn(frm, "  📂  Charger un fichier Excel  ",
            self._load, px=24, py=12).pack(pady=18)

    # ──────────────────────────────────────────────────────────────
    #  NETTOYAGE
    # ──────────────────────────────────────────────────────────────

    def _build_clean(self):
        top = tk.Frame(self.tab_clean, bg=C['bg'])
        top.pack(fill='x', padx=20, pady=10)
        sec_title(top, "🧹  Étape 1 — Nettoyage").pack(fill='x')
        ctrl = tk.Frame(self.tab_clean, bg=C['bg'])
        ctrl.pack(fill='x', padx=20, pady=4)
        tk.Label(ctrl, text="Seuil manquants (%) :", font=FTB, bg=C['bg']).pack(side='left')
        tk.Spinbox(ctrl, from_=0, to=100, increment=5, textvariable=self.threshold,
                   width=6, font=FT, relief='flat', bg=C['panel']).pack(side='left', padx=8)
        btn(ctrl, "  ▶  Appliquer  ", self._run_clean).pack(side='right')
        self.clean_sf = ScrollFrame(self.tab_clean)
        self.clean_sf.pack(fill='both', expand=True, padx=20, pady=8)
        tk.Label(self.clean_sf.inner, text="Chargez un fichier Excel.",
                 font=FTS, bg=C['bg'], fg=C['textlt']).pack(pady=20)

    def _run_clean(self):
        if self.df_raw is None:
            messagebox.showwarning("","Chargez d'abord un fichier."); return
        thr = self.threshold.get()
        self.missing_df = analyze_missing(self.df_raw)
        self.df_clean, self.dropped_cols = apply_missing_threshold(
            self.df_raw, self.missing_df, thr)
        for col in self.df_clean.columns:
            self.var_types[col] = detect_variable_type(self.df_clean[col])
        self.outlier_results = outlier_summary(self.df_clean)
        self._display_clean()
        self._refresh_all()
        self._set_status(f"✔ Nettoyage — {len(self.dropped_cols)} retiré(s)", C['success'])

    def _display_clean(self):
        for w in self.clean_sf.inner.winfo_children(): w.destroy()
        inner = self.clean_sf.inner
        n_drop = len(self.dropped_cols)
        n_mix  = len(self.missing_df[~self.missing_df['coherent']])
        sum_frm = tk.Frame(inner, bg=C['alt'], padx=12, pady=8,
                           highlightbackground=C['border'], highlightthickness=1)
        sum_frm.pack(fill='x', pady=(0,8))
        for label, val, col in [
            ("Conservées",  len(self.missing_df)-n_drop, C['success']),
            ("Retirées",    n_drop, C['error'] if n_drop else C['textlt']),
            ("Types mixtes",n_mix,  C['warning'] if n_mix else C['textlt']),
            ("Seuil",       f"{self.threshold.get()}%", C['accent']),
        ]:
            f = tk.Frame(sum_frm, bg=C['alt']); f.pack(side='left', padx=18)
            tk.Label(f, text=str(val), font=('Segoe UI',18,'bold'),
                     bg=C['alt'], fg=col).pack()
            tk.Label(f, text=label, font=FTS, bg=C['alt'], fg=C['textlt']).pack()

        cols = ('Variable','Type','Cohérent','N total','N valides','N manquants','% manquants','Statut')
        tree = ttk.Treeview(inner, columns=cols, show='headings', height=16)
        vsb  = ttk.Scrollbar(inner, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        for c, w in zip(cols,[200,90,80,70,70,90,100,100]):
            tree.heading(c, text=c); tree.column(c, width=w, anchor='center')
        tree.tag_configure('drop', background='#FDEDEC')
        tree.tag_configure('mix',  background='#FEF9E7')
        tree.tag_configure('ok',   background=C['panel'])
        tree.tag_configure('alt',  background=C['alt'])
        for i, row in self.missing_df.iterrows():
            dropped = row['variable'] in self.dropped_cols
            mixed   = not row['coherent']
            tag = 'drop' if dropped else ('mix' if mixed else ('alt' if i%2 else 'ok'))
            tree.insert('','end', values=(
                row['variable'],row['type'],
                '✔' if row['coherent'] else '✘ Mixte',
                row['n_total'],row['n_valide'],
                row['n_manquant'],f"{row['pct_manquant']}%",
                '❌ Retirée' if dropped else ('⚠ Mixte' if mixed else '✔ OK')
            ), tags=(tag,))
        tree.pack(side='left', fill='both', expand=True)
        vsb.pack(side='right', fill='y')

    # ──────────────────────────────────────────────────────────────
    #  OUTLIERS
    # ──────────────────────────────────────────────────────────────

    def _build_outliers(self):
        sec_title(self.tab_out, "🔍  Outliers & Imputation").pack(
            fill='x', padx=20, pady=10)
        self.out_sf = ScrollFrame(self.tab_out)
        self.out_sf.pack(fill='both', expand=True, padx=20, pady=4)
        tk.Label(self.out_sf.inner,
                 text="Effectuez d'abord le nettoyage.",
                 font=FTS, bg=C['bg'], fg=C['textlt']).pack(pady=20)

    def _display_outliers(self):
        for w in self.out_sf.inner.winfo_children(): w.destroy()
        inner = self.out_sf.inner
        if self.outlier_results is None or (hasattr(self.outlier_results,'__len__') and len(self.outlier_results)==0):
            tk.Label(inner, text="Aucune variable numérique détectée.",
                     font=FTS, bg=C['bg'], fg=C['textlt']).pack(pady=20); return

        import pandas as pd
        df_out = self.outlier_results if isinstance(self.outlier_results, pd.DataFrame) else pd.DataFrame()

        tk.Label(inner,
                 text="Pour chaque variable numérique, choisissez le traitement des outliers et/ou l'imputation des manquants.",
                 font=FTS, bg=C['bg'], fg=C['textlt'], wraplength=880).pack(anchor='w', pady=(0,8))

        self._out_action_vars = {}
        self._imp_action_vars = {}

        rows_iter = df_out.iterrows() if len(df_out)>0 else []
        for _, r in rows_iter:
            col = r['variable']
            frm = tk.Frame(inner, bg=C['panel'],
                           highlightbackground=C['border'], highlightthickness=1)
            frm.pack(fill='x', pady=3, padx=2)
            top = tk.Frame(frm, bg=C['panel'], padx=10, pady=6)
            top.pack(fill='x')

            n_out = r.get('n_outliers_iqr', 0)
            pct   = r.get('pct_iqr', 0)
            lo    = r.get('borne_inf_iqr', '—')
            hi    = r.get('borne_sup_iqr', '—')
            col_f = C['warning'] if n_out > 0 else C['success']
            tk.Label(top, text=f"🔢  {col}", font=FTB,
                     bg=C['panel'], fg=C['text']).pack(side='left')
            tk.Label(top, text=f"  {n_out} outlier(s)  ({pct}%)",
                     font=FTS, bg=C['panel'], fg=col_f).pack(side='left', padx=8)
            tk.Label(top, text=f"Bornes IQR : [{lo} ; {hi}]",
                     font=FTS, bg=C['panel'], fg=C['textlt']).pack(side='left')

            # Actions outliers
            ctrl = tk.Frame(frm, bg=C['panel'], padx=10, pady=4)
            ctrl.pack(fill='x')
            tk.Label(ctrl, text="Outliers :", font=FTS, bg=C['panel']).pack(side='left')
            ov = tk.StringVar(value='none')
            self._out_action_vars[col] = ov
            for lbl, val in [("Aucune action","none"),
                              ("Retirer (→ NA)","remove"),
                              ("Winsoriser","cap"),
                              ("Remplacer par médiane","median")]:
                tk.Radiobutton(ctrl, text=lbl, variable=ov, value=val,
                               font=FTS, bg=C['panel'],
                               activebackground=C['panel'],
                               cursor='hand2').pack(side='left', padx=6)

            # Imputation
            ctrl2 = tk.Frame(frm, bg=C['panel'], padx=10, pady=4)
            ctrl2.pack(fill='x')
            n_miss = int(self.df_clean[col].isna().sum()) if col in self.df_clean.columns else 0
            tk.Label(ctrl2, text=f"Manquants ({n_miss}) :", font=FTS,
                     bg=C['panel']).pack(side='left')
            iv = tk.StringVar(value='none')
            self._imp_action_vars[col] = iv
            for lbl, val in [("Aucune","none"),
                              ("Médiane","median"),
                              ("Moyenne","mean"),
                              ("Mode","mode"),
                              ("Supprimer lignes","drop")]:
                tk.Radiobutton(ctrl2, text=lbl, variable=iv, value=val,
                               font=FTS, bg=C['panel'],
                               activebackground=C['panel'],
                               cursor='hand2').pack(side='left', padx=6)

        btn(inner, "  ▶  Appliquer les traitements sélectionnés  ",
            self._apply_outlier_impute, bg=C['success'], px=18, py=10).pack(pady=12)

    def _apply_outlier_impute(self):
        if self.df_clean is None: return
        df = self.df_clean.copy()
        self.outlier_actions = {}
        self.imputation_log  = []

        for col, ov in self._out_action_vars.items():
            action = ov.get()
            if action != 'none':
                df = treat_outliers(df, col, action)[0]
                self.outlier_actions[col] = action

        for col, iv in self._imp_action_vars.items():
            method = iv.get()
            if method != 'none' and col in df.columns:
                n_before = int(df[col].isna().sum())
                df, val = impute_missing(df, col, method)
                self.imputation_log.append({
                    'variable': col, 'method': method,
                    'value': round(float(val),3) if isinstance(val,(int,float)) else str(val),
                    'n': n_before})

        self.df_clean = df
        self._refresh_all()
        self._set_status("✔ Outliers/Imputation appliqués", C['success'])
        messagebox.showinfo("Traitement appliqué",
                            f"Outliers traités : {len(self.outlier_actions)} variable(s)\n"
                            f"Imputations : {len(self.imputation_log)} variable(s)")

    # ──────────────────────────────────────────────────────────────
    #  PRÉPARATION
    # ──────────────────────────────────────────────────────────────

    def _build_prep(self):
        sec_title(self.tab_prep, "⚙️  Étape 2 — Préparation").pack(
            fill='x', padx=20, pady=10)
        pane = tk.PanedWindow(self.tab_prep, orient='horizontal',
                              bg=C['bg'], sashwidth=5)
        pane.pack(fill='both', expand=True, padx=20, pady=4)

        left = tk.LabelFrame(pane, text=" 2.1  Nouvelle variable calculée ",
                             font=FTB, bg=C['bg'], fg=C['accent'], padx=10, pady=8)
        pane.add(left, minsize=300)
        self._pnv_name = labeled_entry(left, "Nom", width=26)
        self._pnv_name.pack(fill='x', pady=3)
        self._pnv_formula = labeled_entry(left, "Formule Python  (ex: Poids / Taille**2)", width=26)
        self._pnv_formula.pack(fill='x', pady=3)
        info = tk.Frame(left, bg='#EBF3FB', padx=8, pady=6,
                        highlightbackground=C['border'], highlightthickness=1)
        info.pack(fill='x', pady=4)
        tk.Label(info, text="💡 Utilisez les noms de colonnes directement\n"
                             "et les fonctions numpy (np.log, np.sqrt…)",
                 font=FTS, bg='#EBF3FB', fg=C['textlt'], justify='left').pack(anchor='w')
        btn(left, "  ➕  Ajouter  ", self._add_comp, bg=C['success'], px=10, py=6).pack(pady=4)
        tk.Label(left, text="Variables ajoutées :", font=FTB, bg=C['bg']).pack(anchor='w', pady=(8,2))
        self._comp_lb = tk.Listbox(left, font=FTS, height=5, bg=C['panel'],
                                   relief='flat', highlightthickness=1,
                                   highlightbackground=C['border'],
                                   selectbackground=C['accent'])
        self._comp_lb.pack(fill='x')
        btn(left, "Supprimer", self._del_comp, bg='#888', px=8, py=4).pack(pady=3)

        right = tk.LabelFrame(pane, text=" 2.2  Discrétisation en classes ",
                              font=FTB, bg=C['bg'], fg=C['accent'], padx=10, pady=8)
        pane.add(right, minsize=350)
        tk.Label(right, text="Variable source (numérique) :", font=FTS,
                 bg=C['bg'], fg=C['textlt']).pack(anchor='w')
        self._cls_src = ttk.Combobox(right, font=FT, state='readonly', width=26)
        self._cls_src.pack(fill='x', pady=3)
        self._cls_min = labeled_entry(right, "Valeur minimale",  "0",   width=14)
        self._cls_min.pack(fill='x', pady=2)
        self._cls_max = labeled_entry(right, "Valeur maximale",  "100", width=14)
        self._cls_max.pack(fill='x', pady=2)
        self._cls_amp = labeled_entry(right, "Amplitude",        "20",  width=14)
        self._cls_amp.pack(fill='x', pady=2)
        self._cls_lbl = labeled_entry(right, "Étiquettes (séparées par ;) — vide = auto", width=26)
        self._cls_lbl.pack(fill='x', pady=2)
        btn(right, "  ➕  Créer les classes  ", self._add_class, bg=C['success'], px=10, py=6).pack(pady=4)
        tk.Label(right, text="Classes créées :", font=FTB, bg=C['bg']).pack(anchor='w', pady=(8,2))
        self._cls_lb = tk.Listbox(right, font=FTS, height=5, bg=C['panel'],
                                  relief='flat', highlightthickness=1,
                                  highlightbackground=C['border'],
                                  selectbackground=C['accent'])
        self._cls_lb.pack(fill='x')
        btn(right, "Supprimer", self._del_class, bg='#888', px=8, py=4).pack(pady=3)

    def _add_comp(self):
        if self.df_clean is None: return
        name    = self._pnv_name.var.get().strip()
        formula = self._pnv_formula.var.get().strip()
        if not name or not formula: messagebox.showwarning("","Renseignez nom et formule."); return
        df_new, err = add_computed_variable(self.df_clean, name, formula)
        if err: messagebox.showerror("Erreur", err); return
        self.df_clean = df_new
        self.var_types[name] = detect_variable_type(self.df_clean[name])
        self.computed_vars.append((name, formula))
        self._comp_lb.insert('end', f"{name}  =  {formula}")
        self._refresh_all()

    def _del_comp(self):
        sel = self._comp_lb.curselection()
        if not sel: return
        idx = sel[0]; name,_ = self.computed_vars[idx]
        if name in self.df_clean.columns:
            self.df_clean = self.df_clean.drop(columns=[name])
        del self.computed_vars[idx]; self._comp_lb.delete(idx); self._refresh_all()

    def _add_class(self):
        if self.df_clean is None: return
        src = self._cls_src.get()
        if not src: messagebox.showwarning("","Sélectionnez une variable source."); return
        try:
            vmin=float(self._cls_min.var.get()); vmax=float(self._cls_max.var.get())
            amp =float(self._cls_amp.var.get())
        except: messagebox.showerror("Erreur","Min/Max/Amplitude doivent être numériques."); return
        if amp<=0 or vmax<=vmin: messagebox.showerror("Erreur","Amplitude>0 et Max>Min."); return
        breaks = sorted(set([round(b,6) for b in np.arange(vmin, vmax+amp/2, amp)]))
        breaks[-1] = vmax
        lbl_s  = self._cls_lbl.var.get().strip()
        labels = [l.strip() for l in lbl_s.split(';')] if lbl_s else None
        if labels and len(labels) != len(breaks)-1: labels = None
        df_new, new_col, err = create_classes(self.df_clean, src, breaks, labels)
        if err: messagebox.showerror("Erreur", err); return
        self.df_clean = df_new; self.var_types[new_col] = 'qualitative'
        cv = {'source':src,'new_col':new_col,'breaks':str(breaks),
              'labels':','.join(labels) if labels else 'auto'}
        self.class_vars.append(cv)
        self._cls_lb.insert('end', f"{src} → {new_col}")
        self._refresh_all()

    def _del_class(self):
        sel = self._cls_lb.curselection()
        if not sel: return
        idx = sel[0]; cv = self.class_vars[idx]
        if cv['new_col'] in self.df_clean.columns:
            self.df_clean = self.df_clean.drop(columns=[cv['new_col']])
        del self.class_vars[idx]; self._cls_lb.delete(idx); self._refresh_all()

    # ──────────────────────────────────────────────────────────────
    #  DESCRIPTIF
    # ──────────────────────────────────────────────────────────────

    def _build_desc(self):
        top = tk.Frame(self.tab_desc, bg=C['bg'])
        top.pack(fill='x', padx=20, pady=10)
        sec_title(top, "📊  Étape 3a — Analyse descriptive").pack(fill='x')
        ctrl = tk.Frame(self.tab_desc, bg=C['bg'])
        ctrl.pack(fill='x', padx=20, pady=4)
        btn(ctrl, "Tout sél.",   lambda: [v.set(True)  for v in self.desc_checks.values()], bg=C['success'], px=8, py=5).pack(side='left', padx=(0,4))
        btn(ctrl, "Tout désél.", lambda: [v.set(False) for v in self.desc_checks.values()], bg='#888', px=8, py=5).pack(side='left')
        btn(ctrl, "  ▶  Lancer l'analyse  ", self._run_desc).pack(side='right')
        self.desc_sel_sf = ScrollFrame(self.tab_desc, bg=C['bg'])
        self.desc_sel_sf.pack(fill='x', padx=20, pady=4, ipady=6)
        self.desc_res_sf = ScrollFrame(self.tab_desc)
        self.desc_res_sf.pack(fill='both', expand=True, padx=20, pady=4)

    def _refresh_desc_sel(self):
        for w in self.desc_sel_sf.inner.winfo_children(): w.destroy()
        if self.df_clean is None: return
        self.desc_checks = {}
        COLS = 4
        for i, col in enumerate(self.df_clean.columns):
            vtype = self.var_types.get(col,'qualitative')
            icon  = '🔢' if vtype=='numerique' else '🔡'
            var   = tk.BooleanVar(value=True)
            self.desc_checks[col] = var
            frm = tk.Frame(self.desc_sel_sf.inner, bg=C['panel'],
                           highlightbackground=C['border'], highlightthickness=1)
            frm.grid(row=i//COLS, column=i%COLS, padx=3, pady=2, sticky='ew', ipadx=4, ipady=3)
            self.desc_sel_sf.inner.grid_columnconfigure(i%COLS, weight=1)
            tk.Checkbutton(frm, variable=var, bg=C['panel'],
                           activebackground=C['panel'], cursor='hand2').pack(side='left', padx=2)
            tk.Label(frm, text=f"{icon} {col}", font=FTS,
                     bg=C['panel'], fg=C['text']).pack(side='left')

    def _run_desc(self):
        if self.df_clean is None: return
        selected = [c for c,v in self.desc_checks.items() if v.get()]
        if not selected: messagebox.showwarning("","Sélectionnez au moins une variable."); return
        self._set_status("⏳ Analyse descriptive…", C['warning'])
        self.update()
        def _run():
            for col in selected:
                vt = self.var_types.get(col,'qualitative')
                try:
                    if vt == 'numerique':
                        self.charts[f'hist_{col}'] = histogram(self.df_clean[col])
                        self.charts[f'box_{col}']  = boxplot(self.df_clean[col])
                    else:
                        self.charts[f'bar_{col}'] = bar_chart(self.df_clean[col])
                        self.charts[f'pie_{col}'] = pie_chart(self.df_clean[col])
                except: pass
            # Heatmap
            try: self.charts['heatmap'] = correlation_heatmap(self.df_clean, self.var_types)
            except: pass
            self.after(0, lambda: [self._show_desc_results(selected),
                                   self._set_status("✔ Descriptif terminé", C['success'])])
        threading.Thread(target=_run, daemon=True).start()

    def _show_desc_results(self, selected):
        for w in self.desc_res_sf.inner.winfo_children(): w.destroy()
        inner = self.desc_res_sf.inner
        for col in selected:
            if col not in self.df_clean.columns: continue
            vtype = self.var_types.get(col,'qualitative')
            hdr = tk.Frame(inner, bg=C['accent'], padx=10, pady=5)
            hdr.pack(fill='x', pady=(8,1))
            tk.Label(hdr, text=f"{'🔢' if vtype=='numerique' else '🔡'}  {col}  [{vtype}]",
                     font=FTB, bg=C['accent'], fg='white').pack(side='left')
            body = tk.Frame(inner, bg=C['panel'],
                            highlightbackground=C['border'], highlightthickness=1)
            body.pack(fill='x', pady=(0,4))
            if vtype == 'numerique':
                s = descriptive_numeric(self.df_clean[col])
                if s is None: continue
                frm = tk.Frame(body, bg=C['panel'], padx=10, pady=8)
                frm.pack(fill='x')
                if s.get('normality'):
                    n = s['normality']
                    col_n = C['success'] if n['normal'] else C['warning']
                    tk.Label(frm,
                             text=f"Shapiro-Wilk : W={n['stat']}, p={n['p']}  "
                                  f"→ {'✔ Normale' if n['normal'] else '✘ Non normale'}",
                             font=FTS, bg=C['panel'], fg=col_n).pack(anchor='w', pady=2)
                grid = tk.Frame(frm, bg=C['panel']); grid.pack(anchor='w', pady=4)
                for i,(lbl,val) in enumerate([
                    ("N",s['n']),("Manquants",s['manquant']),
                    ("Moyenne",s['mean']),("Médiane",s['median']),
                    ("Écart-type",s['std']),("Mode",s['mode']),
                    ("Min",s['min']),("Max",s['max']),
                    ("Q1",s['q25']),("Q3",s['q75']),
                    ("IQR",s['iqr']),("Étendue",s['etendue']),
                ]):
                    cell = tk.Frame(grid, bg=C['alt'], padx=10, pady=6,
                                    highlightbackground=C['border'], highlightthickness=1)
                    cell.grid(row=i//6, column=i%6, padx=3, pady=3, sticky='ew')
                    tk.Label(cell, text=str(val), font=('Segoe UI',12,'bold'),
                             bg=C['alt'], fg=C['accent']).pack()
                    tk.Label(cell, text=lbl, font=FTS,
                             bg=C['alt'], fg=C['textlt']).pack()
                chart_frm = tk.Frame(frm, bg=C['panel']); chart_frm.pack(fill='x', pady=4)
                for k in [f'hist_{col}', f'box_{col}']:
                    show_img(chart_frm, self.charts.get(k))
            else:
                rows, n_miss, n_tot = frequency_table(self.df_clean[col])
                frm = tk.Frame(body, bg=C['panel'], padx=10, pady=8); frm.pack(fill='x')
                tk.Label(frm, text=f"N={n_tot}  |  Manquants={n_miss}  |  Modalités={len(rows)-1}",
                         font=FTS, bg=C['panel'], fg=C['textlt']).pack(anchor='w', pady=(0,4))
                tree = ttk.Treeview(frm, columns=('Modalité','n (%)'), show='headings', height=min(len(rows),8))
                tree.heading('Modalité', text='Modalité'); tree.column('Modalité', width=200)
                tree.heading('n (%)',    text='n  (%)');   tree.column('n (%)', width=150, anchor='center')
                tree.tag_configure('tot', background=C['alt'], font=FTB)
                tree.tag_configure('odd', background='#F8FAFB')
                tree.tag_configure('evn', background=C['panel'])
                for i, row in enumerate(rows):
                    is_t = row['modalite']=='Total'
                    val  = f"{row['effectif']}  (100%)" if is_t else f"{row['effectif']}  ({row['pourcentage']}%)"
                    tree.insert('','end', values=(row['modalite'], val),
                                tags=('tot' if is_t else ('odd' if i%2 else 'evn'),))
                tree.pack(anchor='w', pady=4)
                chart_frm = tk.Frame(frm, bg=C['panel']); chart_frm.pack(fill='x', pady=4)
                for k in [f'bar_{col}', f'pie_{col}']:
                    show_img(chart_frm, self.charts.get(k))
        # Heatmap
        if 'heatmap' in self.charts and self.charts['heatmap']:
            hdr2 = tk.Frame(inner, bg='#16A085', padx=10, pady=5)
            hdr2.pack(fill='x', pady=(10,1))
            tk.Label(hdr2, text="🌡️  Matrice de corrélation (variables numériques)",
                     font=FTB, bg='#16A085', fg='white').pack(side='left')
            body2 = tk.Frame(inner, bg=C['panel'],
                             highlightbackground=C['border'], highlightthickness=1)
            body2.pack(fill='x', pady=(0,6))
            show_img(body2, self.charts['heatmap'], max_w=700, max_h=500)

    # ──────────────────────────────────────────────────────────────
    #  BIVARIÉ
    # ──────────────────────────────────────────────────────────────

    def _build_bivar(self):
        sec_title(self.tab_bivar, "🔗  Étape 3b — Analyse bivariée").pack(
            fill='x', padx=20, pady=10)
        top = tk.Frame(self.tab_bivar, bg=C['bg'])
        top.pack(fill='x', padx=20, pady=4)
        top.columnconfigure(0, weight=1); top.columnconfigure(1, weight=2)

        dep_f = tk.LabelFrame(top, text=" Variable dépendante (Y) ",
                              font=FTB, bg=C['bg'], fg=C['accent'], padx=10, pady=8)
        dep_f.grid(row=0, column=0, sticky='nsew', padx=(0,10))
        tk.Label(dep_f, text="Sélectionnez Y :", font=FTS, bg=C['bg'], fg=C['textlt']).pack(anchor='w')
        self._dep_combo = ttk.Combobox(dep_f, textvariable=self.dep_var,
                                       state='readonly', font=FT, width=28)
        self._dep_combo.pack(fill='x', pady=4)
        self._dep_info = tk.Label(dep_f, text="", font=FTS, bg=C['bg'], fg=C['textlt'], wraplength=260)
        self._dep_info.pack(anchor='w')
        self._dep_combo.bind('<<ComboboxSelected>>', self._on_dep)

        ind_f = tk.LabelFrame(top, text=" Variables indépendantes (X) ",
                              font=FTB, bg=C['bg'], fg=C['accent'], padx=10, pady=8)
        ind_f.grid(row=0, column=1, sticky='nsew')
        ctrl_b = tk.Frame(ind_f, bg=C['bg']); ctrl_b.pack(fill='x', pady=(0,4))
        btn(ctrl_b, "Tout sél.",   lambda: [v.set(True)  for v in self.indep_checks.values()], bg=C['success'], px=8, py=4).pack(side='left', padx=(0,4))
        btn(ctrl_b, "Tout désél.", lambda: [v.set(False) for v in self.indep_checks.values()], bg='#888', px=8, py=4).pack(side='left')
        btn(ctrl_b, "  ▶  Lancer l'analyse bivariée  ", self._run_bivar).pack(side='right')
        self._ind_sf = ScrollFrame(ind_f, bg=C['bg'])
        self._ind_sf.pack(fill='both', expand=True)

        self.biv_res_sf = ScrollFrame(self.tab_bivar)
        self.biv_res_sf.pack(fill='both', expand=True, padx=20, pady=4)

    def _on_dep(self, e=None):
        dep = self.dep_var.get()
        if dep and self.df_clean is not None and dep in self.df_clean.columns:
            cats = self.df_clean[dep].dropna().unique()
            self._dep_info.config(
                text=f"Modalités ({len(cats)}) : {', '.join(str(c) for c in sorted(cats))}")

    def _refresh_indep(self):
        for w in self._ind_sf.inner.winfo_children(): w.destroy()
        if self.df_clean is None: return
        self.indep_checks = {}
        COLS = 3
        for i, col in enumerate(self.df_clean.columns):
            vtype = self.var_types.get(col,'qualitative')
            icon  = '🔢' if vtype=='numerique' else '🔡'
            var   = tk.BooleanVar(value=False)
            self.indep_checks[col] = var
            frm = tk.Frame(self._ind_sf.inner, bg=C['panel'],
                           highlightbackground=C['border'], highlightthickness=1)
            frm.grid(row=i//COLS, column=i%COLS, padx=3, pady=2, sticky='ew', ipadx=4, ipady=3)
            self._ind_sf.inner.grid_columnconfigure(i%COLS, weight=1)
            tk.Checkbutton(frm, variable=var, bg=C['panel'],
                           activebackground=C['panel'], cursor='hand2').pack(side='left', padx=2)
            tk.Label(frm, text=f"{icon} {col}", font=FTS,
                     bg=C['panel'], fg=C['text']).pack(side='left')

    def _run_bivar(self):
        dep = self.dep_var.get()
        if not dep: messagebox.showwarning("","Sélectionnez la variable dépendante."); return
        indeps = [c for c,v in self.indep_checks.items() if v.get() and c!=dep]
        if not indeps: messagebox.showwarning("","Sélectionnez au moins une variable indépendante."); return
        self._set_status("⏳ Analyse bivariée…", C['warning']); self.update()
        def _run():
            self.bivar_results  = {}
            self.num_results    = {}
            for iv in indeps:
                vt = self.var_types.get(iv, 'qualitative')
                try:
                    if vt == 'numerique':
                        # Test numérique vs qualitative
                        res = numeric_vs_qualitative(self.df_clean, iv, dep)
                        self.num_results[iv] = res
                        self.bivar_results[iv] = None   # pas de crosstab
                        try: self.charts[f'violin_{iv}'] = violin_plot(
                            self.df_clean, iv, dep)
                        except: pass
                    else:
                        res = crosstab_analysis(self.df_clean, dep, iv)
                        self.bivar_results[iv] = res
                        if res:
                            try: self.charts[f'grp_{iv}'] = grouped_bar_chart(
                                self.df_clean, dep, iv)
                            except: pass
                except Exception as e:
                    self.bivar_results[iv] = None; print(f"Bivar {iv}: {e}")
            self.after(0, lambda: [self._show_bivar_results(dep, indeps),
                                   self._refresh_regr(),
                                   self._set_status("✔ Bivarié terminé", C['success'])])
        threading.Thread(target=_run, daemon=True).start()

    def _show_bivar_results(self, dep, indeps):
        for w in self.biv_res_sf.inner.winfo_children(): w.destroy()
        inner = self.biv_res_sf.inner

        for iv in indeps:
            res = self.bivar_results.get(iv)
            p   = res.get('p_value') if res else None
            sig = res.get('significant',False) if res else False
            hdr_bg = C['success'] if sig else C['warning']

            hdr = tk.Frame(inner, bg=hdr_bg, padx=10, pady=5)
            hdr.pack(fill='x', pady=(8,1))
            tk.Label(hdr, text=f"🔗  {iv}  ×  {dep}",
                     font=FTB, bg=hdr_bg, fg='white').pack(side='left')
            if p is not None:
                tk.Label(hdr, text=f"  p = {p:.4f}  {'✔' if sig else '✘'}",
                         font=FTB, bg=hdr_bg,
                         fg='#CCFFCC' if sig else '#FFE0A0').pack(side='right')

            body = tk.Frame(inner, bg=C['panel'],
                            highlightbackground=C['border'], highlightthickness=1)
            body.pack(fill='x', pady=(0,4))

            if res is None:
                tk.Label(body, text="Analyse non disponible.",
                         font=FTS, bg=C['panel'], fg=C['textlt']).pack(pady=8); continue

            frm = tk.Frame(body, bg=C['panel'], padx=10, pady=8); frm.pack(fill='x')
            # Check if numeric test
            num_res = self.num_results.get(iv)
            if num_res is not None:
                tr  = num_res.get('test_recommande','—')
                pv  = num_res.get('p_value')
                sig2= num_res.get('significant', False)
                tk.Label(frm,
                    text=f"Test recommandé : {tr}  |  "
                         f"p = {pv:.4f if pv else '—'}  "
                         f"{'✔ SIGNIFICATIF' if sig2 else '✘ Non significatif'}",
                    font=FTB, bg=C['panel'],
                    fg=C['success'] if sig2 else C['warning']).pack(anchor='w', pady=4)
                all_normal = all(v['normal'] for v in num_res.get('normalite',{}).values() if v)
                if not all_normal:
                    tk.Label(frm, text="⚠ Distribution non normale → test non paramétrique utilisé",
                             font=FTS, bg=C['panel'], fg=C['warning']).pack(anchor='w')
                chart_frm = tk.Frame(frm, bg=C['panel']); chart_frm.pack(fill='x', pady=4)
                show_img(chart_frm, self.charts.get(f'violin_{iv}'))
            elif res is None:
                pass
            else:
                ct = res['crosstab']; pct = res['pct_col']
                col_cats = [c for c in ct.columns if c!='Total']
                row_cats = [r for r in ct.index   if r!='Total']
                tree_cols = [iv] + [f"{c} (n | %)" for c in col_cats] + ['Total']
                tree = ttk.Treeview(frm, columns=tree_cols, show='headings', height=len(row_cats)+1)
                tree.column(iv, width=160); tree.heading(iv, text=iv)
                for c in col_cats:
                    cn = f"{c} (n | %)"
                    tree.heading(cn, text=f"{c}  (n | %)"); tree.column(cn, width=140, anchor='center')
                tree.heading('Total', text='Total'); tree.column('Total', width=80, anchor='center')
                tree.tag_configure('tot', background=C['alt'], font=FTB)
                tree.tag_configure('odd', background='#F8FAFB'); tree.tag_configure('evn', background=C['panel'])
                for i, rcat in enumerate(row_cats):
                    vals = [str(rcat)]
                    for cc in col_cats:
                        n = int(ct.loc[rcat,cc])
                        pv = round(float(pct.loc[rcat,cc]),1) if rcat in pct.index and cc in pct.columns else 0
                        vals.append(f"{n}  |  {pv}%")
                    vals.append(str(int(ct.loc[rcat,'Total'])))
                    tree.insert('','end', values=vals, tags=('odd' if i%2 else 'evn',))
                tot_vals = ['Total']
                for cc in col_cats: tot_vals.append(str(int(ct.loc['Total',cc])) + "  |  100%")
                tot_vals.append(str(res['n']))
                tree.insert('','end', values=tot_vals, tags=('tot',))
                tree.pack(anchor='w', pady=4)

                tests = tk.Frame(frm, bg=C['step_ok'] if sig else '#FEF9E7', padx=8, pady=6,
                                 highlightbackground=C['border'], highlightthickness=1)
                tests.pack(fill='x', pady=4)
                if res.get('chi2') is not None:
                    tk.Label(tests, text=f"Chi²({res['dof']})={res['chi2']}  |  p={res['p_chi2']}  "
                                        f"→ {'✔ SIGN.' if res['p_chi2']<0.05 else '✘ NS'}",
                             font=FTS, bg=tests['bg'],
                             fg=C['success'] if res['p_chi2']<0.05 else C['warning']).pack(anchor='w')
                if res.get('fisher_or') is not None:
                    tk.Label(tests, text=f"Fisher OR={res['fisher_or']}  |  p={res['p_fisher']}  "
                                        f"→ {'✔ SIGN.' if res['p_fisher']<0.05 else '✘ NS'}",
                             font=FTS, bg=tests['bg'],
                             fg=C['success'] if res['p_fisher']<0.05 else C['warning']).pack(anchor='w')
                if res.get('message'):
                    tk.Label(tests, text=f"⚠  {res['message']}", font=FTS,
                             bg=tests['bg'], fg=C['warning']).pack(anchor='w')
                if p is not None:
                    tk.Label(tests,
                             text="→ Sélectionnée pour la régression (p<0.20)" if p<0.20
                                  else "→ Non retenue (p≥0.20)",
                             font=FTS, bg=tests['bg'],
                             fg=C['success'] if p<0.20 else C['textlt']).pack(anchor='w')

                chart_frm = tk.Frame(frm, bg=C['panel']); chart_frm.pack(fill='x', pady=4)
                show_img(chart_frm, self.charts.get(f'grp_{iv}'))

        # Résumé
        if self.bivar_results:
            hdr2 = tk.Frame(inner, bg='#8E44AD', padx=10, pady=5)
            hdr2.pack(fill='x', pady=(12,1))
            tk.Label(hdr2, text="📋  Récapitulatif des p-values",
                     font=FTB, bg='#8E44AD', fg='white').pack(side='left')
            body2 = tk.Frame(inner, bg=C['panel'],
                             highlightbackground=C['border'], highlightthickness=1)
            body2.pack(fill='x', pady=(0,6))
            sum_frm = tk.Frame(body2, bg=C['panel'], padx=10, pady=8); sum_frm.pack(fill='x')
            s_cols = ('Variable','Test','p-value','Significatif','Retenu (p<0.20)')
            tree2 = ttk.Treeview(sum_frm, columns=s_cols, show='headings',
                                 height=len(self.bivar_results))
            for c,w in zip(s_cols,[200,120,100,120,150]):
                tree2.heading(c,text=c); tree2.column(c,width=w,anchor='center')
            tree2.tag_configure('sig', background='#EAFAF1')
            tree2.tag_configure('ns',  background='#FEF9E7')
            # Fusionner bivar + num pour le récap
            all_biv = {}
            for iv, res in self.bivar_results.items():
                if res: all_biv[iv] = res
            for iv, res in self.num_results.items():
                if res: all_biv[iv] = res
            for iv, res in all_biv.items():
                test = res.get('test_recommande') or ('Chi²' if res.get('test_used')=='chi2' else 'Fisher')
                p    = res.get('p_value')
                sig  = '✔' if res.get('significant') else '✘'
                ret  = '✔ Oui' if p and p<0.20 else '✘ Non'
                tree2.insert('','end', values=(
                    iv, str(test), f"{p:.4f}" if p else '—', sig, ret),
                    tags=('sig' if res.get('significant') else 'ns',))
            tree2.pack(anchor='w')

    # ──────────────────────────────────────────────────────────────
    #  RÉGRESSION
    # ──────────────────────────────────────────────────────────────

    def _build_regr(self):
        sec_title(self.tab_regr, "📈  Étape 3c — Régression logistique").pack(
            fill='x', padx=20, pady=10)
        top = tk.Frame(self.tab_regr, bg=C['bg'])
        top.pack(fill='x', padx=20, pady=4)

        self._regr_info = tk.Label(top, text="Effectuez d'abord l'analyse bivariée.",
                                    font=FTS, bg=C['bg'], fg=C['textlt'], wraplength=900)
        self._regr_info.pack(anchor='w', pady=(0,6))

        # Options stepwise
        opt_frm = tk.LabelFrame(top, text=" Options Stepwise ",
                                font=FTB, bg=C['bg'], fg=C['accent'], padx=10, pady=6)
        opt_frm.pack(fill='x', pady=4)
        tk.Label(opt_frm, text="Méthode :", font=FTS, bg=C['bg']).pack(side='left')
        self._sw_method = ttk.Combobox(opt_frm, values=['none','forward','backward','both'],
                                        state='readonly', font=FT, width=12)
        self._sw_method.set('none'); self._sw_method.pack(side='left', padx=8)
        tk.Label(opt_frm, text="p entrée :", font=FTS, bg=C['bg']).pack(side='left', padx=(10,4))
        self._sw_pe = tk.StringVar(value='0.05')
        tk.Entry(opt_frm, textvariable=self._sw_pe, font=FT, width=6,
                 relief='flat', bg=C['panel']).pack(side='left')
        tk.Label(opt_frm, text="  p sortie :", font=FTS, bg=C['bg']).pack(side='left', padx=(10,4))
        self._sw_pr = tk.StringVar(value='0.10')
        tk.Entry(opt_frm, textvariable=self._sw_pr, font=FT, width=6,
                 relief='flat', bg=C['panel']).pack(side='left')
        tk.Label(opt_frm, text="  Seuil décision :", font=FTS, bg=C['bg']).pack(side='left', padx=(10,4))
        self._sw_thr = tk.StringVar(value='0.5')
        tk.Entry(opt_frm, textvariable=self._sw_thr, font=FT, width=6,
                 relief='flat', bg=C['panel']).pack(side='left')

        # Variables candidates
        tk.Label(top, text="Variables candidates (p<0.20) :", font=FTB,
                 bg=C['bg'], fg=C['text']).pack(anchor='w', pady=(6,2))
        self._regr_var_frm = tk.Frame(top, bg=C['bg'])
        self._regr_var_frm.pack(fill='x', pady=4)

        btn(top, "  ▶  Lancer la régression logistique  ",
            self._run_regr).pack(anchor='w', pady=8)

        self.regr_res_sf = ScrollFrame(self.tab_regr)
        self.regr_res_sf.pack(fill='both', expand=True, padx=20, pady=4)

    def _refresh_regr(self):
        for w in self._regr_var_frm.winfo_children(): w.destroy()
        self.regr_checks = {}
        dep = self.dep_var.get()
        if not self.bivar_results:
            self._regr_info.config(text="Effectuez d'abord l'analyse bivariée."); return
        cands = [(iv,res) for iv,res in self.bivar_results.items()
                 if res and res.get('p_value') is not None and res['p_value']<0.20 and iv!=dep]
        self._regr_info.config(
            text=f"Var. dépendante : « {dep} »  |  Candidates (p<0.20) : {len(cands)}")
        COLS = 4
        for i,(iv,res) in enumerate(cands):
            p     = res.get('p_value',1)
            vtype = self.var_types.get(iv,'qualitative')
            icon  = '🔢' if vtype=='numerique' else '🔡'
            var   = tk.BooleanVar(value=True)
            self.regr_checks[iv] = var
            frm = tk.Frame(self._regr_var_frm, bg=C['step_ok'],
                           highlightbackground=C['success'], highlightthickness=1)
            frm.grid(row=i//COLS, column=i%COLS, padx=4, pady=3, sticky='ew', ipadx=6, ipady=4)
            self._regr_var_frm.grid_columnconfigure(i%COLS, weight=1)
            tk.Checkbutton(frm, variable=var, bg=C['step_ok'],
                           activebackground=C['step_ok'], cursor='hand2').pack(side='left', padx=2)
            tk.Label(frm, text=f"{icon} {iv}", font=FTS,
                     bg=C['step_ok'], fg=C['text']).pack(side='left')
            tk.Label(frm, text=f"p={p:.3f}", font=FTS,
                     bg=C['step_ok'], fg=C['success']).pack(side='left', padx=4)

    def _run_regr(self):
        dep = self.dep_var.get()
        if not dep: messagebox.showwarning("","Aucune variable dépendante."); return
        indeps = [c for c,v in self.regr_checks.items() if v.get()]
        if not indeps: messagebox.showwarning("","Sélectionnez au moins une variable."); return
        try:
            p_enter  = float(self._sw_pe.get())
            p_remove = float(self._sw_pr.get())
            thr      = float(self._sw_thr.get())
        except: p_enter=0.05; p_remove=0.10; thr=0.5

        self._set_status("⏳ Régression en cours…", C['warning']); self.update()

        def _run():
            try:
                # Stepwise si demandé
                sw_method = self._sw_method.get()
                if sw_method != 'none':
                    sw_res = stepwise_logistic(self.df_clean, dep, indeps,
                                               sw_method, p_enter, p_remove)
                    self.stepwise_result = sw_res
                    if sw_res.get('selected'):
                        indeps_final = sw_res['selected']
                    else:
                        indeps_final = indeps
                else:
                    self.stepwise_result = None
                    indeps_final = indeps

                reg = logistic_regression(self.df_clean, dep, indeps_final)
                self.reg_result = reg

                # Graphiques
                try:
                    self.charts['forest_plot'] = forest_plot(reg)
                except: pass
                try:
                    if reg.get('roc_fpr') and reg.get('auc'):
                        self.charts['roc'] = roc_curve_plot(
                            reg['roc_fpr'], reg['roc_tpr'], reg['auc'])
                except: pass
                try:
                    if reg.get('confusion_matrix'):
                        import numpy as np
                        cm_arr = np.array(reg['confusion_matrix'])
                        metrics = {k: reg.get(k) for k in
                                   ['sensitivity','specificity','ppv','npv','accuracy']}
                        labels = [reg.get('ref_cat','0'), reg.get('event_cat','1')]
                        self.charts['confusion_matrix'] = confusion_matrix_plot(
                            cm_arr, labels, metrics)
                except: pass

                self.after(0, lambda: [self._show_regr_results(reg, dep),
                                       self._set_status("✔ Régression terminée", C['success'])])
            except Exception as e:
                import traceback; traceback.print_exc()
                self.after(0, lambda: messagebox.showerror("Erreur régression", str(e)))
        threading.Thread(target=_run, daemon=True).start()

    def _show_regr_results(self, reg, dep):
        for w in self.regr_res_sf.inner.winfo_children(): w.destroy()
        inner = self.regr_res_sf.inner

        # Stepwise
        if self.stepwise_result and not self.stepwise_result.get('error'):
            sw = self.stepwise_result
            hdr = tk.Frame(inner, bg='#8E44AD', padx=10, pady=5)
            hdr.pack(fill='x', pady=(6,1))
            tk.Label(hdr, text=f"🔄  Stepwise ({sw['method'].upper()}) — Variables retenues : {', '.join(sw['selected']) or 'Aucune'}",
                     font=FTB, bg='#8E44AD', fg='white').pack(side='left')
            body_sw = tk.Frame(inner, bg=C['panel'],
                               highlightbackground=C['border'], highlightthickness=1)
            body_sw.pack(fill='x', pady=(0,6), padx=0)
            if sw.get('steps'):
                frm = tk.Frame(body_sw, bg=C['panel'], padx=10, pady=8); frm.pack(fill='x')
                s_cols = ('Itération','Action','Variable','p-value')
                tree = ttk.Treeview(frm, columns=s_cols, show='headings', height=len(sw['steps']))
                for c, w in zip(s_cols,[80,100,200,100]):
                    tree.heading(c,text=c); tree.column(c,width=w,anchor='center')
                tree.tag_configure('in',  background='#EAFAF1')
                tree.tag_configure('out', background='#FDEDEC')
                for s in sw['steps']:
                    tree.insert('','end', values=(s['iter'],s['action'],s['variable'],s['p']),
                                tags=('in' if s['action']=='ENTREE' else 'out',))
                tree.pack(anchor='w')

        if reg.get('error'):
            err = tk.Frame(inner, bg='#FDEDEC', padx=12, pady=10,
                           highlightbackground=C['error'], highlightthickness=1)
            err.pack(fill='x', pady=8)
            tk.Label(err, text=f"❌  {reg['error']}",
                     font=FTB, bg='#FDEDEC', fg=C['error']).pack(anchor='w')
            return

        # Qualité
        hdr = tk.Frame(inner, bg=C['accent'], padx=10, pady=5)
        hdr.pack(fill='x', pady=(6,1))
        tk.Label(hdr, text=f"📊  Qualité du modèle  |  N={reg['n']}  |  "
                           f"Dep.=« {dep} »  |  Événement=« {reg.get('event_cat','?')} »",
                 font=FTB, bg=C['accent'], fg='white').pack(side='left')
        body_q = tk.Frame(inner, bg=C['panel'],
                          highlightbackground=C['border'], highlightthickness=1)
        body_q.pack(fill='x', pady=(0,6))
        frm_q = tk.Frame(body_q, bg=C['panel'], padx=10, pady=8); frm_q.pack(fill='x')
        qual = [
            ("Test omnibus",     f"χ²={reg.get('omnibus_chi2','—')}"),
            ("p omnibus",        str(reg.get('omnibus_p','—'))),
            ("R² Cox-Snell",     str(reg.get('cox_snell','—'))),
            ("R² Nagelkerke",    str(reg.get('nagelkerke','—'))),
            ("HL p",             str(reg.get('hl_p','—'))),
            ("AUC",              str(reg.get('auc','—'))),
            ("Sensibilité",      f"{reg.get('sensitivity','—')}%"),
            ("Spécificité",      f"{reg.get('specificity','—')}%"),
            ("VPP",              f"{reg.get('ppv','—')}%"),
            ("VPN",              f"{reg.get('npv','—')}%"),
            ("% bien classés",   f"{reg.get('accuracy','—')}%"),
        ]
        grid_q = tk.Frame(frm_q, bg=C['panel']); grid_q.pack(anchor='w')
        for i,(l,v) in enumerate(qual):
            cell = tk.Frame(grid_q, bg=C['alt'], padx=10, pady=6,
                            highlightbackground=C['border'], highlightthickness=1)
            cell.grid(row=i//6, column=i%6, padx=3, pady=3, sticky='ew')
            tk.Label(cell, text=str(v), font=('Segoe UI',11,'bold'),
                     bg=C['alt'], fg=C['accent']).pack()
            tk.Label(cell, text=l, font=FTS, bg=C['alt'], fg=C['textlt']).pack()

        # VIF + Forest
        for key, label, col_hdr in [
            ('vif_plot',       f"VIF — Multicolinéarité",                     '#D35400'),
            ('forest_plot',    f"Forest plot — OR (IC 95%)",                  '#2980B9'),
            ('roc_curve',      f"Courbe ROC — AUC = {reg.get('auc','—')}",   '#27AE60'),
            ('confusion_matrix', f"Matrice de confusion",                     '#16A085'),
        ]:
            if key in self.charts and self.charts[key]:
                hdr2 = tk.Frame(inner, bg=col_hdr, padx=10, pady=5)
                hdr2.pack(fill='x', pady=(8,1))
                tk.Label(hdr2, text=label, font=FTB, bg=col_hdr, fg='white').pack(side='left')
                b2 = tk.Frame(inner, bg=C['panel'],
                              highlightbackground=C['border'], highlightthickness=1)
                b2.pack(fill='x', pady=(0,4))
                show_img(b2, self.charts[key], max_w=700, max_h=400)

        # Tableau résultats
        hdr3 = tk.Frame(inner, bg='#1E4D2B', padx=10, pady=5)
        hdr3.pack(fill='x', pady=(8,1))
        tk.Label(hdr3, text="📋  Résultats par variable (β, OR, IC 95%, p-value)",
                 font=FTB, bg='#1E4D2B', fg='white').pack(side='left')
        body3 = tk.Frame(inner, bg=C['panel'],
                         highlightbackground=C['border'], highlightthickness=1)
        body3.pack(fill='x', pady=(0,6))
        frm3 = tk.Frame(body3, bg=C['panel'], padx=10, pady=8); frm3.pack(fill='x')
        r_cols = ('Variable','β','SE','OR','IC inf','IC sup','p-value','Sig.')
        tree = ttk.Treeview(frm3, columns=r_cols, show='headings',
                            height=min(len(reg['variables']),14))
        vsb = ttk.Scrollbar(frm3, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        for c,w in zip(r_cols,[220,80,80,80,90,90,90,60]):
            tree.heading(c,text=c); tree.column(c,width=w,anchor='center')
        tree.tag_configure('sig', background='#EAFAF1')
        tree.tag_configure('ns',  background='#FEF9E7')
        tree.tag_configure('alt', background=C['alt'])
        for i,vd in enumerate(reg['variables']):
            sig = vd['significant']
            tag = 'sig' if sig else ('alt' if i%2 else 'ns')
            p_s = f"{vd['p_value']:.4f}" if vd['p_value']>=0.0001 else "<0.0001"
            p_s += " ✔" if sig else ""
            tree.insert('','end', values=(
                vd['variable'],vd['beta'],vd['se'],vd['OR'],
                vd['ci_lo'],vd['ci_hi'],p_s,'✔' if sig else '✘'),
                tags=(tag,))
        tree.pack(side='left', fill='x', expand=True)
        vsb.pack(side='right', fill='y')
        tk.Label(frm3,
                 text="✔ p<0.05  |  OR>1 = risque  |  OR<1 = protecteur  |  IC ne contenant pas 1",
                 font=FTS, bg=C['panel'], fg=C['textlt']).pack(anchor='w', pady=4)

    # ──────────────────────────────────────────────────────────────
    #  JOURNAL
    # ──────────────────────────────────────────────────────────────

    def _build_log(self):
        sec_title(self.tab_log, "📋  Journal des actions").pack(
            fill='x', padx=20, pady=10)
        ctrl = tk.Frame(self.tab_log, bg=C['bg'])
        ctrl.pack(fill='x', padx=20, pady=4)
        btn(ctrl, "🔄  Rafraîchir", self._refresh_log, px=10, py=6).pack(side='left', padx=(0,6))
        btn(ctrl, "💾  Exporter journal (.json)", self._export_log, bg='#8E44AD', px=10, py=6).pack(side='left')
        self.log_sf = ScrollFrame(self.tab_log)
        self.log_sf.pack(fill='both', expand=True, padx=20, pady=4)
        self._refresh_log()

    def _refresh_log(self):
        for w in self.log_sf.inner.winfo_children(): w.destroy()
        entries = get_log()
        if not entries:
            tk.Label(self.log_sf.inner, text="Aucune action enregistrée.",
                     font=FTS, bg=C['bg'], fg=C['textlt']).pack(pady=20); return
        cols = ('Heure','Étape','Action','Détail')
        tree = ttk.Treeview(self.log_sf.inner, columns=cols, show='headings',
                            height=min(len(entries), 25))
        vsb = ttk.Scrollbar(self.log_sf.inner, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        for c, w in zip(cols,[80,160,240,400]):
            tree.heading(c,text=c); tree.column(c,width=w,anchor='w' if w>100 else 'center')
        for i,e in enumerate(entries):
            bg = C['alt'] if i%2 else C['panel']
            tree.insert('','end', values=(e['time'],e['step'],e['action'],e.get('detail','')))
        tree.pack(side='left', fill='both', expand=True)
        vsb.pack(side='right', fill='y')

    def _export_log(self):
        path = filedialog.asksaveasfilename(
            defaultextension='.json',
            filetypes=[("JSON","*.json"),("Texte","*.txt")],
            initialfile=f"journal_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.json")
        if not path: return
        import json
        with open(path,'w',encoding='utf-8') as f:
            json.dump(get_log(), f, ensure_ascii=False, indent=2)
        messagebox.showinfo("OK", f"Journal exporté :\n{path}")

    # ──────────────────────────────────────────────────────────────
    #  SAUVEGARDE / CHARGEMENT SESSION
    # ──────────────────────────────────────────────────────────────

    def _save_session(self):
        if self.df_clean is None:
            messagebox.showwarning("","Aucune donnée à sauvegarder."); return
        path = filedialog.asksaveasfilename(
            defaultextension='.json',
            filetypes=[("Session DataAnalyser","*.json")],
            initialfile=f"session_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.json")
        if not path: return
        session = {
            'file_path':    self.file_path,
            'threshold':    self.threshold.get(),
            'dropped_cols': self.dropped_cols,
            'computed_vars':self.computed_vars,
            'class_vars':   self.class_vars,
            'dep_var':      self.dep_var.get(),
            'outlier_actions': self.outlier_actions,
            'imputation_log':  self.imputation_log,
            'log_entries':  get_log(),
            'saved_at':     datetime.datetime.now().isoformat(),
        }
        with open(path,'w',encoding='utf-8') as f:
            json.dump(session, f, ensure_ascii=False, indent=2)
        messagebox.showinfo("OK", f"Session sauvegardée :\n{path}")

    def _load_session(self):
        path = filedialog.askopenfilename(
            filetypes=[("Session DataAnalyser","*.json"),("Tous","*.*")])
        if not path: return
        try:
            with open(path,'r',encoding='utf-8') as f:
                session = json.load(f)
            info = (f"Session du {session.get('saved_at','?')}\n"
                    f"Fichier : {session.get('file_path','?')}\n\n"
                    f"Voulez-vous recharger le fichier Excel original et restaurer la configuration ?")
            if not messagebox.askyesno("Charger session", info): return
            xl_path = session.get('file_path')
            if xl_path and os.path.exists(xl_path):
                self.df_raw = pd.read_excel(xl_path)
                self.file_path = xl_path
                self.df_clean  = self.df_raw.copy()
                for col in self.df_clean.columns:
                    self.var_types[col] = detect_variable_type(self.df_clean[col])
                self.missing_df    = analyze_missing(self.df_raw)
                self.threshold.set(session.get('threshold', 30.0))
                self.dropped_cols  = session.get('dropped_cols', [])
                self.dep_var.set(session.get('dep_var',''))
                self.computed_vars = session.get('computed_vars',[])
                self.class_vars    = session.get('class_vars',[])
                self._refresh_all()
                self._set_status(f"✔ Session restaurée", C['success'])
                messagebox.showinfo("OK","Session restaurée.\nRelancez les analyses pour obtenir les graphiques.")
            else:
                messagebox.showwarning("","Fichier Excel introuvable. Chargez-le manuellement.")
        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    # ──────────────────────────────────────────────────────────────
    #  ACTIONS GLOBALES
    # ──────────────────────────────────────────────────────────────

    def _refresh_all(self):
        if self.df_clean is None: return
        cols = list(self.df_clean.columns)
        self._dep_combo['values'] = cols
        num_cols = [c for c in cols if self.var_types.get(c)=='numerique']
        self._cls_src['values'] = num_cols
        self._refresh_desc_sel()
        self._refresh_indep()
        self._display_outliers()
        self._refresh_regr()

    def _load(self):
        path = filedialog.askopenfilename(
            title="Sélectionner un fichier Excel",
            filetypes=[("Excel","*.xlsx *.xls *.xlsm"),("Tous","*.*")])
        if not path: return
        try:
            clear_log()
            self.df_raw = pd.read_excel(path)
            self.file_path = path
            self.df_clean  = self.df_raw.copy()
            for col in self.df_clean.columns:
                self.var_types[col] = detect_variable_type(self.df_clean[col])
            self.missing_df    = analyze_missing(self.df_raw)
            self.dropped_cols  = []
            self.computed_vars = []; self.class_vars    = []
            self.bivar_results = {}; self.num_results   = {}; self.reg_result = None
            self.charts        = {}; self.stepwise_result = None
            self.outlier_results = outlier_summary(self.df_clean)
            log_action("Chargement", f"Fichier chargé", f"{len(self.df_raw)} lignes × {len(self.df_raw.columns)} colonnes")
            self._set_status(f"✔ {os.path.basename(path)}\n{len(self.df_raw)} lignes · {len(self.df_raw.columns)} colonnes", C['success'])
            self._refresh_all()
            self.nb.select(1)
            self._run_clean()
        except Exception as e:
            messagebox.showerror("Erreur de chargement", str(e))

    def _export(self):
        if self.df_clean is None:
            messagebox.showwarning("","Chargez d'abord un fichier."); return
        path = filedialog.asksaveasfilename(
            defaultextension='.docx',
            filetypes=[("Word","*.docx")],
            initialfile=f"rapport_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.docx")
        if not path: return
        self._set_status("⏳ Export Word en cours…", C['warning']); self.update()
        def _run():
            try:
                from export.word_export import generate_report
                desc_vars = [c for c,v in self.desc_checks.items() if v.get()] \
                            if self.desc_checks else list(self.df_clean.columns)
                reg_vars  = [c for c,v in self.regr_checks.items() if v.get()] \
                            if self.regr_checks else []
                generate_report({
                    'output_path':     path,
                    'title':           f"Rapport d'analyse statistique\n{os.path.basename(self.file_path or '')}",
                    'filename':        os.path.basename(self.file_path or ''),
                    'df_original':     self.df_raw,
                    'df_clean':        self.df_clean,
                    'missing_df':      self.missing_df,
                    'dropped_cols':    self.dropped_cols,
                    'threshold':       self.threshold.get(),
                    'outlier_results': self.outlier_results,
                    'outlier_actions': self.outlier_actions,
                    'imputation_log':  self.imputation_log,
                    'computed_vars':   self.computed_vars,
                    'class_vars':      self.class_vars,
                    'var_types':       self.var_types,
                    'desc_vars':       desc_vars,
                    'dep_var':         self.dep_var.get() or None,
                    'indep_vars':      list(self.bivar_results.keys()),
                    'bivar_results':   self.bivar_results,
                    'num_results':     self.num_results,
                    'stepwise_result': self.stepwise_result,
                    'reg_result':      self.reg_result,
                    'reg_vars':        reg_vars,
                    'charts':          self.charts,
                    'outlier_df':      self.outlier_results,
                    'action_log':      get_log(),
                })
                self.after(0, lambda: [
                    self._set_status("✔ Rapport exporté !", C['success']),
                    messagebox.showinfo("Export réussi", f"Rapport :\n{path}")])
            except Exception as e:
                import traceback; traceback.print_exc()
                self.after(0, lambda: [
                    self._set_status("❌ Erreur export", C['error']),
                    messagebox.showerror("Erreur export", str(e))])
        threading.Thread(target=_run, daemon=True).start()


def _init():
    for d in ['core','export','ui']:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), d, '__init__.py')
        if not os.path.exists(p): open(p,'w').close()


if __name__ == '__main__':
    _init()
    App().mainloop()
